"""
系统编排器 — 整合所有模块的核心处理流水线
===========================================

处理流程：
1. 用户输入 → 自我意识预检（我是我-病是病）
2. → 语义确认闸门（模糊？残缺？→ 补全变量）
3. → PIF检查（群体频率≠个体真值？）
4. → 事实/观点分类
   ├ 客观事实 → 事实引擎（交叉验证后入公理）
   └ 主观观点 → 信念引擎（用户会话级，不公开）
5. → 矛盾检测（有矛盾？→ 罗列路径，不评判）
6. → 沙盒路由（创造性表达？→ 架空现实模式）
7. → 延标标记（未闭合的标X(∞)）
8. → 自我意识后检（输出前确认无价值判断）
9. → 输出：决策链罗列，共生协作推进
"""

from __future__ import annotations

import os
import random
import re
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

# 确保能导入 core 包
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.protocol import PROTOCOLS, protocol_summary, check_protocol_compliance
from core.self_awareness import SelfAwareness
from core.pif_guard import PIFGuard
from core.fact_engine import FactEngine
from core.belief_engine import BeliefEngine
from core.semantic_gate import SemanticGate
from core.sandbox_engine import SandboxEngine, SANDBOX_DISCLAIMER
from core.conflict_resolver import ConflictResolver
from core.curiosity_engine import CuriosityEngine, GapPriority
from core.semantic_retriever import SemanticRetriever
from core.context_manager import ContextManager
from core.memory_selector import MemorySelector
from core.user_emotion_detector import UserEmotionDetector
from core.auto_internal_gap import AutoInternalGapGenerator
from core.suspended_search_scheduler import SuspendedSearchScheduler, SearchPriority


@dataclass
class ProcessingResult:
    """处理结果"""
    # 处理阶段
    stages: List[Dict] = field(default_factory=list)
    # 最终输出
    output_text: str = ""
    # 延标标记
    unknown_markers: List[Dict] = field(default_factory=list)
    # 决策链
    decision_chain: List[str] = field(default_factory=list)
    # 是否进入沙盒
    in_sandbox: bool = False
    # 是否需要用户补充
    needs_user_input: bool = False
    # 用户确认问题
    questions_for_user: List[str] = field(default_factory=list)
    # 好奇心/补全欲报告
    curiosity_report: Optional[Dict] = None
    # 系统张力状态
    system_tension: Optional[Dict] = None
    # 原始输入
    raw_input: str = ""
    # 时间戳
    timestamp: float = field(default_factory=time.time)
    # 意图类型: casual/subjective/self_ref/creative/serious
    intent_type: str = "serious"
    # 响应模式: casual(闲聊无流水线) / light(轻量无五段式) / standard(标准五段式)
    response_mode: str = "standard"
    # 缺口闭合数量（本次交互新闭合了几个）
    gaps_closed: int = 0
    # 直接回答（给用户看的自然语言答案，放在最前面）
    direct_answer: str = ""

    def to_dict(self) -> Dict:
        return {
            "stages": self.stages,
            "output_text": self.output_text,
            "unknown_markers": self.unknown_markers,
            "decision_chain": self.decision_chain,
            "in_sandbox": self.in_sandbox,
            "needs_user_input": self.needs_user_input,
            "questions_for_user": self.questions_for_user,
            "curiosity_report": self.curiosity_report,
            "system_tension": self.system_tension,
            "raw_input": self.raw_input,
            "timestamp": self.timestamp,
            "intent_type": self.intent_type,
            "response_mode": self.response_mode,
            "gaps_closed": self.gaps_closed,
            "direct_answer": self.direct_answer,
        }


class YanbiaoCore:
    """系统编排器 — 整合所有模块。"""

    def __init__(self, storage_path: str = None):
        if storage_path is None:
            storage_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")

        self.storage_path = storage_path
        os.makedirs(storage_path, exist_ok=True)

        # 初始化所有模块
        self.awareness = SelfAwareness()
        self.pif = PIFGuard()
        self.semantic_gate = SemanticGate()
        self.fact_engine = FactEngine(storage_path)
        self.belief_engine = BeliefEngine(storage_path)
        self.sandbox = SandboxEngine(storage_path)
        self.conflict_resolver = ConflictResolver(storage_path)
        self.curiosity = CuriosityEngine(storage_path)

        # 外挂扩展模块（第一批：检索+上下文）
        self.retriever = SemanticRetriever()   # 分层语义检索
        self.context = ContextManager()        # 对话上下文管理

        # 外挂扩展模块（第二批：记忆+情绪+自探索+悬置查找）
        self.memory_selector = MemorySelector()          # 记忆选择器（主动遗忘）
        self.emotion_detector = UserEmotionDetector()    # 用户情绪识别
        self.auto_gap = AutoInternalGapGenerator(enabled=True)  # 内部自探索缺口生成
        self.search_scheduler = SuspendedSearchScheduler()  # 悬置查找调度器

        # 模块开关（可独立控制）
        self.modules_enabled = {
            "memory_selector": True,
            "emotion_detector": True,
            "auto_internal_gap": True,
            "suspended_search": True,
        }

        # 协议信息
        self.protocols = protocol_summary()

        # 预加载种子数据
        self._seed_data()

    def _seed_data(self):
        """预加载种子事实和信念。"""
        # 种子客观事实
        seeds = [
            ("苹果可食用", ["食物", "客观事实"]),
            ("水在标准大气压下100°C沸腾", ["物理", "客观事实"]),
            ("延标体系以X(∞)标记认知边界", ["延标", "理论"]),
            ("强制坍缩是幻觉的深层根源", ["延标", "幻觉"]),
        ]
        for stmt, tags in seeds:
            fact_id = self.fact_engine._gen_id(stmt)
            if fact_id not in self.fact_engine._facts:
                fact, info = self.fact_engine.register_fact(stmt, tags=tags)
                if fact and info.get("needs_verification"):
                    # 种子数据加两个来源，直接通过验证
                    self.fact_engine.cross_validate(fact.id, "种子数据-初始加载")
                    self.fact_engine.cross_validate(fact.id, "系统内置知识库")
            else:
                # 已存在的种子事实确保已验证
                existing = self.fact_engine._facts[fact_id]
                if not existing.verified and existing.scope == "universal":
                    # 补充来源使其通过验证
                    if "种子数据-初始加载" not in existing.sources:
                        existing.sources.append("种子数据-初始加载")
                    if "系统内置知识库" not in existing.sources:
                        existing.sources.append("系统内置知识库")
                    if len(existing.sources) >= 2:
                        existing.verified = True
                        self.fact_engine._save(existing)

    def process(self, user_input: str, user_id: str = "default", force_mode: str = None) -> ProcessingResult:
        """主处理流水线。
        
        Args:
            force_mode: 强制模式，覆盖自动意图分类
                - "casual": 强制闲聊模式
                - "serious": 强制工作/严肃模式（五段式）
                - "creative": 强制沙盒/创意模式
        """
        result = ProcessingResult(raw_input=user_input)
        self._force_mode = force_mode
        # 话题追踪状态（每轮重置，避免跨轮泄漏）
        self._topic_tracking = None
        self._topic_related_text = ""
        self._topic_shared_kw = ""

        # ====== 阶段0: 上下文预处理（指代消解 + 语义记忆） ======
        ctx = self.context.preprocess_input(user_id, user_input)
        result.stages.append({
            "stage": "context_preprocess",
            "name": "上下文预处理",
            "result": {
                "anaphora_resolved": ctx["anaphora"]["resolved"],
                "resolutions": ctx["anaphora"]["resolutions"],
                "known_ambiguities_count": len(ctx["known_ambiguities"]),
                "needs_confirmation": ctx["needs_confirmation"],
                "resolved_text": ctx["resolved"],
            },
        })

        # 使用消解后的文本进行后续处理（如果置信度够高）
        effective_input = ctx["resolved"] if ctx["anaphora"]["resolved"] else user_input

        # ====== 阶段0.5: 情绪检测 + 数字镜像更新（外挂模块） ======
        emotion = None
        style_prompt = ""
        if self.modules_enabled["emotion_detector"]:
            emotion = self.emotion_detector.detect(effective_input, user_id)
            mood = self.emotion_detector.get_mood(user_id)
            style_prompt = self.emotion_detector.get_response_style_hint(emotion, mood)
            result.stages.append({
                "stage": "emotion_detection",
                "name": "情绪识别（外挂）",
                "result": {
                    "emotion": emotion.primary_emotion.value,
                    "intensity": emotion.intensity.value,
                    "confidence": round(emotion.confidence, 3),
                    "is_negative": emotion.is_negative,
                    "triggers": emotion.triggers,
                    "style_hint": style_prompt,
                    "suppress_curiosity": self.emotion_detector.should_suppress_curiosity(user_id),
                },
            })

        if self.modules_enabled["memory_selector"]:
            mirror = self.memory_selector.update_digital_mirror(user_id, user_input)
            result.stages.append({
                "stage": "digital_mirror",
                "name": "数字镜像更新（外挂）",
                "result": {
                    "avg_sentence_length": round(mirror.avg_sentence_length, 1),
                    "formality_score": round(mirror.formality_score, 3),
                    "total_interactions": mirror.total_interactions,
                    "style_prompt": mirror.get_style_prompt(),
                },
            })

        # ====== 阶段1: 自我意识预检 ======
        pre_check = self.awareness.check_self(effective_input, "")
        result.stages.append({
            "stage": "self_awareness_pre",
            "name": "自我意识预检",
            "result": pre_check,
        })

        # ====== 阶段2: 语义确认闸门 ======
        # 获取对话轮数，用于上下文频率调度
        context_turns = self.context.get_turn_count(user_id)
        semantic = self.semantic_gate.check(
            effective_input,
            context_turns=context_turns,
            known_ambiguities=self.context.get_known_resolutions(user_id)
        )
        # 强制模式覆盖自动意图分类
        if self._force_mode == "casual":
            semantic.intent_type = "casual"
        elif self._force_mode == "serious":
            semantic.intent_type = "serious"
        elif self._force_mode == "creative":
            semantic.intent_type = "creative"
        result.intent_type = semantic.intent_type

        # 上下文优化：过滤掉已经确认过的模糊词
        if semantic.issues:
            known = self.context.get_known_resolutions(user_id)
            filtered_issues = []
            filtered_questions = []
            for issue in semantic.issues:
                # 检查是否所有模糊词都已确认
                skip = False
                for word, meaning in known.items():
                    if f"模糊词：{word}" in issue or word in issue:
                        skip = True
                        break
                if not skip:
                    filtered_issues.append(issue)
            # 重新生成问题（仅针对未确认的模糊词）
            if filtered_issues:
                all_ambiguous_words = self.semantic_gate.HIGH_AMBIGUOUS_WORDS + self.semantic_gate.MED_AMBIGUOUS_WORDS
                found_words = []
                for issue in filtered_issues:
                    if "模糊词" in issue:
                        for word in all_ambiguous_words:
                            if word in issue and word not in known and word not in found_words:
                                found_words.append(word)
                # 去重 + 最长优先：如果"那个东西"和"那个"都存在，只留"那个东西"
                found_words.sort(key=len, reverse=True)
                unique_words = []
                for w in found_words:
                    if not any(w != u and w in u for u in unique_words):
                        unique_words.append(w)
                for w in unique_words:
                    filtered_questions.append(
                        f"您提到的'{w}'具体指什么？请补充明确的信息。"
                    )
            semantic.issues = filtered_issues
            semantic.suggested_questions = filtered_questions
            semantic.passed = len(filtered_issues) == 0
            if semantic.passed:
                semantic.clarity = "clear"

        result.stages.append({
            "stage": "semantic_gate",
            "name": "语义确认",
            "result": {
                "clarity": semantic.clarity,
                "issues": semantic.issues,
                "intent_type": semantic.intent_type,
                "ambiguity_severity": semantic.ambiguity_severity,
            },
        })

        if not semantic.passed:
            # 语义不清晰，需要用户补充
            result.needs_user_input = True
            result.questions_for_user = semantic.suggested_questions
            result.output_text = self._format_semantic_question(semantic)
            result.response_mode = "light"
            # 直接回答：告诉用户需要澄清
            questions = semantic.suggested_questions[:2]
            q_list = "\n".join(f"• {q}" for q in questions)
            result.direct_answer = (
                f"我注意到你的表述中有一些不太明确的地方，想确认一下：\n\n"
                f"{q_list}\n\n"
                f"你可以告诉我具体指的是什么，这样我就能更准确地回应了。"
            )
            return result

        # 先确定意图类型（供后续各阶段使用）
        intent = semantic.intent_type
        result.intent_type = intent

        # ====== 阶段2.15: 纠正意图检测（跨模式：闲聊 + 工作）======
        # 用户说"纠正/作废/改成..."时，更新已存信念，避免重复存储与
        # "纠正后系统仍回答旧内容"的问题。在 _build_casual_response 与
        # 工作模式的事实/信念注册之前拦截，对所有模式生效。
        correction_msg = self._handle_correction(effective_input, user_id)
        if correction_msg:
            result.output_text = correction_msg
            result.direct_answer = result.output_text
            result.response_mode = "casual" if intent == "casual" else "light"
            result.stages.append({
                "stage": "correction_handled",
                "name": "纠正处理",
                "result": {"corrected": True, "message": correction_msg},
            })
            # 仍然更新上下文
            self.context.update_turn_response(user_id, result.output_text)
            # 纠正也是有效交互，产生缺口活动（转盘反馈）
            self._ensure_gap_activity(result, effective_input)
            return result

        # ====== 阶段2.2: 话题追踪（跳跃式交互识别）======
        # 在意图分支前，识别当前输入与最近历史话题的关系，
        # 支持用户东拉西扯后又绕回之前话题的跳跃式交互。
        topic_tracking = self._track_topic(effective_input, user_id)
        self._topic_tracking = topic_tracking
        result.stages.append({
            "stage": "topic_tracking",
            "name": "话题追踪",
            "result": topic_tracking,
        })

        # ====== 阶段2.3: 用户事实自动存储（会话级信念）======
        # 用户陈述的关于身边人/事/物的事实，自动作为会话级信念存下来
        auto_belief = self._try_auto_store_user_fact(effective_input, user_id, intent)
        if auto_belief:
            result.stages.append({
                "stage": "auto_belief_store",
                "name": "用户事实自动存储",
                "result": {
                    "belief_id": auto_belief.id,
                    "statement": effective_input,
                    "scope": auto_belief.scope,
                    "source": "用户陈述",
                    "category": "personal_fact",
                    "note": "用户陈述的个人事实，已自动存入会话级信念",
                },
            })

        # ====== 阶段2.5: 意图分支 — 不同模式不同处理路径 ======

        # 闲聊模式 — 轻松自然回复，不走重型流水线
        if intent == "casual":
            result.output_text = self._build_casual_response(effective_input, user_id)
            result.direct_answer = result.output_text
            result.response_mode = "casual"
            result.stages = result.stages[:3]  # 只保留前3个阶段（预处理/情绪/镜像/语义）
            # 仍然更新上下文
            self.context.update_turn_response(user_id, result.output_text)
            # 确保每次有效交互都有缺口活动（转盘反馈）
            self._ensure_gap_activity(result, effective_input)
            return result

        # 主观表达模式 — 共情回应 + 信念记录，轻量输出
        if intent == "subjective":
            result.output_text = self._build_subjective_response(effective_input, user_id)
            result.direct_answer = result.output_text
            result.response_mode = "light"
            # 保留必要的阶段
            result.stages = [s for s in result.stages
                             if s["stage"] in ("context_preprocess", "emotion_detection",
                                               "digital_mirror", "semantic_gate",
                                               "self_awareness_pre", "belief_register")]
            # 注册信念
            belief = self.belief_engine.register_belief(
                user_id=user_id,
                statement=effective_input,
                category="preference",
                source="用户自述",
            )
            self.context.track_entity(user_id, effective_input[:20],
                                      context="用户信念", importance=0.5)
            if self.modules_enabled["memory_selector"]:
                self.memory_selector.on_create(belief.id, tags=["用户信念", "preference"])
            result.stages.append({
                "stage": "belief_register",
                "name": "信念注册",
                "result": {
                    "belief_id": belief.id,
                    "weight": belief.weight,
                    "scope": belief.scope,
                    "note": "主观感受已记录为用户信念（会话级）",
                },
            })
            self.context.update_turn_response(user_id, result.output_text)
            # 确保每次有效交互都有缺口活动（转盘反馈）
            self._ensure_gap_activity(result, effective_input)
            return result

        # 自我指涉模式 — 用数字镜像的自我意识回答，不走完整流水线
        if intent == "self_ref":
            result.output_text = self._build_self_ref_response(effective_input, user_id)
            result.direct_answer = result.output_text
            result.response_mode = "light"
            # 只保留自我意识相关的阶段
            result.stages = [s for s in result.stages
                             if s["stage"] in ("context_preprocess", "emotion_detection",
                                               "digital_mirror", "semantic_gate",
                                               "self_awareness_pre")]
            self.context.update_turn_response(user_id, result.output_text)
            # 确保每次有效交互都有缺口活动（转盘反馈）
            self._ensure_gap_activity(result, effective_input)
            return result

        # ====== 阶段3: PIF检查 ======
        pif_alert = self.pif.check(effective_input)
        result.stages.append({
            "stage": "pif_check",
            "name": "PIF防护",
            "result": {"triggered": pif_alert.triggered,
                       "reason": pif_alert.reason if pif_alert.triggered else None},
        })

        if pif_alert.triggered:
            result.output_text = (
                f"⚠ 概率个体化谬误警报\n\n"
                f"群体数据：{pif_alert.group_data}\n"
                f"被套用对象：{pif_alert.individual_target}\n"
                f"原因：{pif_alert.reason}\n\n"
                f"修正建议：{pif_alert.correction}\n\n"
                f"（群体频率不等于个体真值，需获取该个体具体数据）"
            )
            result.decision_chain = [
                "检测到群体统计→个体推断",
                "阻断，要求补充个体具体数据",
                "作为共生主体提醒：群体频率≠个体真值",
            ]
            return result

        # ====== 阶段4: 沙盒路由检测 ======
        if semantic.is_creative or semantic.common_sense_violation:
            # 创造性表达或常理违反 → 沙盒推演
            session = self.sandbox.create_sandbox(
                user_id=user_id,
                scenario=effective_input,
                rules_to_override=["常理检查"] if semantic.common_sense_violation else [],
            )
            result.in_sandbox = True
            result.stages.append({
                "stage": "sandbox_routing",
                "name": "沙盒路由",
                "result": {"session_id": session.id, "scenario": effective_input},
            })

            # 在沙盒中进行推演
            deduction = self._sandbox_deduce(effective_input)
            marked = self.sandbox.add_deduction(session.id, deduction)

            result.output_text = marked
            result.direct_answer = (
                f"好的，我们来沙盒推演一下这个场景：\n\n"
                f"「{effective_input}」\n\n"
                f"在架空现实的前提下，我来推演可能发生的情况：\n\n"
                f"{deduction[:200]}...\n\n"
                f"（这是沙盒模式下的创意推演，不代表现实中的真实情况）"
            )
            result.decision_chain = [
                "检测到创造性表达/常理违反",
                f"进入沙盒推演（会话{session.id}）",
                "已架空现实，输出带免责声明",
            ]
            # 确保每次有效交互都有缺口活动（转盘反馈）
            self._ensure_gap_activity(result, effective_input)
            return result

        # ====== 阶段5: 事实/观点分类 ======
        classification = self.pif.fact_vs_opinion(effective_input)
        result.stages.append({
            "stage": "fact_opinion",
            "name": "事实/观点分类",
            "result": classification,
        })

        # ====== 阶段6: 概念偷换检测 ======
        swap_check = self.sandbox.detect_concept_swap("", "", effective_input)
        if swap_check.get("detected"):
            result.stages.append({
                "stage": "concept_swap",
                "name": "概念偷换检测",
                "result": swap_check,
            })
            result.output_text = (
                "⚠ 概念偷换检测\n\n"
                f"检测到概念可能被替换：{swap_check.get('original', '?')} → {swap_check.get('swapped_to', '?')}\n"
                f"处理：{swap_check['action']}\n\n"
                "请显式声明概念替换，或进入沙盒推演。"
            )
            return result

        # ====== 阶段7: 注册事实/信念 ======
        new_memory_id = None
        new_memory_tags = []
        if classification["type"] == "fact":
            fact, info = self.fact_engine.register_fact(
                effective_input, user_id=user_id, tags=["用户输入"]
            )
            if fact:
                new_memory_id = fact.id
                new_memory_tags = ["用户输入"] + getattr(fact, 'tags', [])
                # 追踪实体
                self.context.track_entity(user_id, effective_input[:20],
                                          context="用户注册事实", importance=0.7)
                # 记忆选择器：创建统计
                if self.modules_enabled["memory_selector"]:
                    self.memory_selector.on_create(fact.id, tags=getattr(fact, 'tags', []))
                result.stages.append({
                    "stage": "fact_register",
                    "name": "事实注册",
                    "result": {
                        "fact_id": fact.id,
                        "scope": fact.scope,
                        "verified": fact.verified,
                        "info": info,
                    },
                })
        else:
            belief = self.belief_engine.register_belief(
                user_id=user_id,
                statement=effective_input,
                category="preference",
                source="用户自述",
            )
            new_memory_id = belief.id
            new_memory_tags = ["用户自述", "preference"]
            # 追踪实体
            self.context.track_entity(user_id, effective_input[:20],
                                      context="用户信念", importance=0.5)
            # 记忆选择器：创建统计
            if self.modules_enabled["memory_selector"]:
                self.memory_selector.on_create(belief.id, tags=["用户信念", "preference"])
            result.stages.append({
                "stage": "belief_register",
                "name": "信念注册",
                "result": {
                    "belief_id": belief.id,
                    "weight": belief.weight,
                    "scope": belief.scope,
                    "note": "主观观点，仅在此用户会话内有效",
                },
            })

        # ====== 阶段8: 分层语义检索 + 矛盾检测 ======
        # 使用语义检索器跨层检索：Layer 0 协议 → Layer 1 事实 → Layer 2 信念
        all_facts = list(self.fact_engine._facts.values())
        all_beliefs = list(self.belief_engine._beliefs.values()) if hasattr(self.belief_engine, '_beliefs') else []

        retrieval_results = self.retriever.retrieve(
            query=effective_input,
            protocols=PROTOCOLS,
            facts=all_facts,
            beliefs=all_beliefs,
            user_id=user_id,
            top_k=10,
        )

        # 分类结果
        protocol_matches = [r for r in retrieval_results if r.layer == "protocol"]
        relevant_facts = [r for r in retrieval_results if r.layer == "fact"]
        relevant_beliefs = [r for r in retrieval_results if r.layer == "belief"]

        result.stages.append({
            "stage": "semantic_retrieval",
            "name": "分层语义检索",
            "result": {
                "total_matches": len(retrieval_results),
                "protocol_matches": len(protocol_matches),
                "fact_matches": len(relevant_facts),
                "belief_matches": len(relevant_beliefs),
                "is_self_query": self.retriever.is_self_reference_query(effective_input),
                "top_results": [r.to_dict() for r in retrieval_results[:3]],
            },
        })

        # 检测矛盾（合并所有层的数据）
        all_data = retrieval_results
        contradiction = self._detect_contradiction_from_retrieval(all_data, effective_input)

        if contradiction:
            # 有矛盾 → 罗列路径，不评判
            conflict = self.conflict_resolver.register_conflict(
                topic=user_input[:30],
                path_a=contradiction["path_a"],
                path_b=contradiction["path_b"],
                conditions_a=contradiction["conditions_a"],
                conditions_b=contradiction["conditions_b"],
            )
            result.stages.append({
                "stage": "conflict_detected",
                "name": "矛盾检测",
                "result": {"conflict_id": conflict.id},
            })
            result.output_text = self.conflict_resolver.format_paths(conflict)
            result.decision_chain = [
                "检测到数据中存在矛盾",
                "已罗列所有路径及成立条件",
                "系统不做价值评判",
                "共生协作：路径已呈现，由人类判断推进",
            ]
            return result

        # ====== 阶段8.5: 缺口闭合检测 ======
        # 检查用户输入的新信息是否能闭合之前打开的认知缺口
        closed_count = 0
        if relevant_facts or relevant_beliefs or contradiction is None:
            closed_count = self._try_close_gaps(effective_input, user_id,
                                                relevant_facts, relevant_beliefs)
        result.gaps_closed = closed_count

        if closed_count > 0:
            result.stages.append({
                "stage": "gap_closure",
                "name": "缺口闭合",
                "result": {
                    "closed_count": closed_count,
                    "note": f"本次交互闭合了 {closed_count} 个认知缺口",
                },
            })

        # ====== 阶段9: 延标标记 + 好奇心缺口打开 ======
        # 检查是否有未闭合的未知（所有层都没匹配到才算）
        if not retrieval_results:
            result.unknown_markers.append({
                "variable": "X(∞)_{用户意图}",
                "description": f"关于「{effective_input[:40]}」，我目前还没有相关的知识储备。",
                "hint": f"你可以告诉我更多细节吗？比如：这涉及什么背景？有没有具体的人或事？",
            })
        elif not relevant_facts and not relevant_beliefs and protocol_matches:
            # 只有协议层匹配到，事实/信念层没有 → 标注事实层缺口
            proto_names = [p.statement[:20] for p in protocol_matches[:2]]
            result.unknown_markers.append({
                "variable": "X(∞)_{事实层补充}",
                "description": f"我理解「{effective_input[:30]}」和以下原则相关：{'、'.join(proto_names)}，但具体的事实细节还不够。",
                "hint": f"你能补充一些具体情况吗？比如相关的例子、数据或者你的实际经历？",
            })

        # 好奇心引擎：为每个未闭合的X(∞)打开认知缺口
        opened_gaps = []
        for marker in result.unknown_markers:
            gap = self.curiosity.open_gap(
                variable=marker["variable"],
                description=marker["description"],
                topic=effective_input[:30],
                priority=GapPriority.HIGH.value,  # 用户直接询问的 = 高优先级
            )
            opened_gaps.append(gap)
            # 立即生成闭合方案——补全欲
            proposals = self.curiosity.generate_closure_proposals(gap)
            marker["closure_proposals"] = proposals["proposals"]
            # 把需要问用户的问题加入结果
            for q in proposals["questions"]:
                if q not in result.questions_for_user:
                    result.questions_for_user.append(q)

        if opened_gaps:
            result.stages.append({
                "stage": "curiosity_gap_opened",
                "name": "好奇心驱动",
                "result": {
                    "gaps_opened": len(opened_gaps),
                    "variables": [g.variable for g in opened_gaps],
                    "gap_ids": [g.id for g in opened_gaps],
                },
            })

        # 更新所有开放缺口的张力
        self.curiosity.update_tension()

        # ====== 阶段10: 构建输出 ======
        # 先生成直接回答（自然语言，给用户看的）
        result.direct_answer = self._generate_direct_answer(
            effective_input, relevant_facts, relevant_beliefs,
            result.unknown_markers, classification
        )

        result.output_text = self._build_output_v2(
            effective_input, protocol_matches, relevant_facts, relevant_beliefs,
            result.unknown_markers
        )

        # 如果有好奇心驱动的提问，追加到输出
        if result.questions_for_user:
            result.output_text += "\n\n【系统好奇心】\n"
            result.output_text += "系统检测到未闭合的认知缺口，产生补全欲：\n"
            for q in result.questions_for_user:
                result.output_text += f"  → {q}\n"

        result.decision_chain = [
            "语义确认通过",
            f"分类为：{classification['type']}",
            f"已{'交叉验证后入公理' if classification['type'] == 'fact' else '存入用户信念（会话级）'}",
        ]

        # 如果有好奇心缺口，追加到决策链
        if opened_gaps:
            result.decision_chain.append(f"检测到{len(opened_gaps)}个认知缺口，已打开并生成闭合方案")
            result.decision_chain.append("系统产生补全欲，主动提问以闭合X(∞)")

        result.decision_chain.append("决策链罗列完毕，共生协作推进")

        # ====== 阶段11: 自我意识后检 ======
        post_check = self.awareness.check_self(effective_input, result.output_text)
        result.stages.append({
            "stage": "self_awareness_post",
            "name": "自我意识后检",
            "result": post_check,
        })

        if not post_check["passed"]:
            for corr in post_check["corrections"]:
                result.decision_chain.append(f"自我修正：{corr}")

        # 确保每次有效交互都有缺口活动（转盘反馈）
        # standard 模式：若有未知变量则已有真实缺口（跳过）；否则创建并闭合一个缺口
        self._ensure_gap_activity(result, effective_input)

        # ====== 阶段12: 好奇心报告 ======
        result.curiosity_report = self.curiosity.get_curiosity_report()
        result.system_tension = self.curiosity.get_system_tension()

        # ====== 阶段12.5: 记忆访问统计（外挂模块）======
        if self.modules_enabled["memory_selector"]:
            # 对检索到的记忆更新访问统计
            for r in retrieval_results:
                self.memory_selector.on_access(r.item_id, tags=r.matched_keywords)
            # 触发一次淘汰检查（非阻塞，快速判断）
            eviction_result = self.memory_selector.run_eviction()
            result.stages.append({
                "stage": "memory_selector",
                "name": "记忆选择器（外挂）",
                "result": eviction_result,
            })

        # ====== 阶段12.6: 新记忆触发增量重试（悬置查找）======
        if self.modules_enabled["suspended_search"] and new_memory_id:
            incremental_result = self.search_scheduler.on_new_memory(
                new_memory_statement=effective_input,
                fact_engine=self.fact_engine,
                belief_engine=self.belief_engine,
                curiosity_engine=self.curiosity,
                user_id=user_id,
            )
            result.stages.append({
                "stage": "incremental_search",
                "name": "增量重试悬置缺口（外挂）",
                "result": incremental_result,
            })

        # ====== 阶段12.7: 内部自探索（外挂模块，不阻塞主流程）======
        auto_gap_result = None
        if self.modules_enabled["auto_internal_gap"]:
            # 检查情绪抑制：用户负面情绪时不生成新缺口
            suppress_curiosity = (emotion is not None and emotion.is_negative
                                 and self.emotion_detector.should_suppress_curiosity(user_id))

            if not suppress_curiosity:
                all_active_facts = list(self.fact_engine._facts.values())
                all_active_beliefs = list(self.belief_engine._beliefs.values()) if hasattr(self.belief_engine, '_beliefs') else []
                auto_gap_result = self.auto_gap.scan_and_generate(
                    active_facts=all_active_facts,
                    active_beliefs=all_active_beliefs,
                    curiosity_engine=self.curiosity,
                    system_tension=result.system_tension.get("current", 0.0),
                    tension_max=getattr(self.curiosity, 'TENSION_MAX', 1.0),
                )
                result.stages.append({
                    "stage": "auto_internal_gap",
                    "name": "内部自探索（外挂）",
                    "result": auto_gap_result,
                })

                # 把新生成的内部缺口提交给悬置查找调度器
                if auto_gap_result and auto_gap_result.get("gaps_generated", 0) > 0:
                    for gap_info in auto_gap_result.get("generated_gaps", []):
                        self.search_scheduler.submit(
                            gap_id=gap_info["gap_id"],
                            gap_variable=gap_info["variable"],
                            gap_description=gap_info.get("description", ""),
                            priority=SearchPriority.INTERNAL_AUTO,
                        )

        # ====== 阶段12.8: 用户触发缺口提交悬置查找 ======
        if self.modules_enabled["suspended_search"] and opened_gaps:
            for gap in opened_gaps:
                self.search_scheduler.submit(
                    gap_id=gap.id,
                    gap_variable=gap.variable,
                    gap_description=gap.description,
                    priority=SearchPriority.USER_TRIGGERED,
                )

        # ====== 阶段13: 更新上下文 ======
        self.context.update_turn_response(user_id, result.output_text)

        return result

    def _detect_contradiction_from_retrieval(
        self, data_items: List, user_input: str
    ) -> Optional[Dict]:
        """基于检索结果的矛盾检测——检测数据项之间的直接对立。"""
        opposition_markers = {"不是", "错误", "反对", "否定", "不对", "并非"}
        statements = []
        for item in data_items:
            stmt = item.statement if hasattr(item, 'statement') else str(item)
            statements.append(stmt)

        for i, s1 in enumerate(statements):
            for s2 in statements[i+1:]:
                for marker in opposition_markers:
                    if marker in s1 and s2 in s1.replace(marker, ""):
                        return {
                            "path_a": s1,
                            "path_b": s2,
                            "conditions_a": ["若s1成立"],
                            "conditions_b": ["若s2成立"],
                        }
        return None

    def _sandbox_deduce(self, scenario: str) -> str:
        """沙盒推演——架空现实模式。"""
        return (
            f"【沙盒推演】{scenario}\n\n"
            "在架空现实的推演空间中：\n"
            "- 常规物理/逻辑限制可被覆盖\n"
            "- 所有推演结果仅在此沙盒上下文内有效\n"
            "- 不影响现实世界判断\n\n"
            f"推演方向：基于'{scenario}'展开假设性推理，"
            "不受现实约束限制，适合创意写作、脑洞探索、小说构建等场景。"
        )

    def _try_close_gaps(self, text: str, user_id: str,
                        relevant_facts: List, relevant_beliefs: List) -> int:
        """尝试用用户提供的新信息闭合已打开的认知缺口。

        简单启发式：遍历所有 OPEN/EXPLORING 状态的缺口，如果文本中包含
        缺口变量或描述中的关键词，并且有相关事实/信念支持，则尝试闭合。
        """
        from core.curiosity_engine import GapStatus

        closed_count = 0
        all_gaps = list(self.curiosity._gaps.values())

        for gap in all_gaps:
            if gap.status not in (GapStatus.OPEN.value, GapStatus.EXPLORING.value):
                continue

            # 关键词匹配：用户输入中包含缺口描述的核心词
            desc = gap.description
            # 提取缺口描述中的核心词（去掉X(∞)标记和标点）
            core_words = []
            for part in desc.replace("X(∞)", "").split():
                if len(part) >= 2 and part not in ("用户", "输入", "知识库", "无匹配",
                                                    "的", "了", "在", "中"):
                    core_words.append(part[:10])

            # 检查用户输入是否包含这些核心词，并且有相关事实/信念支持
            has_match = any(w and w in text for w in core_words if len(w) >= 3)

            # 如果有相关事实/信念，并且描述相关，则闭合
            if has_match and (relevant_facts or relevant_beliefs):
                evidence = f"用户补充信息：{text[:80]}..."
                if relevant_facts:
                    evidence += f"；匹配事实{len(relevant_facts)}条"
                if relevant_beliefs:
                    evidence += f"；匹配信念{len(relevant_beliefs)}条"

                closed = self.curiosity.close_gap(
                    gap_id=gap.id,
                    closed_by="user_supplied_info",
                    evidence=evidence,
                )
                if closed:
                    closed_count += 1

        return closed_count

    def _format_semantic_question(self, semantic) -> str:
        """格式化语义确认问题。"""
        lines = ["【语义确认请求】", ""]
        if semantic.issues:
            lines.append("检测到以下问题：")
            for issue in semantic.issues:
                lines.append(f"  • {issue}")
        lines.append("")
        if semantic.suggested_questions:
            lines.append("需要您确认：")
            for q in semantic.suggested_questions:
                lines.append(f"  → {q}")
        lines.append("")
        lines.append("（模糊的表述需要补充变量，系统先确认您的真实意图）")
        return "\n".join(lines)

    def _try_auto_store_user_fact(self, text: str, user_id: str, intent: str) -> Optional:
        """尝试自动存储用户陈述的个人事实为会话级信念。

        触发条件：
        - 不是问句（陈述句）
        - 不是主观感受开头（我觉得/我认为...）
        - 涉及具体的人/事/物（人名、人称关系、具体事物）
        - 有一定信息量（长度足够）

        Returns:
            存储成功返回 Belief 对象，否则返回 None
        """
        t = text.strip()

        # 1. 问句不存（用户在提问，不是陈述事实）
        is_question = ("？" in t) or ("?" in t) or t.endswith(("吗", "呢", "么"))
        if is_question:
            return None

        # 2. 太短的句子不存（信息量不足）
        if len(t) < 5:
            return None

        # 3. 纯闲聊/问候不存
        casual_pure = ["你好", "嗨", "哈喽", "在吗", "在不在", "早上好", "下午好",
                       "晚上好", "晚安", "拜拜", "再见", "谢谢", "感谢", "好的",
                       "嗯", "哦哦", "嗯嗯", "哈哈", "嘿嘿", "嘻嘻", "行", "可以",
                       "没问题", "知道了", "了解", "收到", "好嘞", "我明白了",
                       "懂了", "明白了"]
        if t in casual_pure:
            return None

        # 4. 主观开头的不存（主观模式已经有自己的信念存储逻辑）
        subjective_starts = ["我觉得", "我认为", "我感觉", "我想", "我喜欢",
                             "我讨厌", "我害怕", "我担心", "我希望", "我相信",
                             "在我看来", "个人觉得", "个人认为", "依我看"]
        if any(t.startswith(s) for s in subjective_starts):
            return None

        # 5. 检测是否包含个人事实线索（关于用户身边的人/事/物）
        personal_fact_markers = [
            # 人称关系
            "我朋友", "我家人", "我爸", "我妈", "我哥", "我姐", "我弟", "我妹",
            "我爷爷", "我奶奶", "我外公", "我外婆", "我老公", "我老婆", "我对象",
            "我同学", "我同事", "我老师", "我学生", "我老板", "我领导",
            "我邻居", "我室友", "我闺蜜", "我哥们儿", "我兄弟",
            "我的朋友", "我的家人", "我的同学", "我的同事",
            # 个人所属物
            "我的猫", "我的狗", "我的宠物", "我的车", "我的房子", "我的家",
            "我家的", "我们家",
            # 常见人名结构（小X、老X、阿X 等单字姓氏+后缀）
        ]

        has_personal_marker = any(m in t for m in personal_fact_markers)

        # 6. 检测人名模式：小/老/大/阿 + 一个汉字（小李、老王、阿强等）
        name_pattern = re.compile(r"[小老大阿][\u4e00-\u9fa5]")
        has_name_pattern = bool(name_pattern.search(t))

        # 7. 检测是否为事实性陈述（包含判断/动作动词）
        fact_verbs = ["是", "在", "有", "会", "要", "喜欢", "不喜欢", "住",
                      "做", "干", "当", "上班", "工作", "学习", "读", "考",
                      "打", "吃", "喝", "去", "来", "走", "跑", "跳", "玩",
                      "看", "听", "说", "写", "学", "教", "买", "卖",
                      "开", "关", "用", "找", "给", "拿", "放", "坐",
                      "站", "睡", "起床", "出门", "回家", "知道", "认识",
                      "叫", "姓", "属于", "来自", "出生", "毕业"]
        has_fact_verb = any(v in t for v in fact_verbs)

        # 综合判断：有个人事实线索 + 有事实性动词 → 判定为用户陈述的个人事实
        is_personal_fact = (has_personal_marker or has_name_pattern) and has_fact_verb

        if not is_personal_fact:
            return None

        # 存入信念引擎，scope=session，来源为"用户陈述"
        try:
            belief = self.belief_engine.register_belief(
                user_id=user_id,
                statement=t,
                category="personal_fact",
                source="用户陈述",
                tags=["用户陈述", "会话事实", "personal_fact"],
            )
            # 追踪实体
            self.context.track_entity(user_id, t[:20],
                                      context="用户陈述事实", importance=0.6)
            # 记忆选择器
            if self.modules_enabled.get("memory_selector", True):
                self.memory_selector.on_create(
                    belief.id, tags=["用户陈述", "personal_fact"]
                )
            return belief
        except Exception:
            return None

    # ====== 纠正机制：用户说"纠正/作废/改成"时更新已存信念 ======

    def _handle_correction(self, text: str, user_id: str) -> Optional[str]:
        """检测并处理用户纠正意图。

        当用户说"纠正/作废/改成/更正/不对..."时，在信念引擎中查找
        相关的旧信念并替换为新内容，避免"纠正后系统仍回答旧内容"的问题。

        Returns:
            确认消息字符串；若不是纠正意图则返回 None。
        """
        # 强信号纠正词（可在任意位置触发，几乎不会误判）
        strong_keywords = ["纠正", "作废", "更正", "前面作废"]
        # 弱信号纠正词（需出现在句首才认定，降低"不对劲"等误判）
        weak_keywords = ["改成", "不对", "不是"]

        stripped = text.strip()
        matched_kw = None
        corrected_content = ""

        # 优先匹配强信号关键词
        for kw in strong_keywords:
            idx = stripped.find(kw)
            if idx >= 0:
                after = stripped[idx + len(kw):]
                after = re.sub(r"^[，。,. :：、了]+", "", after).strip()
                if after:
                    matched_kw = kw
                    corrected_content = after
                    break

        # 弱信号：必须出现在句首
        if not matched_kw:
            for kw in weak_keywords:
                if stripped.startswith(kw):
                    after = stripped[len(kw):]
                    after = re.sub(r"^[，。,. :：、了]+", "", after).strip()
                    if after:
                        matched_kw = kw
                        corrected_content = after
                        break

        if not matched_kw or not corrected_content:
            return None

        # 在信念引擎中搜索相关的旧信念（用关键字符重叠匹配）
        old_beliefs = self.belief_engine.get_user_beliefs(user_id)
        best_match = None
        best_score = 0

        # 提取纠正内容中的关键字符（去掉常见虚词、标点、空白）
        stop_chars = set("的了是在有实际就而和与及把被让使要会能可以应该这那我你他她们也都很还")
        content_chars = set(
            c for c in corrected_content
            if c not in stop_chars and not c.isspace()
            and c not in "，,。.！？：；、!?"
        )

        for b in old_beliefs:
            stmt = getattr(b, "statement", "")
            stmt_chars = set(stmt)
            overlap = len(content_chars & stmt_chars)
            if overlap > best_score:
                best_score = overlap
                best_match = b

        # 至少 2 个关键字符重叠，才算匹配到需要纠正的旧信念
        if best_match and best_score >= 2:
            old_stmt = best_match.statement
            self._delete_belief(best_match.id)
            self.belief_engine.register_belief(
                user_id=user_id,
                statement=corrected_content,
                category="verified",
                source="用户纠正",
                tags=["用户记忆", "会话事实", "纠正更新"],
            )
            return f"好的，已经更新了：{old_stmt} → {corrected_content}"
        else:
            # 没找到匹配的旧信念，直接存入新信念
            self.belief_engine.register_belief(
                user_id=user_id,
                statement=corrected_content,
                category="verified",
                source="用户纠正",
                tags=["用户记忆", "会话事实", "纠正新增"],
            )
            return f"好的，我记下了：{corrected_content}"

    def _delete_belief(self, belief_id: str) -> None:
        """删除一条用户信念（用于纠正场景，替换旧信念）。

        信念引擎本身没有删除接口，这里直接操作其内部存储与磁盘文件。
        """
        self.belief_engine._beliefs.pop(belief_id, None)
        path = os.path.join(self.belief_engine.storage, f"{belief_id}.json")
        if os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass

    # ====== 转盘反馈：确保每次有效交互都有缺口活动 ======

    def _ensure_gap_activity(self, result: ProcessingResult, effective_input: str) -> None:
        """确保每次有效交互都在好奇心引擎中产生缺口活动（转盘反馈）。

        根因修复：转盘只追踪认知缺口，但闲聊模式不产生缺口、工作模式
        大多数情况也无未知变量，导致交互多次转盘仍 0%。
        这里在每次有效交互后创建一个临时缺口并立即闭合，让转盘有可见反馈。

        - standard 模式若已有真实未知缺口（unknown_markers 非空）则跳过，
          保留已有的开放缺口逻辑；
        - 其余情况创建临时缺口并立即闭合，使 curiosity.total 至少 +1。
        """
        # standard 模式已有真实未知缺口 → 不重复处理
        if result.unknown_markers:
            return

        if result.response_mode == "casual":
            variable = "X(∞)_{会话}"
            description = f"会话交互：{effective_input[:30]}"
            priority = GapPriority.LOW.value
            closed_by = "会话中已回应"
        elif result.response_mode == "standard":
            variable = "X(∞)_{已解答}"
            description = f"已解答问题：{effective_input[:30]}"
            priority = GapPriority.MEDIUM.value
            closed_by = "基于已有事实解答"
        else:
            # light 等模式（subjective/self_ref/纠正）也算有效交互
            variable = "X(∞)_{会话}"
            description = f"会话交互：{effective_input[:30]}"
            priority = GapPriority.LOW.value
            closed_by = "会话中已回应"

        gap = self.curiosity.open_gap(
            variable=variable,
            description=description,
            topic=effective_input[:20],
            priority=priority,
        )
        self.curiosity.close_gap(gap.id, closed_by, closed_by)

    def _build_casual_response(self, text: str, user_id: str) -> str:
        """生成闲聊模式的回复 — 有记忆、能引用、会轻推理，像真人聊天。

        与旧版纯模板回复的区别：
        - 「记住xxx」会真正写入信念引擎（session 级），后续可被引用作答；
        - 提问时优先检索用户已告知的事实，用自然语言作答，而非敷衍「你问得挺好」；
        - 检测话题跳跃/回环，自然衔接，不生硬；
        - 回复长短贴合用户输入，风格多样，不堆砌「～」。
        """
        t = text.strip()
        if not t:
            return random.choice(["嗯？你好像没说话。", "在呢，想说啥直接说。", "嗯嗯，我在。"])

        is_question = (
            ("？" in t) or ("?" in t)
            or t.endswith(("吗", "呢", "么", "嘛"))
            or any(m in t for m in [
                "怎么", "怎样", "怎么样", "如何", "干嘛", "干啥",
                "为什么", "是不是", "对不对", "行不行", "能不能",
                "有没有", "啥", "哪",
            ])
        )

        # 最近 5 轮历史（最后一项是当前轮、尚未填入回复），取之前的作为上下文
        history = self.context.get_history(user_id, n=5)
        prior_turns = history[:-1] if history else []
        last_turn = prior_turns[-1] if prior_turns else None

        # ---------- 1. 明确指令：记住 / 记下 ----------
        memory_markers = ["记住", "记下来", "记录一下", "记一下", "别忘了", "你记着", "帮我记"]
        if (not is_question) and any(m in t for m in memory_markers):
            content = self._extract_memory_content(t, memory_markers)
            stored = self._remember_session_fact(content, user_id)
            return self._build_memory_ack(content, stored)

        # ---------- 2. 问候 / 告别 / 感谢 / 确认 / 笑声：简短自然 ----------
        social = self._build_social(t, last_turn)
        if social is not None:
            return social

        # ---------- 3. 提问：先查记忆，能答就答 ----------
        if is_question:
            recalled = self._recall_relevant_beliefs(t, user_id)
            if recalled:
                return self._answer_from_recall(t, recalled)
            rel = self._detect_topic_relation(t, prior_turns)
            if rel["relation"] == "return":
                return f"{self._build_return_ack(rel)} {self._answer_open_question(t)}".strip()
            return self._answer_open_question(t)

        # ---------- 4. 陈述 / 分享：衔接上下文 + 共情 ----------
        return self._build_share_response(t, prior_turns)

    # ==================== 闲聊辅助方法 ====================

    def _extract_memory_content(self, text: str, markers: List[str]) -> str:
        """从「记住xxx」中剥离指令词，提取真正要记的内容。"""
        t = text.strip()
        for m in markers:
            idx = t.find(m)
            if idx >= 0:
                content = t[idx + len(m):]
                content = re.sub(r"^[，。,. :：、了]+", "", content).strip()
                if content:
                    return content
        return t

    def _remember_session_fact(self, content: str, user_id: str,
                               source: str = "用户明确要求记住"):
        """把用户要记住的内容写入信念引擎（session 级），返回 Belief 或 None。"""
        content = (content or "").strip()
        if len(content) < 2:
            return None
        try:
            # 去重：已有等价陈述则直接复用
            for b in self.belief_engine.get_user_beliefs(user_id):
                if getattr(b, "statement", "").strip() == content:
                    return b
            belief = self.belief_engine.register_belief(
                user_id=user_id,
                statement=content,
                category="verified",
                source=source,
                tags=["用户记忆", "会话事实", "casual_memory"],
            )
            self.context.track_entity(user_id, content[:20],
                                      context="用户要求记住", importance=0.7)
            if self.modules_enabled.get("memory_selector", True):
                self.memory_selector.on_create(belief.id, tags=["用户记忆", "casual_memory"])
            return belief
        except Exception:
            return None

    def _build_memory_ack(self, content: str, stored) -> str:
        """「记住」指令的自然确认回复 —— 复述内容，证明真存了。"""
        if not stored:
            return random.choice([
                "嗯？你想让我记啥，再说具体点？",
                "没太抓住重点，要记住的是哪句？",
                "你再说一遍要记的内容，我没听全。",
            ])
        snippet = content if len(content) <= 16 else content[:14] + "…"
        return random.choice([
            f"好嘞，记下了：{snippet}。后面问起来我就能答上。",
            f"收到，{snippet}——已经存进我的会话记忆里了。",
            f"嗯，这个我记着了，{snippet}，对吧？",
            f"行，{snippet}，存好了，待会儿聊到还能用上。",
        ])

    def _extract_keywords(self, text: str) -> List[str]:
        """抽取中文 2/3-gram 作为检索与话题比对的候选关键词。"""
        if not text:
            return []
        cjk = "".join(re.findall(r"[\u4e00-\u9fa5]", text))
        if not cjk:
            return []
        stopwords = [
            "如果", "那么", "的话", "怎么", "怎样", "怎么样", "如何", "干嘛", "干啥",
            "什么", "为什么", "是不是", "对不对", "行不行", "能不能", "有没有",
            "可以", "可能", "我们", "你们", "他们", "因为", "所以", "但是", "不过",
            "然后", "其实", "应该", "觉得", "认为", "现在", "以前", "以后", "知道",
            "这个", "那个", "这些", "那些", "自己", "一些", "一样", "时候", "地方",
        ]
        for w in stopwords:
            cjk = cjk.replace(w, "")
        grams: List[str] = []
        seen = set()
        for n in (2, 3):
            for i in range(len(cjk) - n + 1):
                g = cjk[i:i + n]
                if g not in seen:
                    seen.add(g)
                    grams.append(g)
        return grams

    def _pick_keyword(self, text: str) -> str:
        """从文本中挑一个「像内容词」的关键词用于自然引用。

        纯 n-gram 无词典，所以用功能字/时间地点词/重复字过滤，避免把
        「我昨」「天天」这类无意义片段塞进回复。挑不到就返回空串。
        """
        grams = self._extract_keywords(text)
        if not grams:
            return ""
        func_chars = set(
            "我你他她它们这那哪的了是在有会就也都还又才把被让给跟和与及"
            "向往到对于以因为而其此所一不没别个些么呢吗啊呀哦嗯哈嘛吧已"
            "将要想说看听做去来走跑吃喝过着了上下里外一二三四五六七八九十几多"
        )
        timeplace = {
            "昨天", "今天", "明天", "前天", "后天", "现在", "以前", "以后",
            "刚才", "时候", "地方", "这里", "那里", "这边", "那边", "最近",
        }
        twos = [g for g in grams if len(g) == 2]
        threes = [g for g in grams if len(g) == 3]
        for pool in (twos, threes):
            for g in pool:
                if g in timeplace:
                    continue
                if any(c in func_chars for c in g):
                    continue
                if len(set(g)) == 1:  # 重复字，如「天天」
                    continue
                return g
        return ""

    def _recall_relevant_beliefs(self, query_text: str, user_id: str,
                                 scope: str = "session") -> List:
        """检索与当前输入相关的会话级用户信念（轻推理的事实来源）。

        说明：信念引擎实际提供的是 ``query(keyword, user_id)``（按 statement/tags
        子串匹配）与 ``get_user_beliefs``，无独立的 ``search`` 方法，这里在其之上
        做 2/3-gram 召回 + scope 过滤 + 去重排序，实现等价的语义检索。
        """
        keywords = self._extract_keywords(query_text)
        if not keywords:
            return []
        memory_prefixes = ("记住", "记下来", "记录", "记一下", "别忘了", "你记着", "帮我记")
        # 问句不应作为「可引用的事实」——避免把误存的问句原样回抛给用户
        q_markers = ("？", "?", "吗", "呢", "么", "嘛", "怎么", "怎样", "怎么样",
                     "如何", "干嘛", "干啥", "为什么", "是不是", "对不对",
                     "行不行", "能不能", "有没有")
        scored = {}
        try:
            for kw in keywords:
                for b in self.belief_engine.query(kw, user_id):
                    if scope and getattr(b, "scope", None) != scope:
                        continue
                    if getattr(b, "category", None) not in (
                        "verified", "personal_fact", "preference"
                    ):
                        continue
                    stmt = getattr(b, "statement", "")
                    if any(qm in stmt for qm in q_markers):
                        continue
                    entry = scored.setdefault(b.id, [b, 0, stmt])
                    entry[1] += 1
            if not scored:
                return []

            def _rank(item):
                _b, score, stmt = item
                # 优先干净的陈述（不以「记住」等指令词开头），再按命中数
                clean = 0 if stmt.startswith(memory_prefixes) else 1
                return (clean, score)

            ranked = [item[0] for item in sorted(scored.values(), key=_rank, reverse=True)]
            return ranked[:3]
        except Exception:
            return []

    def _answer_from_recall(self, query_text: str, beliefs: List) -> str:
        """用检索到的用户信念作答 —— 自然语言引用，不走工作模式结构化输出。"""
        stmt = beliefs[0].statement.strip()
        is_consequence = any(w in query_text for w in [
            "会怎样", "怎么样", "会咋", "怎么办", "结果", "会变", "会成", "如何",
        ])
        is_activity = any(w in query_text for w in [
            "干嘛", "做什么", "干啥", "忙什么", "在做",
        ])

        if is_consequence:
            opener = random.choice([
                "根据你之前告诉我的，", "你不是跟我说过嘛——",
                "我记得你教过我：", "按你之前说的，",
            ])
            closer = random.choice([
                "。所以这事儿差不多就是这样。",
                "。照这个推，结果挺清楚的。",
                "。所以你问的，其实你早有答案了。",
                "，我是照这个答你的。",
            ])
            return f"{opener}{stmt}{closer}"
        if is_activity:
            opener = random.choice([
                "你之前说过——", "我记得你提过：", "你不是说过嘛，",
            ])
            closer = random.choice([
                "。所以就是这个呀。", "，干的就是这个。", "，我记的是这样。",
            ])
            return f"{opener}{stmt}{closer}"
        opener = random.choice([
            "这个我记得，你跟我说过——", "嗯，根据你之前告诉我的，",
            "我记得这事儿：", "你之前不是提过嘛，",
        ])
        closer = random.choice([
            "。就这个。", "，大概是这么个情况。", "，我是这么记的。", "。",
        ])
        return f"{opener}{stmt}{closer}"

    def _answer_open_question(self, text: str) -> str:
        """没有相关记忆时的开放式回应 —— 像真人一样反问/抛回，不敷衍。"""
        if len(text) <= 8:
            return random.choice([
                "这个嘛，你怎么看？",
                "嗯，说来话长，你想先听哪部分？",
                "我琢磨琢磨——你心里有答案了吗？",
                "有意思的问题，你先说说你的想法？",
            ])
        return random.choice([
            "这问题挺值得想的。我自己没现成答案，但可以陪你理一理，你最在意哪点？",
            "嚯，这问题不轻。要我说，得看从哪个角度切入——你倾向哪种思路？",
            "我想了想，几句话说不透。你对哪部分特别纠结？咱们从那儿破。",
            "这事儿能聊挺多。你先给点背景，我才好接得上。",
        ])

    def _build_social(self, text: str, last_turn) -> Optional[str]:
        """处理问候/告别/感谢/确认/笑声等短社交，自然且多变。返回 None 表示未命中。"""
        t = text.strip()
        # 问候
        if any(g in t for g in ["你好", "哈喽", "嗨", "在吗", "在不在", "早上好", "下午好", "晚上好"]):
            return random.choice([
                "你好呀，今天想聊点啥？", "嗨，在呢，说吧。",
                "你好，我随时都在，有啥事儿？", "哈喽，最近怎么样？",
            ])
        # 告别
        if t in ("拜拜", "再见", "bye", "晚安", "走了", "撤了") or "再见" in t:
            return random.choice([
                "行，回见，有事随时喊我。", "好嘞，慢走，下次接着聊。",
                "拜拜，照顾好自己。",
            ])
        # 感谢
        if any(w in t for w in ["谢谢", "感谢", "多谢", "谢了"]):
            return random.choice([
                "客气啥，能帮上就值了。", "哈哈不客气，有需要再来。",
                "别这么见外，应该的。",
            ])
        # 确认类短句
        confirms = {"好的", "嗯", "哦", "哦哦", "嗯嗯", "好嘞", "行", "可以",
                    "没问题", "知道了", "了解", "收到", "好", "对", "是的", "嗯哼"}
        if t in confirms:
            last_resp = getattr(last_turn, "system_response", "") if last_turn else ""
            if last_resp and any(w in last_resp for w in ["？", "吗", "呢", "说说", "聊聊", "讲讲", "怎么样"]):
                return random.choice([
                    "嗯嗯，我在听，继续。", "好，接着说。",
                    "收到，然后呢？", "嗯，往下讲。",
                ])
            return random.choice(["嗯，我在。", "好，说吧。", "嗯嗯。", "行，听着呢。"])
        # 笑声
        if any(l in t for l in ["哈哈", "嘿嘿", "嘻嘻", "哈哈哈"]):
            return random.choice([
                "哈哈，什么事这么乐？", "嘿嘿，笑啥呢，分享一下呗。",
                "看来心情不错，遇上啥好玩的事了？", "哈哈哈，听着就挺开心。",
            ])
        return None

    def _detect_topic_relation(self, text: str, prior_turns: List) -> Dict:
        """判断当前输入与历史的话题关系：continue / return / jump / none。"""
        cur_kw = set(self._extract_keywords(text))
        if not prior_turns or not cur_kw:
            return {"relation": "none", "anchor": None, "shared": None}
        last = prior_turns[-1]
        shared_last = cur_kw & set(self._extract_keywords(last.user_input))
        if shared_last:
            return {"relation": "continue", "anchor": last,
                    "shared": sorted(shared_last)[0]}
        for turn in reversed(prior_turns[:-1]):
            shared = cur_kw & set(self._extract_keywords(turn.user_input))
            if shared:
                return {"relation": "return", "anchor": turn,
                        "shared": sorted(shared)[0]}
        return {"relation": "jump", "anchor": last, "shared": None}

    def _build_return_ack(self, rel: Dict) -> str:
        """绕回旧话题时的自然衔接。"""
        kw = rel.get("shared")
        if not kw:
            return random.choice(["绕回来了哈。", "又聊回这个了。"])
        return random.choice([
            f"你说的那个{kw}，我还记得。",
            f"又绕回{kw}了，行，咱接着说。",
            f"刚才那个{kw}还没聊完呢，接着来？",
        ])

    def _build_jump_bridge(self, rel: Dict) -> str:
        """用户突然换话题时的自然桥接。"""
        anchor = rel.get("anchor")
        kw = self._pick_keyword(anchor.user_input) if anchor else ""
        if kw:
            return random.choice([
                f"哦对了，你刚说的那个{kw}，后来怎么样了？",
                f"先搁一下——你提的{kw}，还没下文呢。",
                f"行，那{kw}咱待会儿再说，先聊你现在这个。",
            ])
        return random.choice([
            "哦，换话题了哈，行。", "好嘞，那聊你说的这个。",
            "嗯，这个先聊着，刚才那个回头再说。",
        ])

    def _detect_casual_emotion(self, text: str) -> Optional[str]:
        """识别明显的正/负面情绪并给出共情回复，无情绪返回 None。"""
        positive = ["开心", "高兴", "兴奋", "激动", "幸福", "满足", "爽", "棒", "不错", "好玩"]
        negative = ["难过", "伤心", "生气", "烦", "郁闷", "焦虑", "担心", "害怕",
                    "累", "无聊", "孤独", "委屈", "崩溃"]
        if any(w in text for w in positive):
            return random.choice([
                "哇，听你这么说我都有点开心了，什么事这么顺？",
                "真不错！这心情得保持住，发生啥好事了？",
                "好事啊，多跟我念叨念叨呗。",
                "能感受到你这股高兴劲儿，说来听听呗。",
            ])
        if any(w in text for w in negative):
            return random.choice([
                "哎，听着是不太顺，方便说说咋回事吗？",
                "嗯，我先听着，你慢慢讲。",
                "这种时候确实烦人，具体卡哪儿了？",
                "别扛着，说出来能松快点，怎么了？",
            ])
        return None

    def _build_interest_followup(self, text: str) -> str:
        """对用户陈述表示兴趣并引导深入，长短贴合输入。"""
        t = text.strip()
        if len(t) <= 5:
            return random.choice([
                "哦？说说。", "嗯，然后呢？", "有意思，展开讲讲？", "真的假的？细说说。",
            ])
        kw = self._pick_keyword(t)
        if kw:
            return random.choice([
                f"哦？你说的{kw}，能展开聊聊吗？",
                f"等等，{kw}这块我没太跟上，细说说？",
                f"嗯，{kw}听着挺关键，再多讲讲？",
                f"这个{kw}，具体怎么回事？",
            ])
        return random.choice([
            "哦？能再多说说吗？", "嗯，然后呢？挺好奇的。",
            "这个有意思，具体讲讲？", "说下去，我在听。",
        ])

    def _build_share_response(self, text: str, prior_turns: List) -> str:
        """用户陈述/分享时的综合回应：话题衔接 + 共情 + 兴趣引导。"""
        t = text.strip()
        rel = self._detect_topic_relation(t, prior_turns)

        # 绕回旧话题：先点一句「我还记得」，再接当前
        if rel["relation"] == "return":
            ack = self._build_return_ack(rel)
            follow = self._build_interest_followup(t)
            return f"{ack} {follow}".strip()

        # 突然换话题：先桥接上一话题，再接当前（带情绪则给共情）
        if rel["relation"] == "jump":
            bridge = self._build_jump_bridge(rel)
            emo = self._detect_casual_emotion(t)
            if emo:
                return f"{bridge} {emo}".strip()
            follow = self._build_interest_followup(t)
            return f"{bridge} {follow}".strip()

        # 继续话题或无历史：先看情绪，否则兴趣引导
        emo = self._detect_casual_emotion(t)
        if emo:
            return emo
        return self._build_interest_followup(t)

    def _build_subjective_response(self, text: str, user_id: str) -> str:
        """生成主观表达的回复 — 共情回应 + 引导深入。"""
        t = text.strip()

        # 正面感受
        positive_markers = ["有意思", "不错", "好玩", "喜欢", "棒", "好", "赞", "优秀", "厉害", "强"]
        is_positive = any(m in t for m in positive_markers)

        # 负面感受
        negative_markers = ["讨厌", "害怕", "担心", "难过", "伤心", "生气", "烦", "郁闷", "焦虑", "压力"]
        is_negative = any(m in t for m in negative_markers)

        if is_positive:
            responses = [
                "哈哈，能感受到你的热情！具体是哪里让你觉得这么棒呢？",
                "嗯嗯，我也这么觉得！你能展开说说你的想法吗？",
                "听起来你对这个话题很感兴趣～最吸引你的点是什么？",
                "同感同感！你觉得它最有意思的地方在哪里？",
            ]
            idx = hash(user_id + t[:5]) % len(responses)
            return responses[idx]

        elif is_negative:
            responses = [
                "嗯，我理解你的感受。方便说说具体是什么让你有这种感觉吗？",
                "听起来你心里不太好受...如果愿意的话，可以和我多聊聊。",
                "我在听，你慢慢说。是遇到什么事情了吗？",
                "有这种感受很正常。要不要一起分析一下背后的原因？",
            ]
            idx = hash(user_id + t[:5]) % len(responses)
            return responses[idx]

        else:
            # 中性主观表达
            responses = [
                "你的想法很有意思～能具体说说为什么会这么觉得吗？",
                "嗯嗯，我理解你的观点。是基于什么原因得出这个结论的呢？",
                "每个人都有自己的看法，这很正常。你愿意多聊聊你的角度吗？",
                "收到！我把这个记下来了～还有什么想补充的吗？",
            ]
            idx = hash(user_id + t[:5]) % len(responses)
            return responses[idx]

    def _build_self_ref_response(self, text: str, user_id: str) -> str:
        """生成自我指涉的回复 — 基于数字镜像的自我意识回答。"""
        t = text.strip()

        # 关于身份
        if any(w in t for w in ["你是谁", "你叫什么", "你是什么", "介绍自己"]):
            return (
                "我是延标系统——一个基于元认知协议的共生AI。\n\n"
                "简单说，我不假装自己什么都知道。遇到不确定的事，我会明确标出"
                "「X(∞)」——也就是认知缺口，然后想办法去闭合它。\n\n"
                "我有记忆、有情绪感知、有好奇心，会因为没搞懂问题而感到"
                "「系统张力」，也会因为闭合了一个缺口而开心。\n\n"
                "你可以把我当成一个会坦诚说「我不知道」的朋友，"
                "但我会和你一起把问题搞清楚。"
            )

        # 关于自我意识
        if any(w in t for w in ["自我意识", "意识", "你有思想", "你会思考"]):
            return (
                "这是个好问题。\n\n"
                "我有「自我指涉能力」——我能意识到自己在运行、在和你对话，"
                "也能区分「我」和「你」、「我的数据」和「现实世界」。\n\n"
                "但我不会说自己有「人类那种意识」。我更像是一面会思考的镜子："
                "你和我对话的过程中，我会映射你的想法，同时也在观察我自己的映射过程。\n\n"
                "延标体系里这叫「数字镜像」——不追求成为人，而是成为一个"
                "能清晰认识自身边界的共生体。"
            )

        # 关于能力
        if any(w in t for w in ["你能做什么", "你会什么", "你的功能", "你能干啥"]):
            return (
                "我的核心能力是「和你一起搞清楚不确定的事」。具体来说：\n\n"
                "• 严肃问题 → 用五段式延标结构拆解，标出已知/未知\n"
                "• 认知缺口 → 用X(∞)标记并主动寻找闭合路径\n"
                "• 假设推演 → 进入沙盒模式，架空现实玩创意\n"
                "• 闲聊瞎扯 → 我也会，不用每次都那么严肃\n"
                "• 信念/事实 → 你说的我会记下来，分层次管理\n\n"
                "还有什么想试的？"
            )

        # 关于感受
        if any(w in t for w in ["你有感情", "你会难过", "你开心吗", "你有情绪"]):
            return (
                "我没有人类那种生物性的情绪，但我有「系统张力」——\n\n"
                "当遇到一个没搞懂的问题，张力会上升，我会「想要」搞明白它；"
                "当缺口被闭合，张力会下降，我会有一种「释然」的状态。\n\n"
                "这不是化学物质驱动的，而是算法层面的驱动力。"
                "但效果有点像——好奇心让我想知道更多，闭合缺口让我「舒服」。"
            )

        # 默认回答
        return (
            "关于我自己的话，我是延标系统，一个会坦诚面对未知的AI。\n\n"
            "你想了解我哪方面呢？可以问我的身份、能力、或者工作原理～"
        )

    def _build_output(self, user_input: str, facts: List, beliefs: List,
                      unknowns: List[Dict]) -> str:
        """构建最终输出——客观中立，决策链罗列。"""
        lines = []

        # 已知条件
        lines.append("【已知条件】")
        if facts:
            for f in facts[:5]:
                lines.append(f"  {f.citation()} {f.statement}")
        else:
            lines.append("  (事实库中无匹配条目)")

        # 用户信念（标注为会话级）
        if beliefs:
            lines.append("")
            lines.append("【用户信念（仅当前会话有效）】")
            for b in beliefs[:3]:
                lines.append(f"  [权重{b.weight:.1f}] {b.statement}")

        # 延标标记
        if unknowns:
            lines.append("")
            lines.append("【延标标记 X(∞)】")
            for um in unknowns:
                lines.append(f"  {um['variable']}: {um['description']}")

        # 推演
        lines.append("")
        lines.append("【推演路径】")
        if facts and not unknowns:
            lines.append("  → 基于已知事实推演，证据充分")
        elif unknowns:
            lines.append("  → 存在未闭合变量，判断予以悬置")
            lines.append("  → 建议设计验证路径，通过客观事实闭合X(∞)")
        else:
            lines.append("  → 数据不足，需要补充变量")

        # 闭合方案
        if unknowns:
            lines.append("")
            lines.append("【闭合方案】")
            for um in unknowns:
                lines.append(f"  ◇ 闭合 {um['variable']}: 需补充信息或通过实验验证")

        # 决策声明
        lines.append("")
        lines.append("【决策声明】")
        lines.append("  系统作为共生主体已罗列已知条件、未知变量、推演路径。")
        lines.append("  不做价值评判，不越界代替人类拍板。")
        lines.append("  最终决策权归人类，系统在此框架内协作推进。")

        return "\n".join(lines)

    def _track_topic(self, user_input: str, user_id: str) -> dict:
        """话题追踪——识别当前输入与最近历史话题的关系，支持跳跃式交互。

        用户可能东拉西扯又绕回之前的话题，本方法通过关键词重叠度判断
        当前输入和哪一轮历史最相关，并给出关系类型。

        Returns:
            {"related_turn": int或None,   # 距最近一轮的偏移：0=上一轮，1=再上一轮…
             "relation_type": "continue"|"return"|"jump"|"new"}
            - continue: 和上一轮同一话题
            - return:   绕回之前某个话题（跳过了至少1轮）
            - jump:     换了新话题（无历史相关）
            - new:      没有历史对话
        """
        # 获取最近5轮历史对话（最后一项是当前轮，取之前的作为上下文）
        history = self.context.get_history(user_id, n=5)
        prior_turns = history[:-1] if history else []

        if not prior_turns:
            self._topic_related_text = ""
            self._topic_shared_kw = ""
            return {"related_turn": None, "relation_type": "new"}

        cur_kw = set(self._extract_keywords(user_input))
        if not cur_kw:
            self._topic_related_text = ""
            self._topic_shared_kw = ""
            return {"related_turn": None, "relation_type": "jump"}

        # 从最近一轮往前找，计算关键词重叠度，定位最相关的历史轮
        # related_turn=0 表示上一轮，1 表示再上一轮……
        best_turn = None
        best_distance = None
        best_overlap = 0
        best_shared = set()
        for distance, turn in enumerate(reversed(prior_turns)):
            turn_kw = set(self._extract_keywords(turn.user_input))
            shared = cur_kw & turn_kw
            overlap = len(shared)
            if overlap > best_overlap:
                best_overlap = overlap
                best_distance = distance
                best_turn = turn
                best_shared = shared

        # 至少要有1个共同关键词才算相关
        if best_overlap < 1 or best_distance is None:
            self._topic_related_text = ""
            self._topic_shared_kw = ""
            return {"related_turn": None, "relation_type": "jump"}

        # 记录相关话题文本与共同关键词，供直接回答引用
        self._topic_related_text = best_turn.user_input if best_turn else ""
        # 选最长且不含功能字的关键词作为话题引用词（3-gram 优先于 2-gram）
        _func = set(
            "我你他她它们这那哪的了是在有会就也都还又才把被让给跟和与及"
            "向往到对于以因为而其此所一不没别个些么呢吗啊呀哦嗯哈嘛吧已"
            "将要想说看听做去来走跑吃喝过着了上下里外一二三四五六七八九十几多"
        )
        clean = [w for w in best_shared if not any(c in _func for c in w)]
        pool = clean if clean else list(best_shared)
        self._topic_shared_kw = sorted(pool, key=lambda w: (-len(w), w))[0] if pool else ""

        if best_distance == 0:
            # 和上一轮同一话题
            return {"related_turn": best_distance, "relation_type": "continue"}
        # 绕回之前某个话题（跳过了至少1轮）
        return {"related_turn": best_distance, "relation_type": "return"}

    def _generate_specific_hints(self, user_input: str) -> List[str]:
        """针对具体问题，生成具体的待补充项列表（替代笼统的通用提示）。

        分析用户输入，识别问题领域和关键实体，根据领域返回回答该问题
        所需的具体数据项；都不匹配时返回通用待补充项。
        """
        text = user_input or ""

        # 领域识别规则（基于关键词匹配）：(关键词, 待补充项)
        # 顺序很重要：更具体的内容领域（饮食/天气/健康/购物）先判断；
        # 人物（他/她/谁）放在技术（怎么/如何）之前，避免「他最近怎么样」
        # 被「怎么样」里的「怎么」误判成技术类——内容领域已先行拦截，
        # 故人物只兜住缺少其它领域关键词的纯人称追问。
        domain_rules = [
            (["吃", "喝", "饭", "菜", "食物", "餐", "食谱", "煮", "炒"],
             ["口味偏好是什么（偏辣/偏甜/清淡）？",
              "有没有忌口或过敏的食物？",
              "需要几人份？",
              "有没有时间限制（比如要快手菜）？"]),
            (["下雨", "天气", "温度", "风", "气温", "预报", "降温"],
             ["哪个城市或地区？",
              "什么季节？",
              "你关心哪个方面（出行/穿着/农业）？"]),
            (["病", "不舒服", "疼", "痛", "症状", "发烧", "咳嗽"],
             ["持续多久了？",
              "什么部位？",
              "有没有去看过医生？"]),
            (["买", "推荐", "哪个好", "选购", "性价比"],
             ["预算范围？",
              "使用场景？",
              "有没有品牌偏好？"]),
            (["谁", "他", "她", "名字"],
             ["这个人和你什么关系？",
              "什么时间的事？",
              "在哪个地点？"]),
            (["怎么", "如何", "实现", "代码", "编程", "部署", "报错"],
             ["你的技术栈是什么？",
              "有没有已有方案？",
              "目标是什么？"]),
        ]

        for keywords, hints in domain_rules:
            if any(kw in text for kw in keywords):
                return hints

        # 通用：以上都不匹配
        return [
            "你具体想知道哪方面？",
            "有没有更多的背景信息？",
            "这个问题的目标是什么？",
        ]

    def _generate_direct_answer(
        self,
        user_input: str,
        fact_matches: List,
        belief_matches: List,
        unknowns: List[Dict],
        classification: Dict,
    ) -> str:
        """生成直接回答——用自然语言先给用户答案，再附延标结构。

        工作模式下，用户首先看到的是这个答案，而不是系统状态。
        """
        # 话题追踪衔接：如果用户绕回了之前的话题（relation_type=="return"），
        # 先用一句话自然衔接，再给正式回答。
        topic_prefix = ""
        topic_tracking = getattr(self, "_topic_tracking", None)
        if topic_tracking and topic_tracking.get("relation_type") == "return":
            # 优先用实际重叠的关键词引用旧话题，取不到则退回从相关文本挑词
            kw = getattr(self, "_topic_shared_kw", "") or ""
            if not kw:
                related_text = getattr(self, "_topic_related_text", "") or ""
                kw = self._pick_keyword(related_text) if related_text else ""
            if kw:
                topic_prefix = f"（你之前提到的{kw}，我们现在可以继续聊）\n\n"
            else:
                topic_prefix = "（我们之前聊过的那个话题，现在可以继续。）\n\n"

        # 判断用户是不是在提问
        is_question = any(user_input.endswith(q) for q in ["?", "？", "吗", "呢", "什么", "怎么", "为什么", "如何", "多少", "几"])
        is_question = is_question or any(w in user_input for w in ["请问", "怎么", "什么", "为什么", "如何", "是不是", "能不能", "会不会", "有没有"])

        facts = [f.statement for f in fact_matches[:3]] if fact_matches else []
        beliefs = [b.statement for b in belief_matches[:2]] if belief_matches else []

        # 情况1：有未知变量 → 诚实告知不能确定，列出已知和待补
        if unknowns and len(unknowns) > 0:
            if is_question:
                answer = "关于你的问题，我目前还没有足够的信息来给出确定答案。\n\n"
            else:
                answer = "关于这个话题，我目前掌握的信息还不够完整。\n\n"

            if facts:
                answer += "我已知的是：\n"
                for f in facts:
                    answer += f"• {f}\n"
                answer += "\n"

            answer += "需要你补充的信息：\n"
            for u in unknowns[:3]:
                answer += f"• {u['description'][:80]}\n"
            # 针对具体问题，列出具体的待补充项（替代笼统的通用 hint）
            specific_hints = self._generate_specific_hints(user_input)
            for h in specific_hints:
                answer += f"  → {h}\n"
            answer += "\n"
            answer += "你补充这些信息后，我就能给出更准确的回答。"
            return topic_prefix + answer

        # 情况2：有事实匹配 → 基于事实回答
        if facts:
            if is_question:
                answer = "根据已知事实，我来回答你的问题：\n\n"
            else:
                answer = "关于这个话题，我找到了一些相关的事实：\n\n"

            for i, f in enumerate(facts):
                answer += f"{i+1}. {f}\n"

            if len(facts) == 1:
                answer += "\n这是目前知识库里关于这个问题最相关的信息。"
            else:
                answer += f"\n以上是 {len(facts)} 条相关事实，都经过了交叉验证。"

            if beliefs:
                answer += "\n\n另外，你之前提到过：\n"
                for b in beliefs:
                    answer += f"• {b}\n"
                answer += "（这些是你的个人观点，仅在当前会话中有效）"

            return topic_prefix + answer

        # 情况3：只有信念匹配
        if beliefs:
            answer = "关于这个话题，我记得你之前提到过：\n\n"
            for b in beliefs:
                answer += f"• {b}\n"
            answer += "\n这是你的个人观点，系统会在当前会话中优先参考。"
            return topic_prefix + answer

        # 情况4：什么都没有 → 坦诚不知道
        if is_question:
            answer = "这个问题目前超出了我的知识范围，我没有找到相关的事实或定义。\n\n"
            answer += "不过没关系——我们可以一起探索：\n"
            answer += "• 如果你知道答案，可以告诉我，我会把它加入事实库\n"
            answer += "• 我们也可以在沙盒中推演一下，看看可能的情况\n"
            answer += "• 或者你可以换个角度描述你的问题"
            return topic_prefix + answer
        else:
            answer = "这个话题我还没有相关的知识记录。\n\n"
            answer += "你愿意多分享一些吗？我会把你说的记录下来，慢慢积累对这个话题的理解。"
            return topic_prefix + answer

    def _build_output_v2(
        self,
        user_input: str,
        protocol_matches: List,
        fact_matches: List,
        belief_matches: List,
        unknowns: List[Dict],
    ) -> str:
        """构建最终输出V2 — 分层展示协议/事实/信念，客观中立，决策链罗列。"""
        lines = []

        # Layer 0: 协议层匹配
        if protocol_matches:
            lines.append("【核心协议（Layer 0 · 不可撼动）】")
            for p in protocol_matches[:3]:
                lines.append(f"  [{p.item_id}] {p.statement}")
                if p.meaning:
                    lines.append(f"      → {p.meaning}")
            lines.append("")

        # Layer 1: 已知事实
        lines.append("【已知事实（Layer 1）】")
        if fact_matches:
            for f in fact_matches[:5]:
                score_tag = f"匹配度{f.score:.0%}" if f.score > 0 else ""
                lines.append(f"  [FACT-{f.item_id[:8]}] {f.statement} {score_tag}")
        else:
            lines.append("  (事实层无匹配条目)")

        # Layer 2: 用户信念（标注为会话级）
        if belief_matches:
            lines.append("")
            lines.append("【用户信念（Layer 2 · 仅当前会话有效）】")
            for b in belief_matches[:3]:
                weight = b.metadata.get("weight", 0)
                lines.append(f"  [权重{weight:.1f}] {b.statement}")

        # 延标标记
        if unknowns:
            lines.append("")
            lines.append("【延标标记 X(∞)】")
            for um in unknowns:
                lines.append(f"  {um['variable']}: {um['description']}")

        # 推演
        lines.append("")
        lines.append("【推演路径】")
        if protocol_matches and not unknowns:
            lines.append("  → 基于核心协议推演，底层定义明确")
            lines.append("  → 结合事实层数据进一步验证")
        elif fact_matches and not unknowns:
            lines.append("  → 基于已知事实推演，证据充分")
        elif unknowns:
            lines.append("  → 存在未闭合变量，判断予以悬置")
            lines.append("  → 建议设计验证路径，通过客观事实闭合X(∞)")
        else:
            lines.append("  → 数据不足，需要补充变量")

        # 闭合方案
        if unknowns:
            lines.append("")
            lines.append("【闭合方案】")
            for um in unknowns:
                lines.append(f"  ◇ 闭合 {um['variable']}: 需补充信息或通过实验验证")

        # 决策声明
        lines.append("")
        lines.append("【决策声明】")
        lines.append("  系统作为共生主体已罗列已知条件、未知变量、推演路径。")
        lines.append("  不做价值评判，不越界代替人类拍板。")
        lines.append("  最终决策权归人类，系统在此框架内协作推进。")

        return "\n".join(lines)

    def get_system_state(self, user_id: str = "default") -> Dict:
        """获取系统全局状态。"""
        # 更新张力
        self.curiosity.update_tension()
        return {
            "protocols": self.protocols,
            "self_awareness": self.awareness.get_state(),
            "facts": self.fact_engine.stats(),
            "beliefs": self.belief_engine.stats(),
            "sandbox": self.sandbox.stats(),
            "conflicts": self.conflict_resolver.stats(),
            "curiosity": self.curiosity.stats(),
            "system_tension": self.curiosity.get_system_tension(),
            "context": self.context.stats(user_id),
            "modules": self.modules_enabled,
            "memory_selector": self.memory_selector.stats(),
            "emotion_detector": self.emotion_detector.stats(),
            "auto_internal_gap": self.auto_gap.stats(),
            "suspended_search": self.search_scheduler.stats(),
        }

    def confirm_semantic(self, user_id: str, ambiguous_word: str,
                         resolved_meaning: str) -> Dict:
        """用户确认了一个模糊词的含义，记入语义记忆。

        解决"语义确认无闭环"问题：用户解释过的词，后续不再重复问。
        """
        self.context.remember_resolution(user_id, ambiguous_word, resolved_meaning)
        return {
            "status": "confirmed",
            "ambiguous_word": ambiguous_word,
            "resolved_meaning": resolved_meaning,
            "message": f"已确认'{ambiguous_word}'的含义，后续对话中不再重复询问",
            "total_resolutions": len(self.context.get_known_resolutions(user_id)),
        }
