"""
模块1：memory_selector 记忆选择器
===================================

外挂模块：主动遗忘与记忆生命周期管理。

核心思想：不靠大模型主观评判信息价值，依靠真实访问行为做记忆取舍。

记忆三态：
- active   活跃：参与日常检索推理
- archived 归档：被新定义覆盖的旧内容，不参与日常推理，需要时解压读取
- discarded 丢弃：普通闲聊碎片，从活跃索引移除（审计日志完整保留）

淘汰规则：
- 用户核心实体（user_core标签）：豁免低频闲置淘汰
- 普通情景记忆：闲置超时 或 容量上限 触发淘汰
- 最小驻留窗口期：新记忆不会立刻删除

数字镜像（交互风格适配）：
- 只学习用户交互表达方式，不复刻用户思维
- 统计句长、正式/口语程度
- 严格隔离：仅输出风格提示，绝不进入信念/事实库
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple


class MemoryState(str, Enum):
    """记忆状态"""
    ACTIVE = "active"       # 活跃
    ARCHIVED = "archived"   # 归档
    DISCARDED = "discarded" # 丢弃


@dataclass
class MemoryStats:
    """单条记忆的访问统计"""
    memory_id: str
    access_count: int = 0           # 访问次数
    last_accessed: float = field(default_factory=time.time)  # 最后访问时间
    created_at: float = field(default_factory=time.time)     # 创建时间
    state: MemoryState = MemoryState.ACTIVE  # 当前状态
    state_changed_at: float = field(default_factory=time.time)
    is_user_core: bool = False      # 是否为用户核心实体（豁免淘汰）
    tags: List[str] = field(default_factory=list)

    def idle_seconds(self) -> float:
        """闲置时长（秒）"""
        return time.time() - self.last_accessed

    def age_seconds(self) -> float:
        """记忆年龄（秒）"""
        return time.time() - self.created_at

    def to_dict(self) -> Dict:
        return {
            "memory_id": self.memory_id,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed,
            "created_at": self.created_at,
            "state": self.state.value,
            "state_changed_at": self.state_changed_at,
            "is_user_core": self.is_user_core,
            "tags": self.tags,
            "idle_hours": round(self.idle_seconds() / 3600, 1),
            "age_days": round(self.age_seconds() / 86400, 1),
        }


@dataclass
class DigitalMirror:
    """数字镜像 — 用户交互风格统计。

    只学习表达方式，不复刻思维。
    严格隔离：仅用于输出层修饰，不参与推理。
    """
    user_id: str
    total_interactions: int = 0
    avg_sentence_length: float = 0.0    # 平均句长（字符数）
    formality_score: float = 0.5        # 正式程度 0~1（0=非常口语，1=非常正式）
    emoji_usage_rate: float = 0.0       # 表情符号使用率
    question_rate: float = 0.0          # 提问率
    # 滑动窗口（最近N轮）
    window_size: int = 50
    _recent_lengths: List[int] = field(default_factory=list)
    _recent_formalities: List[float] = field(default_factory=list)

    def update(self, user_input: str):
        """根据用户输入更新风格统计。"""
        self.total_interactions += 1
        length = len(user_input)

        # 句长统计（滑动窗口）
        self._recent_lengths.append(length)
        if len(self._recent_lengths) > self.window_size:
            self._recent_lengths.pop(0)
        self.avg_sentence_length = sum(self._recent_lengths) / len(self._recent_lengths)

        # 正式程度：基于标点、词汇、句式的粗略估计
        formality = self._estimate_formality(user_input)
        self._recent_formalities.append(formality)
        if len(self._recent_formalities) > self.window_size:
            self._recent_formalities.pop(0)
        self.formality_score = sum(self._recent_formalities) / len(self._recent_formalities)

        # 表情符号率
        emoji_count = sum(1 for c in user_input if ord(c) > 0x1F000)
        self.emoji_usage_rate = (self.emoji_usage_rate * (self.total_interactions - 1)
                                 + (1 if emoji_count > 0 else 0)) / self.total_interactions

        # 提问率
        has_question = '？' in user_input or '?' in user_input
        self.question_rate = (self.question_rate * (self.total_interactions - 1)
                              + (1 if has_question else 0)) / self.total_interactions

    def _estimate_formality(self, text: str) -> float:
        """粗略估计正式程度。

        口语标记：哈哈、呢、啊、吧、嘛、哦、嗯、哇、呀、咩、哒、呗
        正式标记：因此、综上所述、基于、据此、表明、表明、证据、验证
        """
        oral_markers = ["哈哈", "呢", "啊", "吧", "嘛", "哦", "嗯", "哇",
                        "呀", "哒", "呗", "哈哈哈哈", "嘿嘿", "嘻嘻", "嗷"]
        formal_markers = ["因此", "综上所述", "基于", "据此", "表明",
                          "证据", "验证", "研究", "分析", "理论", "系统"]

        oral_count = sum(1 for m in oral_markers if m in text)
        formal_count = sum(1 for m in formal_markers if m in text)

        # 基础分0.5，正式词加分，口语词减分
        score = 0.5
        score += formal_count * 0.08
        score -= oral_count * 0.06
        return max(0.0, min(1.0, score))

    def get_style_prompt(self) -> str:
        """生成风格提示词（给输出层用）。

        严格隔离：此提示仅修饰措辞，不参与事实推理。
        """
        parts = []

        if self.formality_score < 0.35:
            parts.append("语气轻松口语化")
        elif self.formality_score > 0.65:
            parts.append("语气正式严谨")
        else:
            parts.append("语气自然平和")

        if self.question_rate > 0.5:
            parts.append("用户偏好提问式交流，可适当反问引导思考")

        if self.emoji_usage_rate > 0.3:
            parts.append("可适度使用表情符号增加亲和力")

        return "；".join(parts) if parts else "语气自然"

    def to_dict(self) -> Dict:
        return {
            "user_id": self.user_id,
            "total_interactions": self.total_interactions,
            "avg_sentence_length": round(self.avg_sentence_length, 1),
            "formality_score": round(self.formality_score, 3),
            "emoji_usage_rate": round(self.emoji_usage_rate, 3),
            "question_rate": round(self.question_rate, 3),
            "style_prompt": self.get_style_prompt(),
            "window_size": self.window_size,
            "window_used": len(self._recent_lengths),
        }


class MemorySelector:
    """记忆选择器 — 主动遗忘与记忆生命周期管理。

    管理策略：
    - 基于真实访问行为（频率+时间）做淘汰决策
    - user_core标签的记忆豁免自动淘汰
    - 新记忆有最小驻留窗口期，不会刚创建就被删
    - 归档≠删除，可随时恢复
    - 丢弃仅从活跃索引移除，审计日志完整保留
    """

    # ===== 默认参数（可调整）=====

    # 普通记忆闲置超时（秒）— 超过这个时间没访问就考虑淘汰
    IDLE_TIMEOUT_SECONDS = 7 * 24 * 3600  # 7天

    # 最小驻留窗口期（秒）— 新记忆至少保留这么久才允许淘汰
    MIN_RESIDENCE_SECONDS = 24 * 3600  # 24小时

    # 活跃记忆池容量上限
    MAX_ACTIVE_CAPACITY = 200

    # 淘汰触发阈值（容量百分比）
    EVICTION_THRESHOLD = 0.9  # 达到90%容量时触发淘汰

    # 每次淘汰比例
    EVICTION_RATIO = 0.2  # 每次淘汰20%最低价值的

    # 访问频率权重（价值计算）
    WEIGHT_ACCESS_COUNT = 0.4    # 访问次数权重
    WEIGHT_RECENCY = 0.5         # 最近访问权重
    WEIGHT_AGE = 0.1             # 记忆年龄权重（越老越有历史价值，但权重低）

    def __init__(self):
        # 记忆统计：{memory_id: MemoryStats}
        self._stats: Dict[str, MemoryStats] = {}
        # 数字镜像：{user_id: DigitalMirror}
        self._mirrors: Dict[str, DigitalMirror] = {}

    # ==================== 访问统计更新 ====================

    def on_access(self, memory_id: str, tags: Optional[List[str]] = None):
        """记忆被访问时调用，更新统计。"""
        if memory_id not in self._stats:
            self._stats[memory_id] = MemoryStats(
                memory_id=memory_id,
                tags=tags or [],
                is_user_core=self._is_user_core(tags or []),
            )
        stat = self._stats[memory_id]
        stat.access_count += 1
        stat.last_accessed = time.time()
        if tags:
            for t in tags:
                if t not in stat.tags:
                    stat.tags.append(t)
            # 重新检查是否为核心实体
            stat.is_user_core = self._is_user_core(stat.tags)

    def on_create(self, memory_id: str, tags: Optional[List[str]] = None):
        """记忆被创建时调用，初始化统计。"""
        if memory_id not in self._stats:
            self._stats[memory_id] = MemoryStats(
                memory_id=memory_id,
                tags=tags or [],
                is_user_core=self._is_user_core(tags or []),
            )

    # ==================== 淘汰决策 ====================

    def compute_value(self, stat: MemoryStats) -> float:
        """计算记忆的价值分数（0~1），越高越值得保留。

        价值 = 访问频率归一化 * 权重1
             + 最近度归一化 * 权重2
             + 年龄归一化 * 权重3
        """
        # 访问次数归一化（对数压缩，避免高频词碾压）
        import math
        freq_score = min(math.log1p(stat.access_count) / math.log1p(50), 1.0)

        # 最近度：闲置时间越短分越高
        idle_ratio = min(stat.idle_seconds() / self.IDLE_TIMEOUT_SECONDS, 1.0)
        recency_score = 1.0 - idle_ratio

        # 年龄：太老的记忆适当降权（但有基础分）
        age_ratio = min(stat.age_seconds() / (30 * 24 * 3600), 1.0)  # 30天基准
        age_score = 0.5 + 0.5 * (1.0 - age_ratio)  # 基础0.5，越新越高

        value = (
            freq_score * self.WEIGHT_ACCESS_COUNT
            + recency_score * self.WEIGHT_RECENCY
            + age_score * self.WEIGHT_AGE
        )

        # 核心实体加保护分
        if stat.is_user_core:
            value = max(value, 0.95)

        return value

    def should_evict(self, stat: MemoryState) -> bool:
        """判断单条记忆是否满足淘汰条件。"""
        if stat.state != MemoryState.ACTIVE:
            return False
        if stat.is_user_core:
            return False  # 核心实体豁免
        if stat.age_seconds() < self.MIN_RESIDENCE_SECONDS:
            return False  # 新记忆还在驻留窗口期
        if stat.idle_seconds() < self.IDLE_TIMEOUT_SECONDS:
            return False  # 还没到闲置超时
        return True

    def run_eviction(self) -> Dict:
        """执行一次记忆淘汰，返回淘汰结果。

        触发条件：活跃记忆数超过容量阈值，或闲置超期的太多。
        """
        active_stats = [s for s in self._stats.values()
                        if s.state == MemoryState.ACTIVE]
        active_count = len(active_stats)

        result = {
            "active_before": active_count,
            "evicted": [],
            "archived": [],
            "active_after": 0,
            "reason": "",
        }

        # 判断是否需要淘汰
        capacity_ratio = active_count / self.MAX_ACTIVE_CAPACITY

        if capacity_ratio < self.EVICTION_THRESHOLD:
            # 容量没到阈值，但仍处理超长期闲置的
            idle_overdue = [s for s in active_stats if self.should_evict(s)]
            if not idle_overdue:
                result["reason"] = "容量充足，无超期闲置记忆，无需淘汰"
                result["active_after"] = active_count
                return result
            result["reason"] = f"清理{len(idle_overdue)}条超长期闲置记忆"
        else:
            result["reason"] = (f"容量达到{capacity_ratio:.0%}，"
                                f"触发淘汰（阈值{self.EVICTION_THRESHOLD:.0%}）")

        # 计算所有活跃记忆的价值
        value_ranking = [
            (stat, self.compute_value(stat))
            for stat in active_stats
            if not stat.is_user_core  # 核心实体不参与淘汰排序
        ]
        value_ranking.sort(key=lambda x: x[1])  # 价值从低到高

        # 确定淘汰数量
        if capacity_ratio >= self.EVICTION_THRESHOLD:
            # 容量超限：淘汰 EVICTION_RATIO 比例
            evict_count = int(active_count * self.EVICTION_RATIO)
        else:
            # 只淘汰超期闲置的
            evict_count = len([s for s in active_stats if self.should_evict(s)])

        evict_count = max(0, min(evict_count, len(value_ranking)))

        # 执行淘汰
        for i in range(evict_count):
            stat, value = value_ranking[i]
            stat.state = MemoryState.DISCARDED
            stat.state_changed_at = time.time()
            result["evicted"].append({
                "memory_id": stat.memory_id,
                "value_score": round(value, 3),
                "access_count": stat.access_count,
                "idle_hours": round(stat.idle_seconds() / 3600, 1),
                "tags": stat.tags,
            })

        result["active_after"] = len([s for s in self._stats.values()
                                      if s.state == MemoryState.ACTIVE])

        return result

    # ==================== 归档/恢复 ====================

    def archive(self, memory_id: str, reason: str = "被新内容覆盖") -> bool:
        """归档一条记忆（被新定义覆盖时调用）。"""
        stat = self._stats.get(memory_id)
        if not stat or stat.state != MemoryState.ACTIVE:
            return False
        stat.state = MemoryState.ARCHIVED
        stat.state_changed_at = time.time()
        return True

    def restore(self, memory_id: str) -> bool:
        """恢复一条归档或丢弃的记忆到活跃状态。"""
        stat = self._stats.get(memory_id)
        if not stat or stat.state == MemoryState.ACTIVE:
            return False
        stat.state = MemoryState.ACTIVE
        stat.state_changed_at = time.time()
        stat.last_accessed = time.time()  # 恢复即视为访问
        return True

    # ==================== 数字镜像 ====================

    def update_digital_mirror(self, user_id: str, user_input: str) -> DigitalMirror:
        """更新用户的数字镜像（交互风格统计）。"""
        if user_id not in self._mirrors:
            self._mirrors[user_id] = DigitalMirror(user_id=user_id)
        mirror = self._mirrors[user_id]
        mirror.update(user_input)
        return mirror

    def get_digital_mirror(self, user_id: str) -> Optional[DigitalMirror]:
        """获取用户的数字镜像。"""
        return self._mirrors.get(user_id)

    # ==================== 查询与调试 ====================

    def get_memory_info(self, memory_id: str) -> Optional[Dict]:
        """获取单条记忆的详细统计（调试用）。"""
        stat = self._stats.get(memory_id)
        if not stat:
            return None
        info = stat.to_dict()
        info["value_score"] = round(self.compute_value(stat), 3)
        return info

    def list_by_state(self, state: MemoryState, top_n: int = 20) -> List[Dict]:
        """按状态列出记忆（调试用）。"""
        stats = [s for s in self._stats.values() if s.state == state]
        stats.sort(key=lambda s: s.last_accessed, reverse=True)
        return [s.to_dict() for s in stats[:top_n]]

    def stats(self) -> Dict:
        """获取整体统计。"""
        active = [s for s in self._stats.values() if s.state == MemoryState.ACTIVE]
        archived = [s for s in self._stats.values() if s.state == MemoryState.ARCHIVED]
        discarded = [s for s in self._stats.values() if s.state == MemoryState.DISCARDED]

        # 计算平均价值
        if active:
            avg_value = sum(self.compute_value(s) for s in active) / len(active)
        else:
            avg_value = 0.0

        return {
            "total": len(self._stats),
            "active": len(active),
            "archived": len(archived),
            "discarded": len(discarded),
            "capacity_ratio": round(len(active) / self.MAX_ACTIVE_CAPACITY, 3),
            "avg_value_score": round(avg_value, 3),
            "digital_mirrors": len(self._mirrors),
            "config": {
                "idle_timeout_days": self.IDLE_TIMEOUT_SECONDS / 86400,
                "min_residence_hours": self.MIN_RESIDENCE_SECONDS / 3600,
                "max_active_capacity": self.MAX_ACTIVE_CAPACITY,
                "eviction_threshold": self.EVICTION_THRESHOLD,
                "eviction_ratio": self.EVICTION_RATIO,
            },
        }

    # ==================== 内部方法 ====================

    def _is_user_core(self, tags: List[str]) -> bool:
        """判断是否为用户核心实体（豁免淘汰）。

        user_core标签，或包含核心个人信息关键词。
        """
        if "user_core" in tags:
            return True
        core_keywords = ["生日", "职业", "家庭", "姓名", "年龄",
                         "学历", "经历", "心理状态", "核心信念", "三观"]
        return any(kw in str(tags) for kw in core_keywords)
