"""
语义确认闸门 V2 — 智能模糊识别 + 上下文频率调度
=================================================

"模糊的就需要补充以及明确解释"
"系统会先确认这个语句是意思，先看看用户怎么理解的"

V2 优化：
1. 词元识别 — 不是简单字符串匹配，而是判断模糊词在句子中的语义角色
2. 上下文频率调度 — 对话越深入，对指代消解越宽容（有上下文可依）
3. 主观表达豁免 — "我觉得挺有意思的"这种主观感受，不触发语义确认
4. 闲聊模式豁免 — 问候、感叹等不触发
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class SemanticCheck:
    """语义检查结果"""
    passed: bool
    clarity: str               # "clear" | "ambiguous" | "nonsensical"
    issues: List[str]
    needs_user_confirm: bool    # 是否需要用户确认含义
    suggested_questions: List[str]  # 给用户的确认问题
    is_creative: bool          # 是否为创造性表达（→沙盒）
    common_sense_violation: bool  # 是否违反常理
    intent_type: str = "serious"  # 意图类型: casual/serious/subjective/creative/self_ref
    ambiguity_severity: float = 0.0  # 模糊程度 0-1，越高越需要确认


class SemanticGate:
    """语义确认闸门 V2 — 智能模糊识别。"""

    # 违反常理的模式
    COMMON_SENSE_VIOLATIONS = {
        "吃饭不用嘴": ["吃饭不用嘴", "用手吃饭不用", "脚吃饭"],
        "呼吸不用肺": ["不用肺呼吸", "用脚呼吸"],
        "水往上流": ["水往上流", "水向上流"],
    }

    # 高置信度模糊词 — 几乎一定需要确认
    HIGH_AMBIGUOUS_WORDS = ["那个东西", "之前说的", "上次说的", "那个玩意儿", "这玩意儿"]

    # 中置信度模糊词 — 需要结合上下文判断
    MED_AMBIGUOUS_WORDS = ["那个", "这个", "怎么回事"]

    # 低置信度模糊词 — 通常不触发，只有完全没上下文才触发
    LOW_AMBIGUOUS_WORDS = ["有点", "某种", "大概", "可能", "一些"]

    # 创造性表达标记 — 明确指向创意写作/架空推演的词
    CREATIVE_MARKERS = ["小说", "脑洞", "幻想", "架空", "想象",
                         "创意", "虚构", "if"]

    # 现实性假设词 — 普通的假设推理，不一定是创造性的
    HYPOTHETICAL_MARKERS = ["如果", "假设", "假如", "要是", "万一"]

    # 强创造性标记 — 明确表示架空/虚构场景的词（单独出现就可能进沙盒）
    STRONG_CREATIVE_MARKERS = ["小说", "脑洞", "幻想", "架空", "虚构"]

    # 闲聊/问候模式 — 不触发五段式
    # 闲聊核心词 — 只要包含这些词且不是问句，倾向闲聊
    CASUAL_KEYWORDS = [
        "你好", "嗨", "哈喽", "在吗", "在不在",
        "早上好", "下午好", "晚上好", "晚安",
        "拜拜", "再见",
        "谢谢", "感谢", "多谢",
        "好的", "好嘞", "没问题",
        "嗯", "哦哦", "嗯嗯", "哈哈", "嘿嘿", "嘻嘻",
        "行", "可以", "知道了", "了解", "收到",
        "我明白了", "懂了", "明白了",
    ]

    # 情绪/感受词 — 触发主观模式（不是问句的情况下）
    EMOTION_WORDS = [
        "焦虑", "压力", "难过", "伤心", "开心", "高兴",
        "害怕", "恐惧", "担心", "郁闷", "烦躁", "生气",
        "兴奋", "激动", "失望", "绝望", "孤独", "寂寞",
        "幸福", "满足", "疲惫", "累", "无聊", "有趣",
    ]

    # 过渡/填充词模式 — 不是核心问题，倾向闲聊
    FILLER_PATTERNS = [
        r"^对了",
        r"^话说",
        r"^那个",
        r"^等等",
        r"^顺便",
        r"^哦对了",
    ]

    CASUAL_PATTERNS = [
        r"^你好[呀吗呢]?$",
        r"^嗨$",
        r"^哈喽$",
        r"^在吗$",
        r"^在不在$",
        r"^早上好$",
        r"^下午好$",
        r"^晚上好$",
        r"^拜拜$",
        r"^再见$",
        r"^谢谢[啊呀哦]?$",
        r"^感谢$",
        r"^好的$",
        r"^嗯$",
        r"^哦哦?$",
        r"^哈哈$",
        r"^嘿嘿$",
        r"^嗯嗯$",
        r"^好嘞$",
        r"^行$",
        r"^可以$",
        r"^没问题$",
        r"^知道了$",
        r"^了解$",
        r"^收到$",
    ]

    # 主观表达模式 — 走信念系统，温和回应
    SUBJECTIVE_PATTERNS = [
        r"^我觉得",
        r"^我认为",
        r"^我感觉",
        r"^我想",
        r"^我喜欢",
        r"^我讨厌",
        r"^我害怕",
        r"^我担心",
        r"^我希望",
        r"^我相信",
        r"^在我看来",
        r"^个人觉得",
        r"^个人认为",
        r"^依我看",
        r".*挺有意思",
        r".*挺不错",
        r".*挺好玩",
        r".*太.*了$",
    ]

    # 自我指涉问题 — 关于系统自身
    SELF_REF_PATTERNS = [
        r"你是谁",
        r"你叫什么",
        r"你是什么",
        r"你和.*关系",
        r"你.*做什么的",
        r"你.*能做什么",
        r"你有什么.*功能",
        r"介绍一下你自己",
        r"你怎么工作的",
        r"延标.*你",
        r"你.*延标",
    ]

    # 严肃问题标记 — 明确需要推演/解释
    SERIOUS_MARKERS = [
        "为什么", "怎么回事", "原理", "本质", "核心",
        "解释一下", "说明一下", "分析", "对比", "区别",
        "什么是", "是什么", "如何", "怎样", "怎么办",
        "如何实现", "怎么实现", "可行性", "方案",
        "理论", "概念", "定义", "含义", "意思是",
    ]

    def __init__(self):
        # 编译正则
        self._casual_re = [re.compile(p) for p in self.CASUAL_PATTERNS]
        self._subjective_re = [re.compile(p) for p in self.SUBJECTIVE_PATTERNS]
        self._self_ref_re = [re.compile(p) for p in self.SELF_REF_PATTERNS]

    def detect_intent(self, text: str) -> str:
        """检测用户意图类型 V2 — 分层渐进式判断。

        Returns:
            casual: 闲聊/问候 → 轻松自然回复
            subjective: 主观观点/感受 → 共情+信念记录
            self_ref: 关于系统自身 → 自我意识回答
            creative: 创造性/假设性 → 沙盒推演
            serious: 严肃问题/知识提问 → 五段式延标输出
        """
        t = text.strip()
        is_question = "？" in t or "?" in t

        # 1. 精确匹配闲聊模式（整句匹配）
        for pattern in self._casual_re:
            if pattern.match(t):
                return "casual"

        # 2. 自我指涉（用 search，不要求开头）
        for pattern in self._self_ref_re:
            if pattern.search(t):
                return "self_ref"

        # 3. 创造性表达检测（更严格的判断）
        # 3a. 强创造性标记（小说/脑洞/幻想/架空/虚构）→ 直接 creative
        has_strong_creative = any(m in t for m in self.STRONG_CREATIVE_MARKERS)
        if has_strong_creative:
            return "creative"

        # 3b. 弱创造性标记（想象/创意/if）+ 假设词 → 可能是创造性表达
        # 但弱标记单独出现不算（比如"我有个创意"可能只是说有个好点子）
        has_weak_creative = any(m in t for m in self.CREATIVE_MARKERS
                                if m not in self.STRONG_CREATIVE_MARKERS)
        has_hypothetical = any(m in t for m in self.HYPOTHETICAL_MARKERS)

        # 如果只有假设词，没有创造性标记 → 现实性假设，归为 serious
        # 比如 "如果下雨会怎样" → 正常的假设推理，不需要进沙盒
        if has_hypothetical and not has_strong_creative and not has_weak_creative:
            # 归为 serious，让它走正常推理路径
            pass  # 继续往下走，不提前返回 creative

        # 弱创造性标记 + 假设词 或 违反常理的感觉 → 才算 creative
        if has_weak_creative and has_hypothetical:
            return "creative"

        # 4. 主观表达检测（分层）
        # 4a. 主观表达开头模式（我觉得/我认为...）
        for pattern in self._subjective_re:
            if pattern.match(t):
                return "subjective"

        # 4b. 情绪词 + 非问句 → 主观模式
        if not is_question:
            has_emotion = any(w in t for w in self.EMOTION_WORDS)
            if has_emotion:
                return "subjective"

        # 5. 闲聊关键词检测（非问句 + 包含闲聊核心词）
        if not is_question:
            casual_score = 0
            for kw in self.CASUAL_KEYWORDS:
                if kw in t:
                    # 整词权重更高
                    if t == kw:
                        casual_score += 3
                    elif len(t) <= len(kw) + 3:  # 差异很小，基本是闲聊词+语气词
                        casual_score += 2
                    else:
                        casual_score += 1
            # 过渡词也算
            for pat in self.FILLER_PATTERNS:
                if re.match(pat, t) and not is_question:
                    casual_score += 1

            if casual_score >= 2:
                return "casual"
            # 只有一个闲聊核心词且句子不长 → 也算闲聊
            if casual_score >= 1 and len(t) <= 15:
                return "casual"

        # 6. 严肃问题检测
        has_serious_marker = any(m in t for m in self.SERIOUS_MARKERS)
        if has_serious_marker:
            return "serious"

        # 7. 问句默认严肃
        if is_question:
            return "serious"

        # 8. 默认：陈述句按内容长度判断
        if len(t) <= 6:
            return "casual"  # 短句默认闲聊
        else:
            return "serious"

    def check(self, text: str, context_turns: int = 0,
              known_ambiguities: Dict = None) -> SemanticCheck:
        """检查输入的语义清晰度 V2。

        Args:
            text: 用户输入
            context_turns: 已进行的对话轮数（越多，上下文越丰富，对指代越宽容）
            known_ambiguities: 已确认过的歧义词 {词: 含义}
        """
        if known_ambiguities is None:
            known_ambiguities = {}

        issues: List[str] = []
        suggested_questions: List[str] = []
        ambiguity_severity = 0.0

        # 先判断意图
        intent = self.detect_intent(text)

        # 检查是否为创造性表达（更严格的判断）
        # - 强创造性标记（小说/脑洞/幻想/架空/虚构）→ 直接 creative
        # - 弱创造性标记 + 假设词 → creative
        # - 只有假设词（如果/假设/假如）→ 不算 creative，是现实性假设
        has_strong_creative = any(m in text for m in self.STRONG_CREATIVE_MARKERS)
        has_weak_creative = any(m in text for m in self.CREATIVE_MARKERS
                                if m not in self.STRONG_CREATIVE_MARKERS)
        has_hypothetical = any(m in text for m in self.HYPOTHETICAL_MARKERS)

        is_creative = (
            intent == "creative"
            or has_strong_creative
            or (has_weak_creative and has_hypothetical)
        )

        # ========== 模糊词识别（智能版）==========
        # 根据对话轮数调整阈值：
        # - 0-2轮：严格模式（几乎所有模糊词都触发）
        # - 3-5轮：中等模式（高+中置信度触发）
        # - 6+轮：宽松模式（只有高置信度触发，因为有上下文可依）

        if context_turns <= 2:
            threshold = "low"   # 严格
        elif context_turns <= 5:
            threshold = "medium"  # 中等
        else:
            threshold = "high"    # 宽松

        ambiguous_found = []
        severity_scores = []

        # 高置信度模糊词 — 任何情况都要检查（但已确认的跳过）
        for w in self.HIGH_AMBIGUOUS_WORDS:
            if w in text and w not in known_ambiguities:
                # 额外检查：如果"那个东西"有明确前文指代，可能不需要确认
                ambiguous_found.append(w)
                severity_scores.append(0.9)

        # 中置信度模糊词
        if threshold in ("low", "medium"):
            for w in self.MED_AMBIGUOUS_WORDS:
                if w in text and w not in known_ambiguities:
                    # 智能判断："这个/那个" + 后面跟名词 → 通常是明确的
                    # 比如"这个理论""那个问题" → 明确
                    # 单独的"这个""那个" → 模糊
                    idx = text.find(w)
                    after = text[idx + len(w):idx + len(w) + 6]
                    # 如果后面跟着名词性的词（的、是、有、不、很等），可能是明确的
                    # 如果后面是标点或空白，就是模糊的
                    is_isolated = True
                    if after and after[0] not in "，。！？、；：,.!?;:\n ":
                        # 后面有字，可能是"这个XX"的结构，不算模糊
                        is_isolated = False

                    # 特殊情况："这个/那个"在句首通常是明确的话题引入
                    # "这个问题..." → 明确
                    # 但"这个好用吗？" → 模糊（没有名词）
                    if idx == 0 and len(text) > len(w) + 2:
                        next_part = text[len(w):len(w) + 3]
                        # 如果紧跟着"是/有/不/很/也/都/就/才"等，那是话题引入，不算模糊
                        topic_markers = ["是", "有", "不", "很", "也", "都", "就", "才", "真", "确"]
                        if any(next_part.startswith(m) for m in topic_markers):
                            is_isolated = True  # "这个是..." → 可能是在指代前文

                    if is_isolated:
                        ambiguous_found.append(w)
                        severity_scores.append(0.6 if context_turns > 2 else 0.8)

        # 低置信度模糊词 — 只有在0-1轮且没有上下文时才触发
        if threshold == "low" and context_turns <= 1:
            for w in self.LOW_AMBIGUOUS_WORDS:
                if w in text and w not in known_ambiguities:
                    # "有点/某种/大概"这些通常不影响理解，低优先级
                    ambiguous_found.append(w)
                    severity_scores.append(0.3)

        # 计算模糊严重程度
        if severity_scores:
            ambiguity_severity = min(sum(severity_scores) / len(severity_scores), 1.0)

        # 主观表达模式豁免：
        # "我觉得挺有意思的" → 虽然可能有模糊词，但不应该触发语义确认
        # 用户只是在表达感受
        if intent == "subjective":
            ambiguous_found = []
            issues = []
            ambiguity_severity = 0.0

        if ambiguous_found:
            issues.append(f"检测到模糊词：{', '.join(ambiguous_found)}")
            # 只针对最严重的模糊词提问
            if severity_scores:
                max_idx = severity_scores.index(max(severity_scores))
                most_ambiguous = ambiguous_found[max_idx]
                suggested_questions.append(
                    f"您提到的'{most_ambiguous}'具体指什么？请补充明确的信息。"
                )

        # ========== 常理违反检查 ==========
        cs_violation = None
        for pattern_name, patterns in self.COMMON_SENSE_VIOLATIONS.items():
            for p in patterns:
                if p in text:
                    cs_violation = pattern_name
                    break

        if cs_violation:
            if is_creative:
                # 创造性表达中的常理违反 → 送沙盒
                issues.append(f"违反常理（{cs_violation}），但检测到创造性表达标记，建议进入沙盒推演")
            else:
                # 非创造性的常理违反 → 需确认
                issues.append(f"违反常理（{cs_violation}），需确认用户真实意图")
                suggested_questions.append(
                    f"您提到的内容涉及'{cs_violation}'，这与大众认知不同。"
                    f"您是在进行创造性表达（→沙盒推演），还是需要从其他角度理解？"
                )
                ambiguity_severity = max(ambiguity_severity, 0.7)

        # ========== 判定清晰度 ==========
        # 闲聊/主观表达 → 直接放行
        if intent in ("casual", "subjective"):
            clarity = "clear"
            passed = True
        elif not issues:
            clarity = "clear"
            passed = True
        elif is_creative and cs_violation:
            clarity = "nonsensical"  # 常理违反但在创造性上下文
            passed = True  # 放行到沙盒
        elif issues and ambiguity_severity >= 0.4:
            clarity = "ambiguous"
            passed = False  # 需要用户确认
        else:
            clarity = "clear"
            passed = True

        return SemanticCheck(
            passed=passed,
            clarity=clarity,
            issues=issues,
            needs_user_confirm=not passed,
            suggested_questions=suggested_questions,
            is_creative=is_creative,
            common_sense_violation=cs_violation is not None,
            intent_type=intent,
            ambiguity_severity=round(ambiguity_severity, 3),
        )

    def resolve_ambiguity(self, original: str, user_explanation: str) -> Dict:
        """用户补充解释后，解决歧义。"""
        return {
            "original": original,
            "user_explanation": user_explanation,
            "resolved": True,
            "resolved_meaning": user_explanation,
            "note": "语义歧义已通过用户补充解决，以用户解释为准",
        }
