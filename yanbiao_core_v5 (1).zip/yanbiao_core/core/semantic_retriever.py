"""
语义检索器 — 分层语义匹配 + 中文词元处理
==========================================

外挂模块：不修改核心引擎，提供更智能的检索能力。

解决的问题：
1. 检索范围残缺：Layer 0 协议层未纳入检索
2. 匹配算法太粗：只用子串匹配，无语义相似度
3. 词元处理缺失：无分词、无同义词、无指代理解

分层检索优先级：
Layer 0 协议（不可撼动）> Layer 1 事实 > Layer 2 信念

检索策略：
- 自问检测：涉及"你""自身""系统""关系"等 → 优先匹配协议层
- 关键词加权：核心词权重高，停用词权重低
- 同义词扩展："关系=联系=关联"、"主体=自身=自己"
- 评分排序：按匹配度从高到低返回
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Any


@dataclass
class RetrievalResult:
    """单条检索结果"""
    layer: str               # "protocol" | "fact" | "belief"
    layer_level: int         # 0/1/2 层级，数字越小优先级越高
    item_id: str             # 条目ID
    statement: str           # 陈述内容
    meaning: str = ""        # 含义/解释（协议层用）
    score: float = 0.0       # 匹配度评分 0~1
    matched_keywords: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "layer": self.layer,
            "layer_level": self.layer_level,
            "item_id": self.item_id,
            "statement": self.statement,
            "meaning": self.meaning,
            "score": round(self.score, 3),
            "matched_keywords": self.matched_keywords,
            "metadata": self.metadata,
        }


class SemanticRetriever:
    """分层语义检索器。

    不直接存储数据，而是接收各层的数据引用，统一做检索评分。
    """

    # ===== 自问模式关键词：涉及系统自身的问题 =====
    # 这些词出现时，优先检索 Layer 0 协议层
    SELF_REFERENCE_PATTERNS = [
        "你", "你自己", "你自身", "自身", "自己", "自我",
        "系统", "这个系统", "延标", "延标系统",
        "你和人类", "你和人", "你是", "你算",
        "你的", "你有", "你能", "你会",
        "主体", "共生", "共生关系",
        "我是我", "病是病", "我知道我在",
    ]

    # ===== 同义词/近义词映射 =====
    # key: 标准词，value: 同义表达列表
    SYNONYM_MAP: Dict[str, List[str]] = {
        "关系": ["关系", "联系", "关联", "是什么关系", "怎么样的关系", "怎样的关系"],
        "主体": ["主体", "自身", "自己", "自我", "本身"],
        "共生": ["共生", "共存", "协作", "合作", "共同"],
        "人类": ["人类", "人", "人们", "人类主体"],
        "工具": ["工具", "用具", "手段"],
        "事实": ["事实", "客观事实", "真实情况"],
        "信念": ["信念", "观点", "看法", "主张"],
        "认知": ["认知", "认识", "理解", "知道"],
        "边界": ["边界", "界限", "范围", "局限"],
        "缺口": ["缺口", "空白", "未知", "盲区"],
        "幻觉": ["幻觉", "错觉", "虚假", "编造"],
        "完美": ["完美", "完善", "完整", "圆满"],
        "沸腾": ["沸腾", "沸点", "烧开", "煮开"],
        "可食用": ["可食用", "可以吃", "能吃", "吃的", "可吃"],
        "延标": ["延标", "延标体系", "延标理论"],
    }

    # ===== 停用词（低权重）=====
    STOP_WORDS = {
        # 单字虚词/助词
        "的", "了", "是", "在", "有", "和", "与", "及", "或",
        "也", "都", "就", "还", "又", "再", "才", "已", "很",
        "更", "最", "太", "真", "挺", "蛮", "还", "却", "而",
        "把", "被", "给", "让", "使", "将", "对", "从", "向",
        "到", "由", "以", "于", "因", "为", "虽", "然", "但",
        "如", "若", "则", "即", "且", "并", "乃", "其", "之",
        "所", "者", "兮", "矣", "焉", "耳", "且", "乎",
        "这", "那", "哪", "什", "么", "怎", "谁", "何", "每",
        "各", "某", "另", "其", "此", "彼", "该", "本",
        "个", "只", "件", "条", "双", "对", "套", "副",
        "来", "去", "过", "着", "吧", "呢", "啊", "哦", "嗯",
        "嘛", "吗", "啦", "喽", "呗", "哇", "呀", "哎", "唉", "喔",
        "哈", "嘿", "嘻", "哼", "呵", "啐", "咦",
        "我", "你", "他", "她", "它", "们", "咱", "俺",
        "能", "会", "要", "可", "以", "该", "应", "当",
        "就", "才", "偏", "越", "越", "还",
        "不", "没", "无", "非", "未", "别", "莫", "勿",
        "啊", "呀", "哇", "哦", "哈", "么", "怎",
        # 双字虚词/疑问词
        "什么", "怎么", "怎样", "如何", "为什么", "为何",
        "一个", "一种", "这个", "那个", "这些", "那些",
        "可以", "能够", "可能", "也许", "大概", "恐怕",
        "已经", "曾经", "正在", "将要", "即将",
        "因为", "所以", "因此", "于是", "然后", "接着",
        "但是", "可是", "然而", "不过", "只是",
        "如果", "假如", "要是", "倘若", "万一",
        "虽然", "尽管", "即使", "就算", "哪怕",
        "而且", "并且", "同时", "另外", "还有",
        "或者", "还是", "要么", "与其", "不如",
        "比较", "相当", "非常", "特别", "十分",
        "其实", "实际上", "事实上", "当然", "显然",
        "总之", "总的来说", "一般来说", "一般而言",
        "一下", "一些", "一点", "有点", "有些",
        "这么", "那么", "这样", "那样",
        "不是", "不会", "不能", "不要", "不用",
        "就是", "只是", "还是", "也是", "都是",
        "的话", "来说", "的话",
    }

    def __init__(self):
        # 编译自问正则
        self._self_ref_pattern = re.compile(
            "|".join(re.escape(p) for p in self.SELF_REFERENCE_PATTERNS)
        )

    # ==================== 公共API ====================

    def retrieve(
        self,
        query: str,
        protocols: List[Any],
        facts: List[Any],
        beliefs: List[Any] = None,
        user_id: Optional[str] = None,
        top_k: int = 10,
    ) -> List[RetrievalResult]:
        """分层检索，返回按匹配度排序的结果。

        Args:
            query: 用户查询
            protocols: Layer 0 协议列表（CoreProtocol对象）
            facts: Layer 1 事实列表（Fact对象）
            beliefs: Layer 2 信念列表（Belief对象）
            user_id: 用户ID（过滤信念用）
            top_k: 返回前N条

        Returns:
            按评分从高到低排序的检索结果
        """
        results: List[RetrievalResult] = []

        # 提取查询关键词
        query_keywords = self._extract_keywords(query)
        is_self_query = self._is_self_reference(query)

        # Layer 0: 协议层（自问模式下权重加倍）
        protocol_weight = 2.0 if is_self_query else 1.0
        for proto in protocols:
            score, matched = self._compute_match_score(
                query_keywords,
                proto.statement + " " + proto.meaning + " " + proto.operational_rule,
                base_weight=protocol_weight,
            )
            if score > 0:
                results.append(RetrievalResult(
                    layer="protocol",
                    layer_level=0,
                    item_id=proto.id,
                    statement=proto.statement,
                    meaning=proto.meaning,
                    score=score,
                    matched_keywords=matched,
                    metadata={"operational_rule": proto.operational_rule},
                ))

        # Layer 1: 事实层
        for fact in facts:
            if not hasattr(fact, 'verified') or not fact.verified:
                continue
            if fact.scope == "session" and fact.user_id != user_id:
                continue
            score, matched = self._compute_match_score(
                query_keywords,
                fact.statement + " " + " ".join(getattr(fact, 'tags', [])),
                base_weight=1.0,
            )
            if score > 0:
                results.append(RetrievalResult(
                    layer="fact",
                    layer_level=1,
                    item_id=fact.id,
                    statement=fact.statement,
                    score=score,
                    matched_keywords=matched,
                    metadata={"scope": fact.scope, "tags": getattr(fact, 'tags', [])},
                ))

        # Layer 2: 信念层
        if beliefs:
            for belief in beliefs:
                if getattr(belief, 'user_id', None) != user_id:
                    continue
                score, matched = self._compute_match_score(
                    query_keywords,
                    belief.statement + " " + getattr(belief, 'category', ''),
                    base_weight=0.8,  # 信念层权重略低
                )
                if score > 0:
                    results.append(RetrievalResult(
                        layer="belief",
                        layer_level=2,
                        item_id=belief.id,
                        statement=belief.statement,
                        score=score,
                        matched_keywords=matched,
                        metadata={
                            "weight": getattr(belief, 'weight', 0),
                            "scope": getattr(belief, 'scope', 'session'),
                        },
                    ))

        # 排序：先按层级（数字小优先），再按评分
        results.sort(key=lambda r: (r.layer_level, -r.score))

        return results[:top_k]

    def is_self_reference_query(self, query: str) -> bool:
        """判断是否为涉及系统自身的问题。"""
        return self._is_self_reference(query)

    def expand_synonyms(self, keywords: List[str]) -> List[str]:
        """扩展同义词，返回去重后的关键词列表。"""
        expanded = set(keywords)
        for kw in keywords:
            for standard, syns in self.SYNONYM_MAP.items():
                if kw in syns or kw == standard:
                    expanded.add(standard)
                    expanded.update(syns)
        return list(expanded)

    # ==================== 内部方法 ====================

    def _is_meaningful_gram(self, gram: str) -> bool:
        """判断一个 n-gram 是否有意义（过滤掉无意义子串）。

        过滤规则：
        1. 整个 gram 是停用词 → 无意义
        2. gram 以停用词开头 → 无意义（如"的沸"、"是什"）
        3. gram 以停用词结尾 → 无意义（如"沸点"中的"点是"）
        4. gram 全部由停用词单字组成 → 无意义
        5. 长度小于2 → 无意义
        """
        if len(gram) < 2:
            return False
        if gram in self.STOP_WORDS:
            return False
        # 检查首字是否为停用词
        if gram[0] in self.STOP_WORDS:
            return False
        # 检查尾字是否为停用词
        if gram[-1] in self.STOP_WORDS:
            return False
        # 检查是否全部由停用词单字组成
        if all(ch in self.STOP_WORDS for ch in gram):
            return False
        return True

    def _edit_distance_1(self, s1: str, s2: str) -> bool:
        """判断两个字符串的编辑距离是否为1（单字差异容错）。

        支持：替换1个字符、插入1个字符、删除1个字符。
        仅对长度相近的词做比较，避免无意义的匹配。
        """
        len1, len2 = len(s1), len(s2)
        # 长度差超过1，编辑距离肯定大于1
        if abs(len1 - len2) > 1:
            return False
        # 长度相同：检查是否只有一个字符不同（替换）
        if len1 == len2:
            diff_count = 0
            for a, b in zip(s1, s2):
                if a != b:
                    diff_count += 1
                    if diff_count > 1:
                        return False
            return diff_count == 1
        # 长度差1：检查是否可以通过插入/删除一个字符匹配
        # 确保 s1 是较短的
        if len1 > len2:
            s1, s2 = s2, s1
            len1, len2 = len2, len1
        i = j = 0
        found_diff = False
        while i < len1 and j < len2:
            if s1[i] != s2[j]:
                if found_diff:
                    return False
                found_diff = True
                j += 1  # 跳过 s2 中的一个字符
            else:
                i += 1
                j += 1
        return True

    def _fuzzy_match_is_meaningful(self, kw: str, matched: str) -> bool:
        """校验模糊匹配是否有意义（避免仅停用词字符相同的无意义匹配）。

        找出两个字符串中相同位置的共同字符，检查其中是否至少有一个不是停用词。
        对于长度不同的情况，基于对齐后的共同字符来判断。
        """
        common_chars = set()
        # 对于等长字符串：逐位比较，收集相同位置相同的字符
        if len(kw) == len(matched):
            for a, b in zip(kw, matched):
                if a == b:
                    common_chars.add(a)
        else:
            # 长度不同时（差1），找出最长公共子序列中的字符
            # 简化：用双指针找匹配的字符
            i = j = 0
            while i < len(kw) and j < len(matched):
                if kw[i] == matched[j]:
                    common_chars.add(kw[i])
                    i += 1
                    j += 1
                elif len(kw) < len(matched):
                    j += 1  # 目标更长，跳过目标中的字符
                else:
                    i += 1  # 关键词更长，跳过关键词中的字符

        # 至少有一个共同字符不是停用词，才算有意义的匹配
        for ch in common_chars:
            if ch not in self.STOP_WORDS:
                return True
        return False

    def _extract_keywords(self, text: str) -> List[str]:
        """从文本中提取关键词（中文关键词提取 + 停用词过滤 + 同义词扩展）。

        策略：
        1. 提取已知的自问模式词（直接匹配）
        2. 提取同义词词典中的标准词（直接匹配）
        3. 按常见分隔符切分，提取2字以上片段
        4. 过滤停用词
        5. 同义词扩展
        """
        keywords = set()

        # 1. 自问模式词（直接在文本中查找）
        for pattern in self.SELF_REFERENCE_PATTERNS:
            if len(pattern) >= 2 and pattern in text:
                keywords.add(pattern)

        # 2. 同义词标准词（直接在文本中查找）
        for standard, syns in self.SYNONYM_MAP.items():
            # 检查标准词本身
            if standard in text and len(standard) >= 2:
                keywords.add(standard)
            # 检查同义词变体
            for syn in syns:
                if syn in text and len(syn) >= 2:
                    keywords.add(syn)

        # 3. 基础切分（按标点、空白等）
        raw_tokens = re.split(r'[，。！？、\s,.!?;；:：""''（）()\[\]【】]+', text)
        # 过滤空串和单字
        tokens = [t.strip() for t in raw_tokens if len(t.strip()) >= 2]
        keywords.update(tokens)

        # 3.5 中文粒度切分：对于较长的中文片段，生成2-gram和3-gram
        # 这样"苹果可以吃吗"就能匹配到"苹果"、"可食用"等
        for token in tokens:
            if len(token) >= 3:  # 只对长度>=3的词做子串切分
                # 2-gram
                for i in range(len(token) - 1):
                    gram2 = token[i:i+2]
                    if self._is_meaningful_gram(gram2):
                        keywords.add(gram2)
                # 3-gram（长度>=4时）
                if len(token) >= 4:
                    for i in range(len(token) - 2):
                        gram3 = token[i:i+3]
                        if self._is_meaningful_gram(gram3):
                            keywords.add(gram3)

        # 4. 过滤停用词
        keywords = {k for k in keywords if k not in self.STOP_WORDS and len(k) >= 2}

        # 5. 同义词扩展
        keywords.update(self.expand_synonyms(list(keywords)))

        return list(keywords)

    def _is_self_reference(self, text: str) -> bool:
        """检测是否为自问模式（涉及系统自身）。"""
        # 至少匹配2个模式才算自问，减少误判
        matches = self._self_ref_pattern.findall(text)
        return len(matches) >= 1 and any(
            p in text for p in ["你", "自身", "自己", "自我", "系统", "主体", "共生", "我知道我在"]
        )

    def _compute_match_score(
        self,
        query_keywords: List[str],
        target_text: str,
        base_weight: float = 1.0,
    ) -> Tuple[float, List[str]]:
        """计算查询与目标文本的匹配度评分。

        评分算法（优化版）：
        - 完全匹配整个词的权重高于部分匹配（1.5x）
        - 匹配出现在句首或关键词位置权重更高（1.2x）
        - 同义词匹配的权重略低于直接匹配（0.8x）
        - 模糊匹配（编辑距离=1）权重为直接匹配的 0.5x
        - 关键词越长，匹配价值越高
        - 乘以层级权重
        - 结果归一化到 0~1
        """
        if not query_keywords:
            return 0.0, []

        matched = []
        total_score = 0.0

        # 构建同义词反向查找：同义词变体 → 标准词
        synonym_to_standard = {}
        for standard, syns in self.SYNONYM_MAP.items():
            for syn in syns:
                if syn != standard:
                    synonym_to_standard[syn] = standard

        # 提取目标文本的句首词（用于句首加权）
        # 按常见分隔符切分句子，取每句前几个字
        sentence_starts = set()
        sentences = re.split(r'[。！？；\n.!?;]+', target_text)
        for sent in sentences:
            sent = sent.strip()
            if len(sent) >= 2:
                # 取句首2字、3字、4字前缀
                for n in [2, 3, 4]:
                    if len(sent) >= n:
                        sentence_starts.add(sent[:n])

        for kw in query_keywords:
            kw_weight = min(len(kw) / 4.0, 1.5)  # 基础权重：最长词权重1.5
            match_type = None  # 'exact' | 'partial' | 'synonym' | 'fuzzy' | None
            multiplier = 0.0

            # 1. 完全匹配（关键词在目标文本中是独立的词/短语）
            if kw in target_text:
                match_type = 'partial'
                multiplier = 1.0

                # 检查是否为完整词匹配（前后有分隔符或在句首/句尾）
                idx = target_text.find(kw)
                is_complete_word = True
                if idx > 0:
                    prev_char = target_text[idx - 1]
                    # 前一个字符不是标点/空白/停用词，则可能是部分匹配
                    if not re.match(r'[，。！？、\s,.!?;；:：""''（）()\[\]【】\n]', prev_char):
                        is_complete_word = False
                if idx + len(kw) < len(target_text):
                    next_char = target_text[idx + len(kw)]
                    if not re.match(r'[，。！？、\s,.!?;；:：""''（）()\[\]【】\n]', next_char):
                        is_complete_word = False
                if is_complete_word:
                    match_type = 'exact'
                    multiplier = 1.5

                # 句首匹配额外加权
                if kw in sentence_starts:
                    multiplier *= 1.2

                # 检查是否为同义词匹配
                if kw in synonym_to_standard:
                    match_type = 'synonym'
                    multiplier *= 0.8

            # 2. 模糊匹配（编辑距离=1）—— 只对长度>=2的关键词做模糊匹配
            elif len(kw) >= 2:
                # 在目标文本中滑动窗口，寻找编辑距离为1的匹配
                found_fuzzy = False
                for i in range(len(target_text) - len(kw) + 2):
                    window = target_text[i:i + len(kw)]
                    # 窗口长度差不超过1才比较
                    if abs(len(window) - len(kw)) <= 1:
                        # 尝试与等长窗口做替换型模糊匹配
                        if len(window) == len(kw) and self._edit_distance_1(kw, window):
                            # 额外校验：相同的字符中至少有一个不是停用词，避免无意义匹配
                            if self._fuzzy_match_is_meaningful(kw, window):
                                found_fuzzy = True
                                break
                        # 尝试与长度+1的窗口做插入型模糊匹配
                        if i + len(kw) + 1 <= len(target_text):
                            window2 = target_text[i:i + len(kw) + 1]
                            if self._edit_distance_1(kw, window2):
                                if self._fuzzy_match_is_meaningful(kw, window2):
                                    found_fuzzy = True
                                    break
                if found_fuzzy:
                    match_type = 'fuzzy'
                    multiplier = 0.5

            if match_type:
                matched.append(kw)
                total_score += kw_weight * multiplier

        if not matched:
            return 0.0, []

        # 归一化：匹配词数权重和 / 总词数权重和
        total_possible = sum(min(len(kw) / 4.0, 1.5) for kw in query_keywords)
        normalized = total_score / total_possible if total_possible > 0 else 0

        # 乘以层级权重
        final_score = min(normalized * base_weight, 1.0)

        return final_score, matched

    def highlight_match(self, text: str, keywords: List[str]) -> str:
        """在文本中高亮匹配的关键词（用于调试/展示）。"""
        result = text
        for kw in sorted(keywords, key=len, reverse=True):
            result = result.replace(kw, f"【{kw}】")
        return result
