"""
模块4：suspended_search_scheduler 悬置查找调度器
==================================================

外挂模块：后台异步处理认知缺口，不阻塞主对话响应。

功能：
1. 管理查找任务队列，有并发上限
2. 检索活跃记忆库，尝试搜集证据闭合缺口
3. 沙盒推演结果仅作参考，严禁作为真实证据
4. 找到证据 → 调用好奇心引擎闭合缺口，降低张力
5. 查不到 → 缺口维持悬置，绝不脑补
6. 新记忆入库时，增量匹配悬置缺口

保护机制：
- 最大并发限制（默认10）
- 任务超时终止
- 缺口去重
- 优先级区分（用户对话 > 系统自探索）
"""

from __future__ import annotations

import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Callable, Set


class TaskStatus(str, Enum):
    """任务状态"""
    PENDING = "pending"       # 排队中
    RUNNING = "running"       # 运行中
    COMPLETED = "completed"   # 已完成（找到证据，闭合了）
    FAILED = "failed"         # 失败（超时/错误）
    SUSPENDED = "suspended"   # 悬置（没找到证据，维持缺口）


class SearchPriority(str, Enum):
    """查找优先级"""
    USER_TRIGGERED = "user_triggered"   # 用户对话产生的缺口（最高）
    INTERNAL_AUTO = "internal_auto"     # 系统自探索生成的
    INCREMENTAL = "incremental"         # 新记忆增量重试


@dataclass
class SearchTask:
    """悬置查找任务"""
    task_id: str
    gap_id: str                       # 关联的认知缺口ID
    gap_variable: str                 # 缺口变量名
    gap_description: str              # 缺口描述
    priority: SearchPriority
    status: TaskStatus = TaskStatus.PENDING
    result: Optional[str] = None      # 查找结果描述
    evidence_found: List[str] = field(default_factory=list)  # 找到的证据
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    attempts: int = 0                 # 尝试次数
    error: Optional[str] = None

    def to_dict(self) -> Dict:
        return {
            "task_id": self.task_id,
            "gap_id": self.gap_id,
            "gap_variable": self.gap_variable,
            "gap_description": self.gap_description,
            "priority": self.priority.value,
            "status": self.status.value,
            "result": self.result,
            "evidence_count": len(self.evidence_found),
            "attempts": self.attempts,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_seconds": round(
                (self.finished_at - self.started_at), 2
            ) if self.finished_at and self.started_at else None,
            "error": self.error,
        }


class SuspendedSearchScheduler:
    """悬置查找调度器。

    管理后台查找任务，有并发上限、超时、优先级队列。

    原型版本：同步执行（因为是演示用），接口设计为可异步扩展。
    实际生产环境可替换为线程池/协程。
    """

    # ===== 参数（可调整）=====

    # 最大并发任务数
    MAX_PARALLEL_TASKS = 10

    # 任务超时时间（秒）
    TASK_TIMEOUT = 30

    # 最大排队任务数
    MAX_QUEUE_SIZE = 50

    # 单次查找最大证据数
    MAX_EVIDENCE_PER_SEARCH = 5

    # 增量重试最大次数（同一条新记忆触发的）
    MAX_INCREMENTAL_ATTEMPTS = 3

    def __init__(self):
        # 任务存储：{task_id: SearchTask}
        self._tasks: Dict[str, SearchTask] = {}

        # 优先级队列（按优先级排序）
        self._queue: List[str] = []  # 存task_id

        # 正在运行的任务ID集合
        self._running: Set[str] = set()

        # 已处理过的缺口ID（去重）
        self._processed_gaps: Set[str] = set()

        # 锁（原型简化版，实际多线程需要真锁）
        self._lock = threading.Lock()

        # 统计
        self._total_submitted = 0
        self._total_completed = 0
        self._total_suspended = 0

    # ==================== 任务提交 ====================

    def submit(
        self,
        gap_id: str,
        gap_variable: str,
        gap_description: str,
        priority: SearchPriority = SearchPriority.USER_TRIGGERED,
    ) -> Dict:
        """提交一个缺口到查找队列。

        Returns:
            提交结果
        """
        # 去重检查
        if gap_id in self._processed_gaps:
            return {
                "submitted": False,
                "reason": "该缺口已提交过，去重跳过",
                "gap_id": gap_id,
            }

        # 队列长度检查
        if len(self._queue) >= self.MAX_QUEUE_SIZE:
            return {
                "submitted": False,
                "reason": f"队列已满（{len(self._queue)}/{self.MAX_QUEUE_SIZE}）",
                "gap_id": gap_id,
            }

        # 创建任务
        import uuid
        task_id = f"SS-{uuid.uuid4().hex[:10]}"
        task = SearchTask(
            task_id=task_id,
            gap_id=gap_id,
            gap_variable=gap_variable,
            gap_description=gap_description,
            priority=priority,
        )

        with self._lock:
            self._tasks[task_id] = task
            self._processed_gaps.add(gap_id)
            self._total_submitted += 1

            # 按优先级插入队列（高优先级在前）
            priority_order = {
                SearchPriority.USER_TRIGGERED: 0,
                SearchPriority.INCREMENTAL: 1,
                SearchPriority.INTERNAL_AUTO: 2,
            }
            # 找到插入位置
            insert_idx = len(self._queue)
            for i, qid in enumerate(self._queue):
                q_task = self._tasks.get(qid)
                if q_task and priority_order.get(priority, 99) < priority_order.get(q_task.priority, 99):
                    insert_idx = i
                    break
            self._queue.insert(insert_idx, task_id)

        return {
            "submitted": True,
            "task_id": task_id,
            "gap_id": gap_id,
            "priority": priority.value,
            "queue_position": insert_idx,
            "queue_size": len(self._queue),
        }

    # ==================== 任务执行 ====================

    def process_next(
        self,
        fact_engine,
        belief_engine,
        curiosity_engine,
        user_id: str = None,
    ) -> Optional[Dict]:
        """处理队列中的下一个任务（同步执行，原型用）。

        实际生产环境应在后台线程中调用。

        Args:
            fact_engine: 事实引擎实例
            belief_engine: 信念引擎实例
            curiosity_engine: 好奇心引擎实例
            user_id: 用户ID（用于过滤）

        Returns:
            任务执行结果，或None（没有待处理任务）
        """
        # 检查并发限制
        if len(self._running) >= self.MAX_PARALLEL_TASKS:
            return None

        # 取下一个任务
        with self._lock:
            if not self._queue:
                return None
            task_id = self._queue.pop(0)
            task = self._tasks.get(task_id)
            if not task:
                return None
            task.status = TaskStatus.RUNNING
            task.started_at = time.time()
            task.attempts += 1
            self._running.add(task_id)

        try:
            # 执行查找
            result = self._execute_search(task, fact_engine, belief_engine,
                                          curiosity_engine, user_id)
            return result
        except Exception as e:
            task.status = TaskStatus.FAILED
            task.error = str(e)
            task.finished_at = time.time()
            with self._lock:
                self._running.discard(task_id)
            return task.to_dict()

    def _execute_search(
        self,
        task: SearchTask,
        fact_engine,
        belief_engine,
        curiosity_engine,
        user_id: Optional[str],
    ) -> Dict:
        """执行实际的查找逻辑。

        策略：
        1. 在活跃事实/信念中搜索与缺口相关的证据
        2. 找到足够证据 → 闭合缺口
        3. 没找到 → 维持悬置
        4. 沙盒内容仅作参考，不作为闭合证据
        """
        # 从缺口描述中提取搜索关键词
        keywords = self._extract_search_keywords(task.gap_description)

        found_evidence = []

        # 搜索事实库
        for kw in keywords[:5]:  # 限制关键词数量
            facts = fact_engine.query(kw, user_id)
            for fact in facts[:self.MAX_EVIDENCE_PER_SEARCH]:
                if fact.verified and fact.id not in [e[0] for e in found_evidence]:
                    found_evidence.append((fact.id, fact.statement, "fact"))

        # 搜索信念库
        for kw in keywords[:5]:
            beliefs = belief_engine.query(kw, user_id)
            for belief in beliefs[:3]:
                if belief.id not in [e[0] for e in found_evidence]:
                    found_evidence.append((belief.id, belief.statement, "belief"))

        task.evidence_found = [f"{t}:{s[:30]}" for _, s, t in found_evidence]

        # 判断是否找到足够证据来闭合
        # 标准：至少2条已验证事实，或3条混合证据
        verified_fact_count = sum(1 for _, _, t in found_evidence if t == "fact")
        total_evidence = len(found_evidence)

        can_close = (verified_fact_count >= 2) or (total_evidence >= 3)

        if can_close:
            # 闭合缺口
            evidence_desc = "; ".join(
                f"[{t.upper()}-{mid[:6]}] {s[:40]}"
                for mid, s, t in found_evidence[:3]
            )
            gap = curiosity_engine.close_gap(
                task.gap_id,
                closed_by="suspended_search",
                evidence=f"悬置查找找到证据：{evidence_desc}",
            )
            if gap:
                task.status = TaskStatus.COMPLETED
                task.result = f"找到{total_evidence}条证据，缺口已闭合"
                with self._lock:
                    self._total_completed += 1
            else:
                task.status = TaskStatus.SUSPENDED
                task.result = "证据已找到但缺口闭合失败"
        else:
            # 证据不足，维持悬置
            task.status = TaskStatus.SUSPENDED
            task.result = (f"找到{total_evidence}条相关信息"
                           f"（已验证事实{verified_fact_count}条），证据不足，维持悬置")
            with self._lock:
                self._total_suspended += 1

        task.finished_at = time.time()
        with self._lock:
            self._running.discard(task.task_id)

        return task.to_dict()

    def process_all_pending(
        self,
        fact_engine,
        belief_engine,
        curiosity_engine,
        user_id: str = None,
        max_tasks: int = 10,
    ) -> Dict:
        """批量处理所有待处理任务（原型用，同步执行）。

        Args:
            max_tasks: 最多处理多少个任务

        Returns:
            批量处理结果统计
        """
        results = []
        count = 0

        while count < max_tasks:
            result = self.process_next(
                fact_engine, belief_engine, curiosity_engine, user_id
            )
            if result is None:
                break
            results.append(result)
            count += 1

        completed = sum(1 for r in results if r["status"] == "completed")
        suspended = sum(1 for r in results if r["status"] == "suspended")
        failed = sum(1 for r in results if r["status"] == "failed")

        return {
            "processed": len(results),
            "completed": completed,
            "suspended": suspended,
            "failed": failed,
            "remaining_queue": len(self._queue),
            "details": results,
        }

    # ==================== 增量重试 ====================

    def on_new_memory(
        self,
        new_memory_statement: str,
        fact_engine,
        belief_engine,
        curiosity_engine,
        user_id: str = None,
    ) -> Dict:
        """新记忆入库时，增量匹配悬置缺口。

        每当有新的信念/事实入库，调用此方法尝试用新记忆闭合悬置缺口。
        """
        # 找出所有悬置状态的任务
        suspended_tasks = [
            t for t in self._tasks.values()
            if t.status == TaskStatus.SUSPENDED
            and t.attempts < self.MAX_INCREMENTAL_ATTEMPTS
        ]

        if not suspended_tasks:
            return {"rechecked": 0, "closed": 0, "reason": "无悬置缺口"}

        # 提取新记忆关键词
        new_keywords = set(self._extract_search_keywords(new_memory_statement))

        rechecked = 0
        newly_closed = 0

        for task in suspended_tasks:
            # 检查新记忆是否与该缺口相关
            gap_keywords = set(self._extract_search_keywords(task.gap_description))
            overlap = new_keywords & gap_keywords

            if overlap:  # 有关联，重新尝试查找
                task.attempts += 1
                rechecked += 1

                # 重新执行查找（现在多了一条新记忆）
                result = self._execute_search(
                    task, fact_engine, belief_engine, curiosity_engine, user_id
                )

                if result["status"] == "completed":
                    newly_closed += 1

        return {
            "new_memory": new_memory_statement[:50],
            "suspended_total": len(suspended_tasks),
            "rechecked": rechecked,
            "newly_closed": newly_closed,
            "reason": f"新记忆触发增量重试，重新检查{rechecked}个相关悬置缺口",
        }

    # ==================== 辅助方法 ====================

    def _extract_search_keywords(self, text: str) -> List[str]:
        """从文本中提取搜索关键词。"""
        import re
        # 提取2字以上的中文词和英文词
        words = re.findall(r'[\u4e00-\u9fa5A-Za-z0-9]{2,}', text)
        # 过滤停用词
        stopwords = {"什么", "怎么", "为什么", "这个", "那个", "一个", "一种",
                     "可以", "能够", "我们", "你们", "他们", "它们", "自己",
                     "不是", "就是", "还是", "或者", "以及", "的话", "没有",
                     "存在", "需要", "进行", "通过", "相关", "如何", "关于"}
        words = [w for w in words if w not in stopwords and len(w) >= 2]
        return words

    # ==================== 查询接口 ====================

    def get_task(self, task_id: str) -> Optional[Dict]:
        """获取任务详情。"""
        task = self._tasks.get(task_id)
        return task.to_dict() if task else None

    def list_tasks(self, status: Optional[TaskStatus] = None,
                   limit: int = 20) -> List[Dict]:
        """列出任务列表。"""
        tasks = list(self._tasks.values())
        if status:
            tasks = [t for t in tasks if t.status == status]
        tasks.sort(key=lambda t: t.created_at, reverse=True)
        return [t.to_dict() for t in tasks[:limit]]

    def stats(self) -> Dict:
        """获取调度器统计。"""
        status_counts = {}
        for status in TaskStatus:
            status_counts[status.value] = sum(
                1 for t in self._tasks.values() if t.status == status
            )

        return {
            "total_submitted": self._total_submitted,
            "total_completed": self._total_completed,
            "total_suspended": self._total_suspended,
            "queue_size": len(self._queue),
            "running_count": len(self._running),
            "total_tasks": len(self._tasks),
            "status_breakdown": status_counts,
            "config": {
                "max_parallel_tasks": self.MAX_PARALLEL_TASKS,
                "task_timeout_seconds": self.TASK_TIMEOUT,
                "max_queue_size": self.MAX_QUEUE_SIZE,
                "max_incremental_attempts": self.MAX_INCREMENTAL_ATTEMPTS,
            },
        }
