"""
模块3：auto_internal_gap 内部自探索缺口生成器
================================================

外挂模块：系统内部认知求索，主动发现认知缺口。

三类内部生成缺口：
1. 信息断层缺口 — 记忆中存在跳跃/缺失的逻辑链条
2. 待交叉验证缺口 — 只有单一来源/未验证的事实
3. 隐含推论缺口 — 从已知事实可以推导出但未明确的结论

约束：
- 生成的缺口提交给好奇心引擎，拉高系统张力
- 缺口悬置在内部，对用户完全透明
- 受系统总张力上限控制，张力超限停止生成新缺口
- 可关闭，退回原有被动缺口模式
- 仅扫描活跃记忆池，归档/丢弃数据不参与
"""

from __future__ import annotations

import time
import hashlib
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from .curiosity_engine import CuriosityEngine, GapPriority


class GapSource(str, Enum):
    """缺口来源类型"""
    INFO_GAP = "info_gap"           # 信息断层
    NEEDS_VERIFICATION = "needs_verification"  # 待交叉验证
    IMPLIED_INFERENCE = "implied_inference"    # 隐含推论


@dataclass
class InternalGapProposal:
    """内部生成的缺口提案"""
    source: GapSource              # 缺口类型
    variable: str                  # 变量名 X(∞)_xxx
    description: str               # 描述
    evidence_used: List[str]       # 用到的证据（记忆ID或陈述）
    priority: str                  # 优先级
    confidence: float              # 生成置信度 0~1


class AutoInternalGapGenerator:
    """内部自探索缺口生成器。

    扫描活跃记忆池，内部推演发现认知缺口。

    算法策略：
    - 信息断层：检测记忆中存在因果/时序跳跃
    - 待交叉验证：发现只有单一来源的客观事实
    - 隐含推论：从多条记忆中可推导但未明确的结论

    约束：
    - 受总张力上限控制
    - 可随时关闭
    - 绝不脑补，只标记缺口
    """

    # ===== 参数（可调整）=====

    # 单次扫描最多生成的缺口数
    MAX_GAPS_PER_SCAN = 5

    # 生成置信度阈值（低于此值的缺口不提交）
    CONFIDENCE_THRESHOLD = 0.4

    # 各类缺口的权重（影响优先级分配）
    WEIGHT_INFO_GAP = 0.3
    WEIGHT_NEEDS_VERIFICATION = 0.4
    WEIGHT_IMPLIED_INFERENCE = 0.3

    # 最小记忆数量才启动扫描（避免记忆太少时乱生成）
    MIN_MEMORIES_FOR_SCAN = 5

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self._generated_gaps: Set[str] = set()  # 已生成的缺口ID（去重）
        self._scan_count = 0
        self._total_generated = 0

    # ==================== 主入口 ====================

    def scan_and_generate(
        self,
        active_facts: List,
        active_beliefs: List,
        curiosity_engine,  # CuriosityEngine 实例
        system_tension: float,
        tension_max: float = 1.0,
    ) -> Dict:
        """扫描活跃记忆，生成内部认知缺口。

        Args:
            active_facts: 活跃事实列表
            active_beliefs: 活跃信念列表
            curiosity_engine: 好奇心引擎实例（用于提交缺口）
            system_tension: 当前系统张力
            tension_max: 张力上限，超过则停止生成

        Returns:
            扫描结果统计
        """
        if not self.enabled:
            return {"enabled": False, "generated": 0, "reason": "模块未启用"}

        all_memories = active_facts + active_beliefs
        if len(all_memories) < self.MIN_MEMORIES_FOR_SCAN:
            return {
                "generated": 0,
                "reason": f"记忆数量不足（{len(all_memories)} < {self.MIN_MEMORIES_FOR_SCAN}）",
            }

        self._scan_count += 1
        proposals: List[InternalGapProposal] = []

        # 1. 检测待交叉验证缺口（未验证的客观事实）
        verification_gaps = self._detect_verification_gaps(active_facts)
        proposals.extend(verification_gaps)

        # 2. 检测信息断层缺口
        info_gaps = self._detect_info_gaps(all_memories)
        proposals.extend(info_gaps)

        # 3. 检测隐含推论缺口
        inference_gaps = self._detect_implied_inferences(all_memories)
        proposals.extend(inference_gaps)

        # 过滤：去重 + 置信度阈值
        proposals = self._filter_proposals(proposals)

        # 按优先级和置信度排序
        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        proposals.sort(key=lambda p: (
            priority_order.get(p.priority, 3),
            -p.confidence,
        ))

        # 张力控制：计算还能生成多少缺口
        # 每个高优先级缺口约增加 0.1 张力，中优先级 0.05，低优先级 0.02
        tension_budget = max(0, tension_max - system_tension)
        TENSION_PER_GAP = {"critical": 0.15, "high": 0.1, "medium": 0.05, "low": 0.02}

        generated = []
        current_tension_usage = 0.0

        for prop in proposals[:self.MAX_GAPS_PER_SCAN]:
            gap_cost = TENSION_PER_GAP.get(prop.priority, 0.05)
            if current_tension_usage + gap_cost > tension_budget * 0.5:
                # 只用掉张力预算的一半，留一半给用户触发的缺口
                break

            # 提交给好奇心引擎
            try:
                gap = curiosity_engine.open_gap(
                    variable=prop.variable,
                    description=prop.description,
                    topic=f"内部探索-{prop.source.value}",
                    priority=prop.priority,
                    source="internal_auto",  # 标记为内部自动生成
                )
                generated.append({
                    "gap_id": gap.id,
                    "variable": prop.variable,
                    "source": prop.source.value,
                    "priority": prop.priority,
                    "confidence": round(prop.confidence, 3),
                })
                current_tension_usage += gap_cost
                self._total_generated += 1
            except Exception:
                continue

        return {
            "scan_id": self._scan_count,
            "total_memories_scanned": len(all_memories),
            "proposals_found": len(proposals),
            "gaps_generated": len(generated),
            "generated_gaps": generated,
            "tension_budget_used": round(current_tension_usage, 3),
            "tension_remaining": round(tension_budget - current_tension_usage, 3),
        }

    # ==================== 三类缺口检测 ====================

    def _detect_verification_gaps(self, facts: List) -> List[InternalGapProposal]:
        """检测待交叉验证缺口。

        找出已注册但来源数 < 2 的客观事实。
        """
        gaps = []
        for fact in facts:
            if not hasattr(fact, 'verified'):
                continue
            if not fact.verified:
                sources = getattr(fact, 'sources', [])
                if len(sources) < 2:
                    var = f"X(∞)_验证_{fact.id[:6]}"
                    desc = (f"事实「{fact.statement[:30]}」仅{len(sources)}个来源，"
                            f"待交叉验证后可入公理")

                    gap_id = self._make_gap_id("verification", fact.id)
                    if gap_id in self._generated_gaps:
                        continue
                    self._generated_gaps.add(gap_id)

                    gaps.append(InternalGapProposal(
                        source=GapSource.NEEDS_VERIFICATION,
                        variable=var,
                        description=desc,
                        evidence_used=[fact.id],
                        priority="medium",  # 待验证 = 中优先级
                        confidence=0.8,  # 确定性很高，因为是明确计数
                    ))
        return gaps

    def _detect_info_gaps(self, memories: List) -> List[InternalGapProposal]:
        """检测信息断层缺口。

        策略：
        - 检测记忆中存在"因为...所以..."但中间环节缺失的情况
        - 检测提到了结果但没提原因的陈述
        - 原型基于关键词模式匹配
        """
        gaps = []

        # 因果关键词对
        cause_markers = ["因为", "由于", "原因是", "导致", "所以", "因此", "结果是"]

        for mem in memories:
            stmt = getattr(mem, 'statement', str(mem))
            mid = getattr(mem, 'id', str(mem))

            # 检测有"所以/因此"但前面没有明确原因的情况
            if "所以" in stmt or "因此" in stmt:
                cause_part = stmt.split("所以")[0] if "所以" in stmt else stmt.split("因此")[0]
                if len(cause_part) < 5:  # 原因部分太短，可能信息不全
                    var = f"X(∞)_原因_{mid[:6]}"
                    desc = f"「{stmt[:30]}」提到了结论，但原因描述不充分，存在信息断层"

                    gap_id = self._make_gap_id("info_gap", mid, "cause")
                    if gap_id in self._generated_gaps:
                        continue
                    self._generated_gaps.add(gap_id)

                    gaps.append(InternalGapProposal(
                        source=GapSource.INFO_GAP,
                        variable=var,
                        description=desc,
                        evidence_used=[mid],
                        priority="low",
                        confidence=0.5,
                    ))

            # 检测有"但是"但转折原因不明确的情况
            if "但是" in stmt or "然而" in stmt:
                var = f"X(∞)_转折_{mid[:6]}"
                desc = f"「{stmt[:30]}」存在转折关系，需补充完整背景条件"

                gap_id = self._make_gap_id("info_gap", mid, "but")
                if gap_id in self._generated_gaps:
                    continue
                self._generated_gaps.add(gap_id)

                gaps.append(InternalGapProposal(
                    source=GapSource.INFO_GAP,
                    variable=var,
                    description=desc,
                    evidence_used=[mid],
                    priority="low",
                    confidence=0.4,
                ))

        return gaps

    def _detect_implied_inferences(self, memories: List) -> List[InternalGapProposal]:
        """检测隐含推论缺口。

        策略：
        - 如果记忆A提到概念X，记忆B提到概念Y，且X和Y可能有关联
        - 但记忆中没有明确说明X和Y的关系 → 隐含推论缺口
        - 原型版本：检测共同关键词的记忆对之间是否缺少关系陈述
        """
        gaps = []

        if len(memories) < 2:
            return gaps

        # 提取每条记忆的关键词
        mem_keywords = []
        for mem in memories:
            stmt = getattr(mem, 'statement', str(mem))
            mid = getattr(mem, 'id', str(mem))
            # 简单提取：找长度>=2的实词片段
            import re
            words = re.findall(r'[\u4e00-\u9fa5]{2,}', stmt)
            # 过滤停用词
            stopwords = {"什么", "怎么", "为什么", "这个", "那个", "一个", "一种",
                         "可以", "能够", "我们", "你们", "他们", "它们", "自己",
                         "不是", "就是", "还是", "或者", "以及", "的话"}
            words = [w for w in words if w not in stopwords and len(w) >= 2]
            mem_keywords.append((mid, set(words), stmt))

        # 找有重叠关键词的记忆对
        for i in range(len(mem_keywords)):
            for j in range(i + 1, len(mem_keywords)):
                mid1, kw1, stmt1 = mem_keywords[i]
                mid2, kw2, stmt2 = mem_keywords[j]

                common = kw1 & kw2
                # 至少有1个共同关键词，但不是完全重复
                if len(common) >= 1 and kw1 != kw2:
                    # 检查两条记忆是否已经明确了关系
                    combined = stmt1 + stmt2
                    relation_markers = ["关系", "影响", "导致", "因为",
                                        "所以", "相关", "关联", "作用"]
                    has_explicit_relation = any(m in combined for m in relation_markers)

                    if not has_explicit_relation:
                        common_word = list(common)[0]
                        var = f"X(∞)_关系_{common_word}"
                        desc = (f"记忆中存在多条涉及「{common_word}」的陈述，"
                                f"但未明确它们之间的关系")

                        gap_id = self._make_gap_id("inference", mid1, mid2)
                        if gap_id in self._generated_gaps:
                            continue
                        self._generated_gaps.add(gap_id)

                        # 置信度：共同关键词越多，置信度越高
                        confidence = min(0.3 + len(common) * 0.15, 0.7)

                        gaps.append(InternalGapProposal(
                            source=GapSource.IMPLIED_INFERENCE,
                            variable=var,
                            description=desc,
                            evidence_used=[mid1, mid2],
                            priority="low",
                            confidence=confidence,
                        ))

                    # 每对只生成一个缺口，避免重复
                    break

        return gaps

    # ==================== 辅助方法 ====================

    def _filter_proposals(self, proposals: List[InternalGapProposal]) -> List[InternalGapProposal]:
        """过滤提案：去重 + 置信度阈值。"""
        # 按置信度阈值过滤
        filtered = [p for p in proposals if p.confidence >= self.CONFIDENCE_THRESHOLD]
        return filtered

    def _make_gap_id(self, *parts: str) -> str:
        """生成唯一的缺口ID（用于去重）。"""
        raw = "|".join(parts)
        return hashlib.md5(raw.encode()).hexdigest()[:12]

    # ==================== 控制接口 ====================

    def enable(self):
        """启用内部自探索。"""
        self.enabled = True

    def disable(self):
        """关闭内部自探索，退回被动模式。"""
        self.enabled = False

    def reset(self):
        """重置生成历史（允许重新生成之前生成过的缺口）。"""
        self._generated_gaps.clear()
        self._scan_count = 0
        self._total_generated = 0

    # ==================== 统计 ====================

    def stats(self) -> Dict:
        """获取统计信息。"""
        return {
            "enabled": self.enabled,
            "scan_count": self._scan_count,
            "total_generated": self._total_generated,
            "unique_gap_patterns": len(self._generated_gaps),
            "config": {
                "max_gaps_per_scan": self.MAX_GAPS_PER_SCAN,
                "confidence_threshold": self.CONFIDENCE_THRESHOLD,
                "min_memories_for_scan": self.MIN_MEMORIES_FOR_SCAN,
            },
        }
