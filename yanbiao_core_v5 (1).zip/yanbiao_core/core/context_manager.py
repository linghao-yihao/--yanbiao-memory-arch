"""
对话上下文管理器 — 指代消解 + 语义确认闭环
============================================

外挂模块：不修改核心引擎，提供对话级别的上下文记忆。

解决的问题：
1. 语义确认无状态 — 用户解释后下一轮又重问
2. 指代消解缺失 — "这个""那个""它"无法回溯前文
3. 对话上下文断层 — 每轮独立处理，没有历史关联

上下文记忆三态：
- 短期：当前会话的最近N轮（活跃）
- 中期：已确认的语义消解（归档，本轮会话有效）
- 长期：用户偏好模式（跨会话，存入信念引擎）
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass
class DialogueTurn:
    """一轮对话"""
    turn_id: int
    user_input: str
    system_response: str = ""
    timestamp: float = field(default_factory=time.time)
    # 该轮中确认的语义映射 {模糊词: 明确含义}
    semantic_resolutions: Dict[str, str] = field(default_factory=dict)
    # 该轮中提到的关键实体
    entities: List[str] = field(default_factory=list)


@dataclass
class AnaphoraResolution:
    """指代消解结果"""
    resolved: bool
    original: str           # 原始输入
    resolved_text: str      # 消解后的文本（替换了指代词）
    resolutions: Dict[str, str]  # {指代词: 指代对象}
    confidence: float       # 置信度


class ContextManager:
    """对话上下文管理器。

    职责：
    1. 维护对话历史（短期记忆）
    2. 处理指代消解（这个、那个、它 → 具体实体）
    3. 语义确认闭环（用户解释过的模糊词，后续不再重复问）
    4. 上下文实体追踪
    """

    # 指代词模式
    DEMONSTRATIVE_PRONOUNS = {
        "这个": "近指单数",
        "那个": "远指单数",
        "这些": "近指复数",
        "那些": "远指复数",
        "它": "中性单数",
        "它们": "中性复数",
        "这事": "近指事件",
        "那事": "远指事件",
        "这东西": "近指事物",
        "那东西": "远指事物",
        "刚才": "时间指代",
        "之前": "时间指代",
        "上次": "时间指代",
        "前面说的": "回指前文",
        "之前说的": "回指前文",
        "刚才说的": "回指前文",
    }

    # 最大历史轮数
    MAX_HISTORY_TURNS = 10
    # 最大语义消解记忆数
    MAX_RESOLUTIONS = 50

    def __init__(self):
        # 每个用户一个对话历史
        self._histories: Dict[str, List[DialogueTurn]] = {}
        # 每个用户的语义确认记忆（已消解的模糊词映射）
        self._semantic_memory: Dict[str, Dict[str, str]] = {}
        # 每个用户的实体追踪
        self._entity_tracker: Dict[str, List[Dict]] = {}
        # 当前轮次计数
        self._turn_counters: Dict[str, int] = {}

    # ==================== 对话历史管理 ====================

    def add_turn(self, user_id: str, user_input: str) -> DialogueTurn:
        """添加新一轮用户输入，返回该轮对象。"""
        if user_id not in self._histories:
            self._histories[user_id] = []
            self._semantic_memory[user_id] = {}
            self._entity_tracker[user_id] = []
            self._turn_counters[user_id] = 0

        self._turn_counters[user_id] += 1
        turn = DialogueTurn(
            turn_id=self._turn_counters[user_id],
            user_input=user_input,
        )
        self._histories[user_id].append(turn)

        # 限制历史长度
        if len(self._histories[user_id]) > self.MAX_HISTORY_TURNS:
            self._histories[user_id] = self._histories[user_id][-self.MAX_HISTORY_TURNS:]

        return turn

    def update_turn_response(self, user_id: str, response: str):
        """更新当前轮的系统回复。"""
        history = self._histories.get(user_id, [])
        if history:
            history[-1].system_response = response

    def get_history(self, user_id: str, n: int = 5) -> List[DialogueTurn]:
        """获取最近N轮对话历史。"""
        history = self._histories.get(user_id, [])
        return history[-n:] if history else []

    def get_current_turn(self, user_id: str) -> Optional[DialogueTurn]:
        """获取当前轮（最后一轮）。"""
        history = self._histories.get(user_id, [])
        return history[-1] if history else None

    # ==================== 语义确认闭环 ====================

    def remember_resolution(self, user_id: str, ambiguous_word: str,
                            resolved_meaning: str):
        """记住一个语义消解结果，后续不再问同样的问题。

        Args:
            user_id: 用户ID
            ambiguous_word: 模糊词（如"这个"）
            resolved_meaning: 用户解释的明确含义（如"指代你自身"）
        """
        if user_id not in self._semantic_memory:
            self._semantic_memory[user_id] = {}

        self._semantic_memory[user_id][ambiguous_word] = resolved_meaning

        # 同时写入当前轮
        current = self.get_current_turn(user_id)
        if current:
            current.semantic_resolutions[ambiguous_word] = resolved_meaning

        # 限制记忆数量
        if len(self._semantic_memory[user_id]) > self.MAX_RESOLUTIONS:
            # 去掉最早的（字典在Python 3.7+是有序的）
            keys = list(self._semantic_memory[user_id].keys())
            for k in keys[:-self.MAX_RESOLUTIONS]:
                del self._semantic_memory[user_id][k]

    def get_known_resolutions(self, user_id: str) -> Dict[str, str]:
        """获取该用户已确认的所有语义消解。"""
        return dict(self._semantic_memory.get(user_id, {}))

    def filter_known_ambiguities(self, user_id: str,
                                 ambiguous_words: List[str]) -> List[str]:
        """过滤掉已经确认过的模糊词，只返回还需要问的。"""
        known = self._semantic_memory.get(user_id, {})
        return [w for w in ambiguous_words if w not in known]

    # ==================== 指代消解 ====================

    def resolve_anaphora(self, user_id: str, text: str) -> AnaphoraResolution:
        """指代消解：把"这个""那个"等指代词替换为具体实体。

        策略：
        1. 检测文本中的指代词
        2. 从最近的对话历史中寻找候选实体
        3. 基于距离和相关性选择最佳匹配
        4. 如果置信度低，保留原词（不强行消解）
        """
        resolutions: Dict[str, str] = {}
        resolved_text = text

        # 检测指代词（按长度从长到短匹配，避免"这个"匹配掉"这个东西"）
        found_pronouns = []
        for pronoun in sorted(self.DEMONSTRATIVE_PRONOUNS.keys(), key=len, reverse=True):
            if pronoun in text:
                found_pronouns.append(pronoun)

        if not found_pronouns:
            return AnaphoraResolution(
                resolved=False,
                original=text,
                resolved_text=text,
                resolutions={},
                confidence=1.0,
            )

        # 从历史中提取候选实体
        candidates = self._extract_candidate_entities(user_id)

        for pronoun in found_pronouns:
            if pronoun not in text:
                continue

            # 找最佳候选
            best_candidate, confidence = self._find_best_candidate(
                pronoun, candidates, text, user_id
            )

            if best_candidate and confidence >= 0.5:
                resolutions[pronoun] = best_candidate
                resolved_text = resolved_text.replace(pronoun, best_candidate)

        if resolutions:
            # 计算平均置信度（基于每个消解的置信度，这里简化为候选数量反比）
            avg_confidence = 0.6 if len(resolutions) == 1 else 0.5
            return AnaphoraResolution(
                resolved=True,
                original=text,
                resolved_text=resolved_text,
                resolutions=resolutions,
                confidence=avg_confidence,
            )
        else:
            return AnaphoraResolution(
                resolved=False,
                original=text,
                resolved_text=text,
                resolutions={},
                confidence=0.0,
            )

    # ==================== 实体追踪 ====================

    def track_entity(self, user_id: str, entity: str,
                     context: str = "", importance: float = 0.5):
        """追踪一个在对话中出现的实体。"""
        if user_id not in self._entity_tracker:
            self._entity_tracker[user_id] = []

        # 检查是否已存在，存在则更新时间和重要性
        for ent in self._entity_tracker[user_id]:
            if ent["entity"] == entity:
                ent["last_seen"] = time.time()
                ent["importance"] = min(ent["importance"] + 0.1, 1.0)
                ent["context"] = context or ent["context"]
                return

        # 新增实体
        self._entity_tracker[user_id].append({
            "entity": entity,
            "context": context,
            "first_seen": time.time(),
            "last_seen": time.time(),
            "importance": importance,
            "mention_count": 1,
        })

        # 限制实体数量
        if len(self._entity_tracker[user_id]) > 30:
            # 按重要性+最近访问排序，保留前20
            self._entity_tracker[user_id].sort(
                key=lambda e: e["importance"] + (1.0 if time.time() - e["last_seen"] < 60 else 0),
                reverse=True
            )
            self._entity_tracker[user_id] = self._entity_tracker[user_id][:20]

    def get_entities(self, user_id: str, top_n: int = 10) -> List[Dict]:
        """获取最近/最重要的实体列表。"""
        entities = self._entity_tracker.get(user_id, [])
        # 按最近提及+重要性排序
        sorted_ents = sorted(
            entities,
            key=lambda e: e["last_seen"] * 0.7 + e["importance"] * 1000,
            reverse=True,
        )
        return sorted_ents[:top_n]

    # ==================== 预处理入口 ====================

    def preprocess_input(self, user_id: str, user_input: str) -> Dict:
        """对用户输入做上下文预处理，返回处理结果。

        Returns:
            {
                "original": 原始输入,
                "resolved": 指代消解后的文本,
                "anaphora": 指代消解详情,
                "known_ambiguities": 已知的语义消解,
                "needs_confirmation": 还需要确认的模糊词列表,
                "context_entities": 上下文中的相关实体,
            }
        """
        # 1. 添加到对话历史
        self.add_turn(user_id, user_input)

        # 2. 指代消解
        anaphora = self.resolve_anaphora(user_id, user_input)

        # 3. 检测模糊词并过滤已确认的
        ambiguous_found = self._detect_ambiguous_words(user_input)
        needs_confirm = self.filter_known_ambiguities(user_id, ambiguous_found)

        # 4. 获取相关实体
        entities = self.get_entities(user_id, top_n=5)

        return {
            "original": user_input,
            "resolved": anaphora.resolved_text,
            "anaphora": {
                "resolved": anaphora.resolved,
                "resolutions": anaphora.resolutions,
                "confidence": anaphora.confidence,
            },
            "known_ambiguities": self.get_known_resolutions(user_id),
            "needs_confirmation": needs_confirm,
            "context_entities": entities,
        }

    # ==================== 内部方法 ====================

    def _detect_ambiguous_words(self, text: str) -> List[str]:
        """检测文本中的模糊词。"""
        found = []
        for pronoun in sorted(self.DEMONSTRATIVE_PRONOUNS.keys(), key=len, reverse=True):
            if pronoun in text:
                found.append(pronoun)
        return found

    def _extract_candidate_entities(self, user_id: str) -> List[str]:
        """从对话历史中提取候选实体列表。

        优先级：
        1. 实体追踪器中的实体（重要度高）
        2. 最近几轮用户输入中的名词短语
        3. 语义确认记忆中的消解结果
        """
        candidates = []

        # 1. 实体追踪器
        entities = self.get_entities(user_id, top_n=10)
        for ent in entities:
            candidates.append(ent["entity"])

        # 2. 语义确认记忆（已知指代）
        known = self.get_known_resolutions(user_id)
        for meaning in known.values():
            if meaning not in candidates:
                candidates.append(meaning)

        # 3. 最近用户输入中的关键短语（2字以上）
        history = self.get_history(user_id, n=3)
        for turn in reversed(history):  # 最近的在前
            phrases = re.findall(r'[\u4e00-\u9fa5A-Za-z0-9]{2,}', turn.user_input)
            for p in phrases:
                if len(p) >= 2 and p not in candidates:
                    candidates.append(p)

        return candidates

    def _find_best_candidate(
        self,
        pronoun: str,
        candidates: List[str],
        current_text: str,
        user_id: str,
    ) -> Tuple[Optional[str], float]:
        """为指代词找最佳候选实体。

        评分因素：
        - 距离：越近的轮次权重越高
        - 相关性：与当前上下文的词汇重叠度
        - 实体类型匹配："他/她"匹配人，"它"匹配物
        """
        if not candidates:
            return None, 0.0

        # 自问模式特殊处理："这个"在"这个主体"上下文中 → 可能指系统自身
        if "主体" in current_text and pronoun in ["这个"]:
            # 检查是否在讨论系统自身
            history = self.get_history(user_id, n=3)
            for turn in history:
                if any(w in turn.user_input for w in ["你", "系统", "主体", "自身"]):
                    # "这个主体"很可能指系统
                    return "你自身", 0.7

        # 默认取第一个候选（最近提及的）
        best = candidates[0]
        confidence = 0.6 if len(candidates) == 1 else 0.4

        return best, confidence

    # ==================== 状态清理 ====================

    def clear_context(self, user_id: str):
        """清空用户的所有上下文（会话重置）。"""
        self._histories.pop(user_id, None)
        self._semantic_memory.pop(user_id, None)
        self._entity_tracker.pop(user_id, None)
        self._turn_counters.pop(user_id, None)

    def stats(self, user_id: str = None) -> Dict:
        """获取上下文统计。"""
        if user_id:
            return {
                "history_turns": len(self._histories.get(user_id, [])),
                "semantic_resolutions": len(self._semantic_memory.get(user_id, {})),
                "tracked_entities": len(self._entity_tracker.get(user_id, [])),
            }
        else:
            return {
                "total_users": len(self._histories),
                "user_ids": list(self._histories.keys()),
            }

    def get_turn_count(self, user_id: str) -> int:
        """获取用户对话轮数。"""
        return len(self._histories.get(user_id, []))
