"""
模块2：user_emotion_detector 用户情绪识别模块
===============================================

外挂模块：识别用户情绪，用于调整回复语气。

设计原则：
- 只识别用户情绪，不实现AI自身情绪
- 区分瞬时情绪 / 长期心理状态
- 情绪信号仅用于输出修饰，禁止参与事实推理
- 负面情绪时，抑制系统主动探索提问
- 原型用关键词实现，后续可无缝替换LLM识别

瞬时情绪（emotion）：
- 仅本轮上下文生效，用于调整回复语气
- 会话结束直接丢弃，不持久化

长期心理状态（mood）：
- 滑动窗口多次重复出现，才生成 user_core 信念
- 状态变更时旧内容归档
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple


class EmotionType(str, Enum):
    """情绪类型"""
    HAPPY = "happy"           # 开心/积极
    CALM = "calm"             # 平静/中性
    FRUSTRATED = "frustrated" # 烦躁/挫败
    SAD = "sad"               # 难过/低落
    ANGRY = "angry"           # 愤怒
    ANXIOUS = "anxious"       # 焦虑/担忧
    CURIOUS = "curious"       # 好奇/探索
    TIRED = "tired"           # 疲惫
    EXCITED = "excited"       # 兴奋/激动


class EmotionIntensity(str, Enum):
    """情绪强度"""
    MILD = "mild"       # 轻微
    MODERATE = "moderate"  # 中等
    STRONG = "strong"   # 强烈


@dataclass
class EmotionDetection:
    """单次情绪检测结果"""
    primary_emotion: EmotionType       # 主情绪
    intensity: EmotionIntensity        # 强度
    confidence: float                  # 置信度 0~1
    triggers: List[str]                # 触发关键词
    is_negative: bool                  # 是否为负面情绪
    raw_input: str                     # 原始输入
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict:
        return {
            "primary_emotion": self.primary_emotion.value,
            "intensity": self.intensity.value,
            "confidence": round(self.confidence, 3),
            "triggers": self.triggers,
            "is_negative": self.is_negative,
            "timestamp": self.timestamp,
        }


@dataclass
class MoodState:
    """长期心理状态（滑动窗口统计）"""
    user_id: str
    window_size: int = 20          # 滑动窗口大小（轮次）
    _emotion_history: List[EmotionDetection] = field(default_factory=list)
    _dominant_mood: Optional[EmotionType] = None
    _mood_confidence: float = 0.0
    _last_updated: float = field(default_factory=time.time)

    def add_emotion(self, detection: EmotionDetection):
        """添加一次情绪检测到滑动窗口。"""
        self._emotion_history.append(detection)
        if len(self._emotion_history) > self.window_size:
            self._emotion_history.pop(0)
        self._recompute_mood()
        self._last_updated = time.time()

    def _recompute_mood(self):
        """重新计算主导心境。"""
        if len(self._emotion_history) < 5:  # 样本太少不判定
            self._dominant_mood = None
            self._mood_confidence = 0.0
            return

        # 统计各情绪出现次数（加权：越近权重越高）
        emotion_scores: Dict[str, float] = {}
        total_weight = 0.0

        for i, emo in enumerate(self._emotion_history):
            # 时间衰减权重：越近权重越高
            recency_weight = 0.5 + 0.5 * (i / len(self._emotion_history))
            weight = emo.confidence * recency_weight
            key = emo.primary_emotion.value
            emotion_scores[key] = emotion_scores.get(key, 0) + weight
            total_weight += weight

        if total_weight == 0:
            self._dominant_mood = None
            self._mood_confidence = 0.0
            return

        # 找出占比最高的情绪
        max_emotion = max(emotion_scores, key=emotion_scores.get)
        max_ratio = emotion_scores[max_emotion] / total_weight

        # 超过阈值才认定为主导心境
        MOOD_THRESHOLD = 0.35  # 占比超过35%才算主导心境
        if max_ratio >= MOOD_THRESHOLD:
            self._dominant_mood = EmotionType(max_emotion)
            self._mood_confidence = max_ratio
        else:
            self._dominant_mood = None
            self._mood_confidence = 0.0

    def get_dominant_mood(self) -> Tuple[Optional[EmotionType], float]:
        """获取当前主导心境及置信度。"""
        return self._dominant_mood, self._mood_confidence

    def is_persistently_negative(self) -> bool:
        """是否持续处于负面情绪状态（可能需要生成长期心理状态信念）。"""
        if self._dominant_mood is None:
            return False
        negatives = {EmotionType.FRUSTRATED, EmotionType.SAD,
                     EmotionType.ANGRY, EmotionType.ANXIOUS, EmotionType.TIRED}
        return self._dominant_mood in negatives and self._mood_confidence >= 0.4

    def to_dict(self) -> Dict:
        mood, conf = self.get_dominant_mood()
        return {
            "user_id": self.user_id,
            "window_size": self.window_size,
            "samples_in_window": len(self._emotion_history),
            "dominant_mood": mood.value if mood else None,
            "mood_confidence": round(conf, 3),
            "is_persistently_negative": self.is_persistently_negative(),
            "recent_emotions": [e.primary_emotion.value for e in self._emotion_history[-5:]],
        }


class UserEmotionDetector:
    """用户情绪识别器。

    原型用关键词匹配实现，后续可无缝替换为LLM识别。

    约束：
    - 情绪信号仅用于输出修饰
    - 禁止参与事实推理
    - 负面情绪时抑制主动探索提问
    """

    # ===== 情绪关键词词典 =====
    # 格式: {情绪类型: [(关键词, 强度权重), ...]}

    EMOTION_KEYWORDS: Dict[EmotionType, List[Tuple[str, float]]] = {
        EmotionType.HAPPY: [
            ("哈哈", 0.6), ("哈哈哈", 0.8), ("开心", 0.7), ("不错", 0.3),
            ("挺好", 0.4), ("赞", 0.5), ("棒", 0.5), ("喜欢", 0.4),
            ("太好了", 0.7), ("有趣", 0.4), ("有意思", 0.4),
        ],
        EmotionType.FRUSTRATED: [
            ("烦", 0.5), ("烦死了", 0.8), ("无语", 0.5), ("离谱", 0.4),
            ("搞不懂", 0.4), ("太难了", 0.5), ("心累", 0.6), ("崩溃", 0.8),
            ("受不了", 0.7), ("服了", 0.5), ("麻了", 0.4), ("折腾", 0.3),
        ],
        EmotionType.SAD: [
            ("难过", 0.7), ("伤心", 0.7), ("失落", 0.6), ("沮丧", 0.6),
            ("遗憾", 0.4), ("可惜", 0.4), ("哭", 0.6), ("呜呜", 0.7),
            ("emo", 0.5), ("抑郁", 0.7), ("空虚", 0.5),
        ],
        EmotionType.ANGRY: [
            ("生气", 0.7), ("愤怒", 0.8), ("气死", 0.8), ("恼火", 0.7),
            ("扯淡", 0.5), ("狗屁", 0.6), ("离谱", 0.3), ("什么鬼", 0.5),
            ("凭什么", 0.6), ("不公平", 0.5),
        ],
        EmotionType.ANXIOUS: [
            ("担心", 0.6), ("焦虑", 0.7), ("害怕", 0.6), ("恐惧", 0.8),
            ("不安", 0.5), ("紧张", 0.5), ("压力大", 0.6), ("纠结", 0.5),
            ("犹豫", 0.4), ("没底", 0.5), ("慌", 0.6),
        ],
        EmotionType.CURIOUS: [
            ("为什么", 0.3), ("怎么", 0.2), ("想知道", 0.5), ("好奇", 0.7),
            ("有意思", 0.3), ("原理", 0.4), ("机制", 0.4), ("探索", 0.5),
            ("研究", 0.3), ("试试", 0.3),
        ],
        EmotionType.TIRED: [
            ("累", 0.5), ("疲惫", 0.7), ("困", 0.5), ("没精神", 0.6),
            ("乏", 0.5), ("没劲", 0.5), ("想休息", 0.6), ("撑不住", 0.7),
        ],
        EmotionType.EXCITED: [
            ("太棒了", 0.8), ("牛", 0.5), ("牛逼", 0.7), ("厉害", 0.5),
            ("激动", 0.7), ("兴奋", 0.7), ("期待", 0.5), ("爽", 0.6),
        ],
    }

    # 负面情绪集合
    NEGATIVE_EMOTIONS = {
        EmotionType.FRUSTRATED, EmotionType.SAD, EmotionType.ANGRY,
        EmotionType.ANXIOUS, EmotionType.TIRED,
    }

    # 情绪强度判定阈值
    INTENSITY_STRONG = 0.7
    INTENSITY_MODERATE = 0.4

    def __init__(self):
        self._moods: Dict[str, MoodState] = {}  # {user_id: MoodState}

    # ==================== 核心检测 ====================

    def detect(self, user_input: str, user_id: str = "default") -> EmotionDetection:
        """检测用户输入中的情绪。

        算法：
        1. 对每种情绪，累加所有匹配关键词的权重
        2. 取权重最高的情绪为主情绪
        3. 根据总权重判定强度
        4. 置信度基于匹配词数量和权重总和
        """
        emotion_scores: Dict[EmotionType, float] = {}
        all_triggers: List[str] = []

        for emotion, keywords in self.EMOTION_KEYWORDS.items():
            score = 0.0
            triggers = []
            for keyword, weight in keywords:
                if keyword in user_input:
                    score += weight
                    triggers.append(keyword)
            if score > 0:
                emotion_scores[emotion] = score
                all_triggers.extend(triggers)

        # 没有检测到任何情绪 → 平静
        if not emotion_scores:
            detection = EmotionDetection(
                primary_emotion=EmotionType.CALM,
                intensity=EmotionIntensity.MILD,
                confidence=0.3,  # 平静的置信度低，因为是默认值
                triggers=[],
                is_negative=False,
                raw_input=user_input,
            )
        else:
            # 取得分最高的情绪
            primary = max(emotion_scores, key=emotion_scores.get)
            max_score = emotion_scores[primary]

            # 判定强度
            if max_score >= self.INTENSITY_STRONG:
                intensity = EmotionIntensity.STRONG
            elif max_score >= self.INTENSITY_MODERATE:
                intensity = EmotionIntensity.MODERATE
            else:
                intensity = EmotionIntensity.MILD

            # 置信度：基于匹配强度和匹配词数量
            match_count = len(all_triggers)
            count_factor = min(match_count / 3.0, 1.0)  # 3个词以上满
            score_factor = min(max_score / 1.5, 1.0)
            confidence = 0.3 + 0.4 * score_factor + 0.3 * count_factor
            confidence = min(confidence, 1.0)

            detection = EmotionDetection(
                primary_emotion=primary,
                intensity=intensity,
                confidence=confidence,
                triggers=all_triggers,
                is_negative=primary in self.NEGATIVE_EMOTIONS,
                raw_input=user_input,
            )

        # 更新长期心境
        self._update_mood(user_id, detection)

        return detection

    def _update_mood(self, user_id: str, detection: EmotionDetection):
        """更新用户的长期心境状态。"""
        if user_id not in self._moods:
            self._moods[user_id] = MoodState(user_id=user_id)
        self._moods[user_id].add_emotion(detection)

    # ==================== 查询接口 ====================

    def get_mood(self, user_id: str) -> Optional[MoodState]:
        """获取用户的长期心境状态。"""
        return self._moods.get(user_id)

    def should_suppress_curiosity(self, user_id: str) -> bool:
        """是否应该抑制好奇心（用户负面情绪时，少主动提问）。

        返回 True 时，系统应减少主动探索性提问。
        """
        mood = self._moods.get(user_id)
        if not mood:
            return False
        return mood.is_persistently_negative()

    def get_response_style_hint(self, detection: EmotionDetection,
                                mood: Optional[MoodState] = None) -> str:
        """生成回复风格提示（给输出层用）。

        严格隔离：此提示仅修饰语气，不参与事实推理。
        """
        hints = []

        # 基于瞬时情绪
        if detection.is_negative:
            if detection.primary_emotion == EmotionType.FRUSTRATED:
                hints.append("用户略显烦躁，回复应简洁耐心，避免过多提问")
            elif detection.primary_emotion == EmotionType.SAD:
                hints.append("用户情绪低落，语气应温和包容，给予情感支持")
            elif detection.primary_emotion == EmotionType.ANGRY:
                hints.append("用户有愤怒情绪，保持中立客观，避免激化")
            elif detection.primary_emotion == EmotionType.ANXIOUS:
                hints.append("用户有焦虑感，提供清晰确定的信息，减少模糊表述")
            elif detection.primary_emotion == EmotionType.TIRED:
                hints.append("用户状态疲惫，回复简洁凝练，避免冗长")
        elif detection.primary_emotion == EmotionType.HAPPY:
            hints.append("用户情绪积极，可保持轻松愉快的语气")
        elif detection.primary_emotion == EmotionType.CURIOUS:
            hints.append("用户有探索欲，可适当拓展相关话题")
        elif detection.primary_emotion == EmotionType.EXCITED:
            hints.append("用户情绪兴奋，可保持热情呼应")

        # 基于长期心境（如果有）
        if mood and mood.is_persistently_negative():
            hints.insert(0, "用户近期情绪偏负面，整体保持温和支持态度")

        return "；".join(hints) if hints else "语气自然"

    # ==================== 统计 ====================

    def stats(self, user_id: str = None) -> Dict:
        """获取情绪检测统计。"""
        if user_id:
            mood = self._moods.get(user_id)
            return {
                "mood": mood.to_dict() if mood else None,
                "suppress_curiosity": self.should_suppress_curiosity(user_id),
            }
        else:
            return {
                "total_users": len(self._moods),
                "user_ids": list(self._moods.keys()),
            }
