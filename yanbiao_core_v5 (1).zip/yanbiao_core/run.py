"""
延标核心系统 v1.0 — 启动入口
运行方式：python run.py
详细说明见 README.md
"""

import os
import sys


def check_dependencies():
    """检查依赖是否安装，缺了就给出安装提示。"""
    missing = []

    try:
        import flask  # noqa: F401
    except ImportError:
        missing.append("flask")

    if missing:
        print("=" * 60)
        print("  ⚠️  缺少依赖，正在尝试安装...")
        print("=" * 60)
        import subprocess
        for pkg in missing:
            print(f"  安装 {pkg}...", end=" ")
            try:
                subprocess.check_call(
                    [sys.executable, "-m", "pip", "install", pkg, "-q",
                     "--break-system-packages"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                print("✅")
            except subprocess.CalledProcessError:
                print("❌ 自动安装失败")
                print()
                print("  请手动执行以下命令安装：")
                print(f"    pip install {' '.join(missing)}")
                print()
                print("  如果在 Windows 上，也可以试试：")
                print(f"    python -m pip install {' '.join(missing)}")
                sys.exit(1)
        print("  安装完成！")
        print()


def print_banner():
    """打印启动横幅。"""
    banner = r"""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║    延 标 核 心 系 统  v1.0                                    ║
║    Yanbiao Core System — 元认知协议引擎                      ║
║                                                              ║
║    我知道我在  ·  事实独裁  ·  开放包容                      ║
║    认知有边界  ·  缺口即动力  ·  共生协作                    ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
"""
    print(banner)


def print_module_info(core):
    """打印模块状态信息。"""
    state = core.get_system_state()

    print("  📦 核心模块状态:")
    proto_list = state['protocols'].get('core_protocols', [])
    print(f"     协议层: {len(proto_list)} 条不可撼动公理")
    print(f"     事实库: {state['facts']['total']} 条")
    print(f"     信念库: {state['beliefs']['total']} 条")
    print(f"     沙盒: {state['sandbox']['total_sessions']} 个推演会话")
    print()

    print("  🧩 外挂扩展模块:")
    modules = state.get('modules', {})
    module_names = {
        "memory_selector": "记忆选择器（主动遗忘 + 数字镜像）",
        "emotion_detector": "用户情绪识别",
        "auto_internal_gap": "内部自探索缺口生成",
        "suspended_search": "悬置查找调度器",
    }
    for key, name in module_names.items():
        status = "✅ 已启用" if modules.get(key, False) else "⭕ 未启用"
        print(f"     {status}  {name}")
    print()

    tension = state.get('system_tension', {})
    curiosity = state.get('curiosity', {})
    print(f"  🧠 系统张力: {tension.get('tension_level', 0):.1%} "
          f"({tension.get('feeling', '平静')})")
    print(f"     认知缺口: {curiosity.get('total', 0)} 个 "
          f"（开放 {curiosity.get('open', 0)} / "
          f"闭合 {curiosity.get('closed', 0)}）")
    print()


def main():
    # 切换到脚本所在目录（确保相对路径正确）
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    # 检查依赖
    check_dependencies()

    # 导入配置
    from config import system as config

    # 导入核心
    from orchestrator import YanbiaoCore
    from app import app

    print_banner()

    # 初始化核心
    data_dir = os.path.join(script_dir, config.DATA_DIR)
    core = YanbiaoCore(storage_path=data_dir)

    # 设置模块开关
    core.modules_enabled["memory_selector"] = config.ENABLE_MEMORY_SELECTOR
    core.modules_enabled["emotion_detector"] = config.ENABLE_EMOTION_DETECTOR
    core.modules_enabled["auto_internal_gap"] = config.ENABLE_AUTO_INTERNAL_GAP
    core.modules_enabled["suspended_search"] = config.ENABLE_SUSPENDED_SEARCH

    # 把核心实例挂到 app 上
    app.core = core

    # 打印信息
    print_module_info(core)

    print("  🌐 访问地址:")
    print(f"     本机: http://localhost:{config.PORT}")
    print(f"     局域网: http://<你的IP>:{config.PORT}")
    print()
    print("  💡 提示:")
    print("     · 改参数编辑 config.py")
    print("     · 按 Ctrl+C 停止服务")
    print()
    print("  " + "═" * 58)
    print()

    # 启动服务
    try:
        app.run(
            host=config.HOST,
            port=config.PORT,
            debug=config.DEBUG,
        )
    except KeyboardInterrupt:
        print("\n\n  👋 已停止服务，再见！")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"  ❌ 端口 {config.PORT} 被占用了！")
            print(f"     改一下 config.py 里的 PORT 就行，比如改成 5999")
        else:
            print(f"  ❌ 启动失败: {e}")


if __name__ == "__main__":
    main()
