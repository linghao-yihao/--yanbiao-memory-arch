"""
延标核心系统 — 全局配置文件
==============================

新手只需要改这里的参数就行，不用到处找代码。
每个参数都有注释说明是什么意思。
"""

from dataclasses import dataclass


@dataclass
class SystemConfig:
    """系统基本配置"""

    # ===== 服务配置 =====
    HOST: str = "0.0.0.0"      # 监听地址，0.0.0.0 表示所有地址都能访问
    PORT: int = 5998             # 端口号，改这个就能换端口
    DEBUG: bool = False          # 调试模式，出问题时改成 True 可以看到详细错误

    # ===== 数据存储 =====
    DATA_DIR: str = "data"       # 数据存在哪个文件夹里（相对于项目根目录）

    # ===== 模块开关 =====
    # 不想用哪个模块就改成 False
    ENABLE_MEMORY_SELECTOR: bool = True      # 记忆选择器（主动遗忘）
    ENABLE_EMOTION_DETECTOR: bool = True     # 用户情绪识别
    ENABLE_AUTO_INTERNAL_GAP: bool = True    # 内部自探索缺口生成
    ENABLE_SUSPENDED_SEARCH: bool = True     # 悬置查找调度器
    ENABLE_SEMANTIC_RETRIEVER: bool = True   # 分层语义检索
    ENABLE_CONTEXT_MANAGER: bool = True      # 对话上下文管理


@dataclass
class MemoryConfig:
    """记忆选择器配置"""

    # 普通记忆闲置多久考虑淘汰（单位：天）
    IDLE_TIMEOUT_DAYS: int = 7

    # 新记忆最少保留多久才允许淘汰（单位：小时）
    MIN_RESIDENCE_HOURS: int = 24

    # 活跃记忆池最多存多少条
    MAX_ACTIVE_CAPACITY: int = 200

    # 容量达到多少百分比触发淘汰（0.9 = 90%）
    EVICTION_THRESHOLD: float = 0.9

    # 每次淘汰多少比例
    EVICTION_RATIO: float = 0.2

    # 价值评分权重（三个加起来=1就行）
    WEIGHT_ACCESS_COUNT: float = 0.4    # 访问频率权重
    WEIGHT_RECENCY: float = 0.5         # 最近访问权重
    WEIGHT_AGE: float = 0.1             # 记忆年龄权重

    # 数字镜像滑动窗口大小（最近多少轮）
    MIRROR_WINDOW_SIZE: int = 50


@dataclass
class EmotionConfig:
    """情绪识别配置"""

    # 情绪强度阈值
    INTENSITY_STRONG: float = 0.7
    INTENSITY_MODERATE: float = 0.4

    # 长期心境滑动窗口大小
    MOOD_WINDOW_SIZE: int = 20

    # 主导心境判定阈值（占比超过多少才算主导）
    MOOD_THRESHOLD: float = 0.35

    # 持续负面心境判定阈值
    NEGATIVE_MOOD_CONFIDENCE: float = 0.4


@dataclass
class CuriosityConfig:
    """好奇心引擎配置"""

    # 张力阈值
    TENSION_NOTICE: float = 0.15      # 开始注意到缺口
    TENSION_DISCOMFORT: float = 0.35   # 开始感到不适
    TENSION_URGE: float = 0.55         # 强烈补全欲，主动提问
    TENSION_MAX: float = 1.0           # 最大张力

    # 优先级权重（影响张力增长速度）
    PRIORITY_WEIGHT_CRITICAL: float = 1.0
    PRIORITY_WEIGHT_HIGH: float = 0.7
    PRIORITY_WEIGHT_MEDIUM: float = 0.4
    PRIORITY_WEIGHT_LOW: float = 0.2

    # 张力自然衰减速度（每秒降低多少）
    TENSION_DECAY_RATE: float = 0.01


@dataclass
class AutoGapConfig:
    """内部自探索缺口生成配置"""

    # 单次扫描最多生成多少个缺口
    MAX_GAPS_PER_SCAN: int = 5

    # 生成置信度阈值（低于这个值的缺口不提交）
    CONFIDENCE_THRESHOLD: float = 0.4

    # 最少多少条记忆才启动扫描
    MIN_MEMORIES_FOR_SCAN: int = 5


@dataclass
class SearchConfig:
    """悬置查找调度器配置"""

    # 最大并发任务数
    MAX_PARALLEL_TASKS: int = 10

    # 任务超时时间（秒）
    TASK_TIMEOUT: int = 30

    # 最大排队任务数
    MAX_QUEUE_SIZE: int = 50

    # 单次查找最多找多少条证据
    MAX_EVIDENCE_PER_SEARCH: int = 5

    # 增量重试最大次数
    MAX_INCREMENTAL_ATTEMPTS: int = 3


@dataclass
class ContextConfig:
    """上下文管理配置"""

    # 最多保留多少轮对话历史
    MAX_HISTORY_TURNS: int = 10

    # 最多记住多少个语义消解结果
    MAX_RESOLUTIONS: int = 50

    # 最多追踪多少个实体
    MAX_TRACKED_ENTITIES: int = 20


# ===== 创建全局配置实例 =====

system = SystemConfig()
memory = MemoryConfig()
emotion = EmotionConfig()
curiosity = CuriosityConfig()
auto_gap = AutoGapConfig()
search = SearchConfig()
context = ContextConfig()
