@echo off
cd /d "%~dp0"

REM Try to find Python
where python >nul 2>&1
if errorlevel 1 (
    where py >nul 2>&1
    if errorlevel 1 (
        echo [ERROR] Python not found!
        echo.
        echo Please install Python 3.8 or higher:
        echo   https://www.python.org/downloads/
        echo IMPORTANT: Check "Add Python to PATH" during installation!
        echo.
        pause
        exit /b 1
    )
    py "%~dp0启动.py"
) else (
    python "%~dp0启动.py"
)

if errorlevel 1 (
    echo.
    echo [ERROR] Startup failed. Please check the message above.
    echo.
    pause
)
