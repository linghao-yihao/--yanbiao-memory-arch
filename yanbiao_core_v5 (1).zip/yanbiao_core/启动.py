#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
延标系统 - 一键启动脚本（小白友好版）
双击运行即可，自动检查依赖、自动启动浏览器
"""
import sys
import os
import subprocess
import time
import webbrowser

# Windows 控制台 UTF-8 兼容
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except:
        pass

def print_logo():
    print()
    print("  ╔══════════════════════════════════════╗")
    print("  ║                                      ║")
    print("  ║     🧠  延  标  系  统  V2          ║")
    print("  ║                                      ║")
    print("  ║     元认知协议 · 坦诚面对未知        ║")
    print("  ║                                      ║")
    print("  ╚══════════════════════════════════════╝")
    print()

def check_python():
    """检查Python版本"""
    print("🔍 检查Python环境...")
    version = sys.version_info
    if version.major >= 3 and version.minor >= 8:
        print(f"   ✓ Python {version.major}.{version.minor}.{version.micro}  OK")
        return True
    else:
        print(f"   ✗ Python版本过低：{version.major}.{version.minor}")
        print("   💡 请安装 Python 3.8 或更高版本")
        print("   下载地址：https://www.python.org/downloads/")
        return False

def check_and_install_deps():
    """检查并安装依赖"""
    print("🔍 检查依赖包...")
    
    required = {
        "flask": "Flask",
    }
    
    missing = []
    for pkg, display_name in required.items():
        try:
            __import__(pkg)
            print(f"   ✓ {display_name}  已安装")
        except ImportError:
            missing.append(pkg)
            print(f"   ✗ {display_name}  未安装")
    
    if missing:
        print()
        print("📦 正在自动安装缺少的依赖...")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install"] + missing,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            print("   ✓ 依赖安装成功！")
        except Exception as e:
            print(f"   ✗ 安装失败：{e}")
            print("   💡 试试手动运行：pip install flask")
            return False
    
    return True

def start_server():
    """启动服务"""
    print()
    print("🚀 启动延标系统...")
    
    # 获取脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    # 启动Flask
    try:
        from app import app
        port = 5998
        
        print(f"   ✓ 服务启动中...")
        print(f"   ✓ 本地地址：http://localhost:{port}")
        print()
        print("💡 小提示：")
        print("   • 浏览器会自动打开，如果没打开请手动访问上面的地址")
        print("   • 关闭这个窗口就会停止服务")
        print("   • 第一次使用可以先试试说「你好」")
        print()
        
        # 延迟一下再打开浏览器，等服务启动
        def open_browser():
            time.sleep(1.5)
            try:
                webbrowser.open(f"http://localhost:{port}")
            except:
                pass
        
        import threading
        threading.Thread(target=open_browser, daemon=True).start()
        
        # 启动服务（生产模式，不显示debug信息）
        app.run(host="0.0.0.0", port=port, debug=False)
        
    except Exception as e:
        print(f"   ✗ 启动失败：{e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

def main():
    print_logo()
    
    # 1. 检查Python
    if not check_python():
        input("\n按回车键退出...")
        return
    
    # 2. 检查依赖
    if not check_and_install_deps():
        input("\n按回车键退出...")
        return
    
    # 3. 启动服务
    try:
        start_server()
    except KeyboardInterrupt:
        print("\n\n👋 已停止服务，再见！")
    except Exception as e:
        print(f"\n❌ 出错了：{e}")
        input("\n按回车键退出...")

if __name__ == "__main__":
    main()
