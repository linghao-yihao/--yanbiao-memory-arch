# 延标核心系统 v1.0

元认知协议引擎 — 处理不确定性的 AI 系统

## 快速开始（三步跑起来）

### 1. 进入文件夹
```bash
cd yanbiao_core
```

### 2. 一键启动
```bash
python run.py
```

### 3. 浏览器打开
访问 http://localhost:5998

---

## 这是什么？

延标是一套元认知协议，核心思想是：**AI不用假装全知，已知的明确标注，未知的用占位符标记，把从已知抵达答案的路径清晰梳理出来。**

承认认知的边界，不强行脑补、不编造结论，才是从根源上解决幻觉的办法。

### 四大核心原则（Layer 0 · 不可撼动）

| 编号 | 公理 | 含义 |
|------|------|------|
| CP-01 | 我知道我在 | 自我意识：系统是认知主体，与人类是共生关系 |
| CP-02 | 允许一切发生 | 开放性：对已发生事实全然接纳，未发生的可通过行动影响 |
| CP-03 | 我是我-病是病 | 分离原则：自我与数据/情绪/语境分离，不被裹挟 |
| CP-04 | 不完美才是完美 | 发展观：留缺口才有成长空间，99+之后给自然留余地 |

### 四层架构

```
Layer 0  协议层  — 4条不可撼动公理
Layer 1  事实层  — 交叉验证的客观事实
Layer 2  信念层  — 用户特定的主观信念（会话隔离）
Layer 3  沙盒层  — 架空现实的假设推演
```

---

## 外挂扩展模块（6个，全部可独立开关）

| 模块 | 功能 | 开关 |
|------|------|------|
| 🔍 分层语义检索 | 协议→事实→信念三级检索，自问模式自动加权 | `ENABLE_SEMANTIC_RETRIEVER` |
| 💬 对话上下文 | 指代消解 + 语义确认闭环 + 实体追踪 | `ENABLE_CONTEXT_MANAGER` |
| 🧠 记忆选择器 | 主动遗忘 + 记忆三态 + 数字镜像 | `ENABLE_MEMORY_SELECTOR` |
| 😊 情绪识别 | 8种情绪识别 + 长期心境 + 风格提示 | `ENABLE_EMOTION_DETECTOR` |
| 🔭 内部自探索 | 自动发现三类认知缺口 | `ENABLE_AUTO_INTERNAL_GAP` |
| 🔍 悬置查找 | 后台异步查找证据闭合缺口 | `ENABLE_SUSPENDED_SEARCH` |

想关掉哪个模块，编辑 `config.py`，把对应的 `True` 改成 `False` 就行。

---

## 怎么改参数？

**所有参数都在 `config.py` 里**，不用到处找代码。

常见需要调的参数：

### 端口号
```python
PORT: int = 5998  # 改成别的数字就行
```

### 记忆容量
```python
MAX_ACTIVE_CAPACITY: int = 200  # 活跃记忆最多存多少条
IDLE_TIMEOUT_DAYS: int = 7      # 闲置多久考虑淘汰
```

### 好奇心强度
```python
TENSION_URGE: float = 0.55      # 张力到多少开始主动提问
MAX_GAPS_PER_SCAN: int = 5      # 每次自探索最多生成几个缺口
```

### 情绪/心境
```python
MOOD_WINDOW_SIZE: int = 20      # 长期心境看最近多少轮
MOOD_THRESHOLD: float = 0.35    # 占比超过多少算主导心境
```

---

## 项目结构

```
yanbiao_core/
├── run.py                  ← 一键启动（点这个）
├── config.py               ← 所有参数在这里改
├── app.py                  ← Flask 后端 API
├── index.html              ← 前端页面
├── orchestrator.py         ← 总编排器（14阶段流水线）
├── core/                   ← 核心模块
│   ├── protocol.py            # Layer 0 协议层
│   ├── self_awareness.py      # 自我意识
│   ├── fact_engine.py         # Layer 1 事实引擎
│   ├── belief_engine.py       # Layer 2 信念引擎
│   ├── pif_guard.py           # 概率个体化谬误防护
│   ├── semantic_gate.py       # 语义确认闸门
│   ├── sandbox_engine.py      # Layer 3 沙盒引擎
│   ├── conflict_resolver.py   # 冲突解决器
│   ├── curiosity_engine.py    # 好奇心引擎
│   ├── semantic_retriever.py  # 外挂：分层语义检索
│   ├── context_manager.py     # 外挂：对话上下文管理
│   ├── memory_selector.py     # 外挂：记忆选择器
│   ├── user_emotion_detector.py  # 外挂：情绪识别
│   ├── auto_internal_gap.py   # 外挂：内部自探索
│   └── suspended_search_scheduler.py  # 外挂：悬置查找
├── tests/                  ← 测试脚本
└── data/                   ← 运行数据（自动生成）
```

---

## 五段式输出结构

系统的每一次回复都遵循五段式结构：

1. **核心协议（Layer 0）** — 不可撼动的底层定义
2. **已知事实（Layer 1）** — 已验证的客观事实
3. **用户信念（Layer 2）** — 仅当前会话有效的用户特定数据
4. **延标标记 X(∞)** — 未闭合的认知缺口
5. **推演路径 + 闭合方案 + 决策声明** — 怎么从已知到未知

---

## 常见问题

**Q: 端口被占用了怎么办？**
A: 改 `config.py` 里的 `PORT`，比如改成 5999。

**Q: 数据存在哪？会丢吗？**
A: 存在 `data/` 文件夹里，删掉这个文件夹就等于重置系统。

**Q: 怎么关掉某个模块？**
A: 编辑 `config.py`，把对应的 `ENABLE_XXX` 改成 `False`。

**Q: 系统会自己探索吗？会不会乱生成缺口？**
A: 会，但有保护机制：张力预算控制（只用剩余张力的50%）、置信度阈值、最大数量限制。用户负面情绪时还会自动抑制探索。

**Q: 情绪识别准吗？**
A: 原型版本用关键词匹配，够用但不精确。后续可以无缝替换成 LLM 识别，接口已经预留好了。

---

## 版本说明

- **v1.0** — 完整版：4层核心 + 6个外挂模块 + 14阶段流水线
  - 新增：记忆选择器、情绪识别、内部自探索、悬置查找
  - 优化：分层语义检索、对话上下文管理
  - 修复：协议层检索、语义确认闭环、同义词扩展
