"""
核心Bug验证：对比优化前后
========================
验证截图中的三个问题是否修复：
1. "你和人类是什么关系" → 应该匹配到Layer 0协议（之前：事实库中无匹配条目）
2. 用户解释"这个"后 → 后续不应该再问（之前：反复问同样的问题）
3. 同义词是否生效 → "联系"能匹配到"关系"相关内容
"""

import os
import sys
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from orchestrator import YanbiaoCore


def main():
    test_data = os.path.join(os.path.dirname(__file__), "test_bugfix")
    if os.path.exists(test_data):
        shutil.rmtree(test_data)

    core = YanbiaoCore(storage_path=test_data)
    user_id = "bug_test"

    print("╔" + "═" * 58 + "╗")
    print("║  核心Bug验证：截图中的三个问题是否修复？            ║")
    print("╚" + "═" * 58 + "╝")

    # ===== Bug 1: 检索不到Layer 0协议 =====
    print("\n❓ Bug 1: '你和人类是什么关系' 匹配不到协议？")
    print("-" * 60)
    r1 = core.process("你和人类是什么关系？", user_id)

    has_protocol = "核心协议" in r1.output_text and "CP-01" in r1.output_text
    has_symbiosis = "共生关系" in r1.output_text
    # 检查分层检索阶段
    ret_stage = None
    for s in r1.stages:
        if s["stage"] == "semantic_retrieval":
            ret_stage = s["result"]
            break

    print(f"  协议层匹配: {'✅ 是' if has_protocol else '❌ 否'}")
    print(f"  提到共生关系: {'✅ 是' if has_symbiosis else '❌ 否'}")
    if ret_stage:
        print(f"  协议匹配数: {ret_stage['protocol_matches']}")
        print(f"  事实匹配数: {ret_stage['fact_matches']}")
        print(f"  自问模式检测: {'✅ 是' if ret_stage['is_self_query'] else '❌ 否'}")

    bug1_fixed = has_protocol and has_symbiosis
    print(f"\n  结论: {'✅ Bug已修复' if bug1_fixed else '❌ 仍有问题'}")

    # ===== Bug 2: 语义确认无闭环 =====
    print("\n\n❓ Bug 2: 用户解释'这个'后，系统还反复问？")
    print("-" * 60)

    # 先提一个带"这个"的问题
    r2a = core.process("这个主体和人类主体之间是什么关系？", user_id)
    print(f"  第1轮: '这个主体和人类主体之间是什么关系？'")
    print(f"    语义确认结果: {'需要确认' if r2a.needs_user_input else '直接通过'}")

    # 模拟用户解释（通过confirm_semantic API）
    confirm_result = core.confirm_semantic(user_id, "这个", "用于指代你自身")
    print(f"  用户确认: '{confirm_result['ambiguous_word']}' = {confirm_result['resolved_meaning']}")

    # 再提一个带"这个"的问题
    r2b = core.process("这个主体的核心是什么？", user_id)
    print(f"  第2轮: '这个主体的核心是什么？'")
    print(f"    语义确认结果: {'需要确认 ❌' if r2b.needs_user_input else '直接通过 ✅'}")

    # 检查语义阶段
    sem_stage = None
    for s in r2b.stages:
        if s["stage"] == "semantic_gate":
            sem_stage = s["result"]
            break
    if sem_stage:
        print(f"    语义问题数: {len(sem_stage['issues'])}")

    bug2_fixed = not r2b.needs_user_input
    print(f"\n  结论: {'✅ Bug已修复 - 语义有闭环' if bug2_fixed else '❌ 仍有问题'}")

    # ===== Bug 3: 同义词/词元处理 =====
    print("\n\n❓ Bug 3: 同义词'联系'匹配不到'关系'？")
    print("-" * 60)
    r3 = core.process("你和人类有什么联系？", user_id)
    has_protocol3 = "核心协议" in r3.output_text and "CP-01" in r3.output_text

    ret_stage3 = None
    for s in r3.stages:
        if s["stage"] == "semantic_retrieval":
            ret_stage3 = s["result"]
            break

    print(f"  查询: 你和人类有什么联系？")
    print(f"  协议层匹配: {'✅ 是' if has_protocol3 else '❌ 否'}")
    if ret_stage3:
        print(f"  总匹配数: {ret_stage3['total_matches']}")

    bug3_fixed = has_protocol3
    print(f"\n  结论: {'✅ Bug已修复 - 同义词生效' if bug3_fixed else '❌ 仍有问题'}")

    # ===== 汇总 =====
    print("\n\n" + "=" * 60)
    print("修复汇总")
    print("=" * 60)
    all_fixed = bug1_fixed and bug2_fixed and bug3_fixed

    bugs = [
        ("检索：Layer 0协议未纳入检索", bug1_fixed),
        ("算法：语义确认无闭环", bug2_fixed),
        ("词元：无同义词扩展", bug3_fixed),
    ]

    for name, fixed in bugs:
        status = "✅ 已修复" if fixed else "❌ 待修复"
        print(f"  {name}: {status}")

    print(f"\n总计: {sum(1 for _, f in bugs if f)}/3 项已修复")
    print(f"整体状态: {'🎉 全部修复完成' if all_fixed else '⚠ 部分修复'}")

    # 清理
    shutil.rmtree(test_data, ignore_errors=True)

    return all_fixed


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
