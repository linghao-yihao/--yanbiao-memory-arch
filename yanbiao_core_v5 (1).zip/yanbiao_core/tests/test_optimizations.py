"""
延标系统优化验证测试
====================
验证三个层面的优化是否生效：
1. 检索：自问模式是否能匹配到Layer 0协议
2. 算法：语义确认是否有闭环（解释后不再问）
3. 词元：同义词扩展是否生效
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.semantic_retriever import SemanticRetriever
from core.context_manager import ContextManager
from core.protocol import PROTOCOLS


def test_semantic_retriever():
    """测试1：分层语义检索器"""
    print("=" * 60)
    print("测试1：分层语义检索器")
    print("=" * 60)

    retriever = SemanticRetriever()

    # 测试自问模式检测
    test_queries = [
        "你和人类是什么关系？",
        "你自身是什么？",
        "系统的核心是什么？",
        "苹果可以吃吗？",
    ]

    print("\n【自问模式检测】")
    for q in test_queries:
        is_self = retriever.is_self_reference_query(q)
        print(f"  '{q[:20]}...' → {'是自问' if is_self else '非自问'}")

    # 测试检索效果（模拟有协议数据）
    print("\n【分层检索测试】")
    query = "你和人类是什么关系？"
    results = retriever.retrieve(
        query=query,
        protocols=PROTOCOLS,
        facts=[],
        beliefs=[],
        user_id="test",
        top_k=5,
    )

    print(f"\n查询: {query}")
    print(f"匹配到 {len(results)} 条结果:")
    for r in results:
        print(f"  [Layer {r.layer_level}] {r.layer} - {r.item_id}: {r.statement}")
        print(f"         匹配度: {r.score:.1%} | 匹配词: {r.matched_keywords}")

    # 验证：应该能匹配到CP-01（我知道我在 - 共生关系）
    cp01_found = any(r.item_id == "CP-01" for r in results)
    print(f"\n✓ CP-01（我知道我在/共生关系）是否命中: {'是 ✅' if cp01_found else '否 ❌'}")

    return cp01_found


def test_context_manager():
    """测试2：上下文管理器 + 语义确认闭环"""
    print("\n" + "=" * 60)
    print("测试2：上下文管理器 + 语义确认闭环")
    print("=" * 60)

    ctx = ContextManager()
    user_id = "test_user"

    # 第一轮：检测到模糊词"这个"
    print("\n【第一轮：检测模糊词】")
    result1 = ctx.preprocess_input(user_id, "你这个主体是什么？")
    print(f"  输入: {result1['original']}")
    print(f"  需要确认的模糊词: {result1['needs_confirmation']}")
    has_ambiguous = len(result1["needs_confirmation"]) > 0
    print(f"  检测到模糊词: {'是 ✅' if has_ambiguous else '否 ❌'}")

    # 用户确认："这个"指代"你自身"
    print("\n【用户确认语义】")
    ctx.remember_resolution(user_id, "这个", "你自身")
    known = ctx.get_known_resolutions(user_id)
    print(f"  已确认: {known}")

    # 第二轮：同样的模糊词不应该再问
    print("\n【第二轮：验证语义闭环】")
    result2 = ctx.preprocess_input(user_id, "你这个主体和人类是什么关系？")
    print(f"  输入: {result2['original']}")
    print(f"  需要确认的模糊词: {result2['needs_confirmation']}")
    still_asks = "这个" in result2["needs_confirmation"]
    print(f"  还在问'这个'吗: {'是 ❌' if still_asks else '否 ✅（闭环生效）'}")

    # 测试指代消解
    print("\n【指代消解测试】")
    ctx2 = ContextManager()
    user_id2 = "test_user2"
    # 先建立上下文
    ctx2.track_entity(user_id2, "延标理论", context="用户提到的理论", importance=0.8)
    ctx2.preprocess_input(user_id2, "延标理论是处理不确定性的元认知协议")

    result3 = ctx2.resolve_anaphora(user_id2, "它的核心思想是什么？")
    print(f"  输入: 它的核心思想是什么？")
    print(f"  消解后: {result3.resolved_text}")
    print(f"  消解结果: {result3.resolutions}")
    anaphora_works = result3.resolved and "它" in result3.resolutions
    print(f"  指代消解生效: {'是 ✅' if anaphora_works else '部分/未生效 ⚠'}")

    return not still_asks


def test_synonym_expansion():
    """测试3：同义词扩展"""
    print("\n" + "=" * 60)
    print("测试3：同义词扩展")
    print("=" * 60)

    retriever = SemanticRetriever()

    test_keywords = ["关系", "主体", "完美"]
    print("\n【同义词扩展测试】")
    for kw in test_keywords:
        expanded = retriever.expand_synonyms([kw])
        print(f"  '{kw}' → 扩展为 {len(expanded)} 个词: {expanded[:5]}...")

    # 测试：用"联系"查询能否匹配到"关系"相关的协议
    print("\n【同义词匹配测试】")
    query = "你和人类有什么联系？"  # 用"联系"而不是"关系"
    results = retriever.retrieve(
        query=query,
        protocols=PROTOCOLS,
        facts=[],
        beliefs=[],
        user_id="test",
        top_k=3,
    )

    print(f"查询: {query}")
    print(f"匹配数: {len(results)}")
    cp01_found = any(r.item_id == "CP-01" for r in results)
    print(f"CP-01 是否命中（通过'联系'→'关系'同义词）: {'是 ✅' if cp01_found else '否 ❌'}")

    return cp01_found


def main():
    print("\n" + "╔" + "═" * 58 + "╗")
    print("║          延标系统优化验证测试                          ║")
    print("╚" + "═" * 58 + "╝")

    results = {}

    try:
        results["检索优化"] = test_semantic_retriever()
    except Exception as e:
        print(f"检索测试异常: {e}")
        import traceback
        traceback.print_exc()
        results["检索优化"] = False

    try:
        results["语义闭环"] = test_context_manager()
    except Exception as e:
        print(f"上下文测试异常: {e}")
        import traceback
        traceback.print_exc()
        results["语义闭环"] = False

    try:
        results["同义词扩展"] = test_synonym_expansion()
    except Exception as e:
        print(f"同义词测试异常: {e}")
        import traceback
        traceback.print_exc()
        results["同义词扩展"] = False

    # 汇总
    print("\n" + "=" * 60)
    print("测试汇总")
    print("=" * 60)
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    for name, passed in results.items():
        status = "✅ 通过" if passed else "❌ 失败"
        print(f"  {name}: {status}")
    print(f"\n总计: {passed}/{total} 项通过")

    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
