"""
端到端集成测试
==============
验证完整的编排器流程是否正常工作。
"""

import os
import sys
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from orchestrator import YanbiaoCore


def test_end_to_end():
    """端到端测试：模拟用户对话流程"""
    print("=" * 60)
    print("端到端集成测试")
    print("=" * 60)

    # 使用临时数据目录
    test_data = os.path.join(os.path.dirname(__file__), "test_data_e2e")
    if os.path.exists(test_data):
        shutil.rmtree(test_data)

    core = YanbiaoCore(storage_path=test_data)
    user_id = "test_user"

    # 测试1：自问"你和人类是什么关系"
    print("\n【测试1：自问模式 - 你和人类是什么关系？】")
    result1 = core.process("你和人类是什么关系？", user_id)
    print(f"  输出前300字:\n{result1.output_text[:300]}...")

    # 检查是否有协议层匹配
    has_protocol = "核心协议" in result1.output_text
    print(f"\n  有协议层匹配: {'是 ✅' if has_protocol else '否 ❌'}")

    # 检查是否还显示"事实库中无匹配条目"
    no_match_text = "无匹配条目" in result1.output_text
    print(f"  仍显示'无匹配条目': {'否 ✅' if not no_match_text else '是 ❌'}")

    # 测试2：语义确认闭环
    print("\n【测试2：语义确认闭环】")
    # 第一轮：带"这个"的问题
    result2a = core.process("你这个主体的定位是什么？", user_id)
    needs_confirm = result2a.needs_user_input
    print(f"  第一轮: 检测到模糊词需要确认 → {'是 ✅' if needs_confirm else '否'}")

    # 用户确认
    core.confirm_semantic(user_id, "这个", "指代你自身")

    # 第二轮：同样的模糊词
    result2b = core.process("这个主体和人类怎么协作？", user_id)
    still_asks = result2b.needs_user_input and "这个" in str(result2b.questions_for_user)
    print(f"  第二轮: 用户解释后还问吗 → {'否 ✅（闭环）' if not still_asks else '是 ❌'}")

    # 测试3：指代消解
    print("\n【测试3：指代消解】")
    # 先建立上下文
    core.process("延标理论是一种元认知协议", user_id)
    # 再用"它"提问
    result3 = core.process("它的核心思想是什么？", user_id)
    print(f"  输入: 它的核心思想是什么？")
    # 检查上下文预处理阶段
    ctx_stage = None
    for s in result3.stages:
        if s["stage"] == "context_preprocess":
            ctx_stage = s["result"]
            break
    if ctx_stage:
        print(f"  消解后文本: {ctx_stage.get('resolved_text', 'N/A')[:50]}")
        anaphora_resolved = ctx_stage.get("anaphora_resolved", False)
        print(f"  指代消解生效: {'是 ✅' if anaphora_resolved else '否 ⚠'}")

    # 测试4：系统状态
    print("\n【测试4：系统状态】")
    state = core.get_system_state()
    print(f"  事实数: {state['facts']['total']}")
    print(f"  上下文用户数: {state['context'].get('total_users', 0)}")
    print(f"  系统张力: {state['system_tension'].get('level', 'N/A')}")

    # 清理
    shutil.rmtree(test_data, ignore_errors=True)

    print("\n" + "=" * 60)
    print("端到端测试完成 ✅")
    print("=" * 60)


if __name__ == "__main__":
    test_end_to_end()
