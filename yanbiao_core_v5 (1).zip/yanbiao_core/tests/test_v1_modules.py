"""
四个外挂模块集成测试
======================
验证 memory_selector / user_emotion_detector / auto_internal_gap / suspended_search_scheduler
全部正常工作，且不破坏原有核心功能。
"""

import os
import sys
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from orchestrator import YanbiaoCore


def test_all_modules():
    """完整集成测试"""
    print("=" * 70)
    print("  延标核心系统 V1.0 外挂扩展模块集成测试")
    print("=" * 70)

    test_data = os.path.join(os.path.dirname(__file__), "test_data_v1")
    if os.path.exists(test_data):
        shutil.rmtree(test_data)

    core = YanbiaoCore(storage_path=test_data)
    user_id = "test_user"
    results = {}

    # ===== 测试1：系统初始状态 =====
    print("\n【测试1：系统初始状态】")
    state = core.get_system_state()
    print(f"  模块开关: {state['modules']}")
    print(f"  记忆选择器: {state['memory_selector']['total']} 条记忆")
    print(f"  情绪检测器: {state['emotion_detector']['total_users']} 个用户")
    print(f"  自探索生成器: 启用={state['auto_internal_gap']['enabled']}")
    print(f"  悬置查找调度器: 队列{state['suspended_search']['queue_size']}")
    all_modules_present = all(k in state["modules"] for k in
                              ["memory_selector", "emotion_detector",
                               "auto_internal_gap", "suspended_search"])
    print(f"  四个模块全部注册: {'✅ 是' if all_modules_present else '❌ 否'}")
    results["模块注册"] = all_modules_present

    # ===== 测试2：情绪识别 =====
    print("\n【测试2：用户情绪识别模块】")
    test_inputs = [
        ("今天天气真好哈哈，挺开心的", "happy", "正面情绪"),
        ("烦死了，这东西怎么搞都搞不懂", "frustrated", "负面情绪"),
        ("有点担心明天的结果", "anxious", "焦虑情绪"),
        ("延标理论的核心架构是什么？", "curious/calm", "好奇/平静"),
    ]

    emotion_ok = True
    for text, expected_emotion, desc in test_inputs:
        r = core.process(text, user_id)
        emo_stage = None
        for s in r.stages:
            if s["stage"] == "emotion_detection":
                emo_stage = s["result"]
                break
        if emo_stage:
            print(f"  '{text[:20]}...' → {emo_stage['emotion']} "
                  f"(强度:{emo_stage['intensity']}, 置信度:{emo_stage['confidence']})")
        else:
            print(f"  '{text[:20]}...' → ❌ 未检测到情绪阶段")
            emotion_ok = False

    # 检查情绪抑制功能
    mood = core.emotion_detector.get_mood(user_id)
    print(f"  长期心境: {mood._dominant_mood.value if mood and mood._dominant_mood else '未形成'}")
    print(f"  情绪识别正常: {'✅ 是' if emotion_ok else '❌ 否'}")
    results["情绪识别"] = emotion_ok

    # ===== 测试3：数字镜像 =====
    print("\n【测试3：数字镜像（交互风格适配）】")
    # 多轮对话积累风格数据
    for i in range(5):
        core.process(f"测试对话第{i}轮，内容随意", user_id)

    state = core.get_system_state()
    ms = state["memory_selector"]
    print(f"  交互轮数: {ms['digital_mirrors']} 个镜像")

    # 检查镜像数据
    mirror = core.memory_selector.get_digital_mirror(user_id)
    if mirror:
        print(f"  平均句长: {mirror.avg_sentence_length:.1f} 字")
        print(f"  正式程度: {mirror.formality_score:.3f}")
        print(f"  风格提示: {mirror.get_style_prompt()}")
        mirror_ok = True
    else:
        mirror_ok = False
        print(f"  ❌ 未找到数字镜像")

    print(f"  数字镜像正常: {'✅ 是' if mirror_ok else '❌ 否'}")
    results["数字镜像"] = mirror_ok

    # ===== 测试4：记忆选择器（主动遗忘）=====
    print("\n【测试4：记忆选择器 — 主动遗忘机制】")
    # 注册一些事实模拟记忆积累
    for i in range(15):
        core.fact_engine.register_fact(
            f"测试事实{i}号：用于验证记忆选择器功能",
            user_id=user_id,
            tags=["测试数据", f"tag{i}"],
        )

    # 手动触发访问统计（模拟不同访问频率）
    from core.memory_selector import MemorySelector
    mem_stats = core.memory_selector.stats()
    print(f"  注册前记忆数: {mem_stats['total']}")

    # 模拟访问
    for i in range(15):
        fact_id = list(core.fact_engine._facts.keys())[i % len(core.fact_engine._facts)]
        for _ in range(i % 5):  # 不同访问频率
            core.memory_selector.on_access(fact_id)

    mem_stats2 = core.memory_selector.stats()
    print(f"  访问后记忆数: {mem_stats2['total']}")
    print(f"  活跃数: {mem_stats2['active']}")
    print(f"  容量使用率: {mem_stats2['capacity_ratio']:.0%}")

    # 手动降低容量阈值触发淘汰测试
    original_capacity = core.memory_selector.MAX_ACTIVE_CAPACITY
    core.memory_selector.MAX_ACTIVE_CAPACITY = 10  # 降低容量触发淘汰
    evict_result = core.memory_selector.run_eviction()
    print(f"  降低容量后淘汰: {evict_result['active_before']} → {evict_result['active_after']} "
          f"(淘汰了 {len(evict_result['evicted'])} 条)")
    print(f"  淘汰原因: {evict_result['reason']}")

    # 恢复
    core.memory_selector.MAX_ACTIVE_CAPACITY = original_capacity
    memory_ok = len(evict_result['evicted']) > 0
    print(f"  主动遗忘机制正常: {'✅ 是' if memory_ok else '❌ 否'}")
    results["记忆选择器"] = memory_ok

    # ===== 测试5：内部自探索缺口生成 =====
    print("\n【测试5：内部自探索缺口生成器】")
    # 先注册几条有重叠的事实
    core.fact_engine.register_fact("延标理论是处理不确定性的元认知协议", tags=["延标", "理论"])
    core.fact_engine.register_fact("延标体系用X(∞)标记认知边界", tags=["延标", "X(∞)"])
    core.fact_engine.register_fact("认知边界的标记有助于减少幻觉", tags=["认知", "幻觉"])

    # 手动触发自探索
    all_facts = list(core.fact_engine._facts.values())
    all_beliefs = list(core.belief_engine._beliefs.values()) if hasattr(core.belief_engine, '_beliefs') else []

    gap_result = core.auto_gap.scan_and_generate(
        active_facts=all_facts,
        active_beliefs=all_beliefs,
        curiosity_engine=core.curiosity,
        system_tension=0.1,
        tension_max=1.0,
    )

    print(f"  扫描记忆数: {gap_result.get('total_memories_scanned', 0)}")
    print(f"  发现提案数: {gap_result.get('proposals_found', 0)}")
    print(f"  生成缺口数: {gap_result.get('gaps_generated', 0)}")
    if gap_result.get("generated_gaps"):
        for g in gap_result["generated_gaps"][:3]:
            print(f"    - {g['variable']} ({g['source']}, {g['priority']})")

    auto_gap_ok = gap_result.get("gaps_generated", 0) >= 0  # 生成0个也算正常（记忆不够多）
    auto_gap_works = gap_result.get("scan_id", 0) > 0
    print(f"  自探索生成器正常: {'✅ 是' if auto_gap_works else '❌ 否'}")
    results["自探索生成器"] = auto_gap_works

    # ===== 测试6：悬置查找调度器 =====
    print("\n【测试6：悬置查找调度器】")
    sched_stats_before = core.search_scheduler.stats()
    print(f"  提交前队列: {sched_stats_before['queue_size']}")

    # 提交一个测试缺口
    from core.suspended_search_scheduler import SearchPriority
    submit_result = core.search_scheduler.submit(
        gap_id="test-gap-001",
        gap_variable="X(∞)_测试",
        gap_description="测试缺口：验证悬置查找调度器是否正常工作",
        priority=SearchPriority.USER_TRIGGERED,
    )
    print(f"  提交结果: {submit_result.get('submitted', False)} "
          f"(队列位置: {submit_result.get('queue_position', '?')})")

    sched_stats_after = core.search_scheduler.stats()
    print(f"  提交后队列: {sched_stats_after['queue_size']}")

    # 执行查找
    search_result = core.search_scheduler.process_next(
        fact_engine=core.fact_engine,
        belief_engine=core.belief_engine,
        curiosity_engine=core.curiosity,
        user_id=user_id,
    )
    if search_result:
        print(f"  执行结果: {search_result['status']}")
        print(f"  结果描述: {search_result.get('result', 'N/A')[:50]}")

    sched_final = core.search_scheduler.stats()
    print(f"  最终状态: 已完成{sched_final['total_completed']}, "
          f"悬置{sched_final['total_suspended']}")

    scheduler_ok = submit_result.get("submitted", False) and search_result is not None
    print(f"  悬置查找调度器正常: {'✅ 是' if scheduler_ok else '❌ 否'}")
    results["悬置查找调度器"] = scheduler_ok

    # ===== 测试7：端到端完整对话 =====
    print("\n【测试7：端到端完整对话（所有模块串联）】")

    # 重置上下文
    core.context.clear_context(user_id)

    # 一轮完整对话
    r = core.process("我最近好累啊，感觉什么都不想做，延标理论能帮我吗？", user_id)

    # 检查经过了哪些阶段
    stage_names = [s["name"] for s in r.stages]
    print(f"  经过阶段数: {len(stage_names)}")
    for name in stage_names:
        print(f"    → {name}")

    required_stages = [
        "上下文预处理",
        "情绪识别（外挂）",
        "数字镜像更新（外挂）",
        "自我意识预检",
        "语义确认",
        "分层语义检索",
        "好奇心驱动",
        "记忆选择器（外挂）",
        "内部自探索（外挂）",
    ]
    stages_found = sum(1 for s in required_stages if s in stage_names)
    print(f"\n  关键阶段命中: {stages_found}/{len(required_stages)}")

    e2e_ok = stages_found >= len(required_stages) - 2  # 允许缺2个（有些条件触发）
    print(f"  端到端流程正常: {'✅ 是' if e2e_ok else '❌ 否'}")
    results["端到端集成"] = e2e_ok

    # ===== 汇总 =====
    print("\n" + "=" * 70)
    print("  测试汇总")
    print("=" * 70)

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for name, ok in results.items():
        status = "✅ 通过" if ok else "❌ 失败"
        print(f"  {name}: {status}")

    print(f"\n总计: {passed}/{total} 项通过")
    print(f"整体状态: {'🎉 全部通过' if passed == total else '⚠ 部分通过'}")

    # 清理
    shutil.rmtree(test_data, ignore_errors=True)

    return passed == total


if __name__ == "__main__":
    success = test_all_modules()
    sys.exit(0 if success else 1)
