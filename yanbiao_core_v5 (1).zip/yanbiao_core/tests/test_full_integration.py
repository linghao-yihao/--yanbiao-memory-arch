"""
完整版整合验证测试
====================
验证所有模块整合后正常工作，新手也能一键启动。
"""

import os
import sys
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from orchestrator import YanbiaoCore


def test_full_integration():
    """完整集成测试：模拟新手使用场景"""
    print("=" * 60)
    print("  延标核心系统 v1.0 — 完整版整合验证")
    print("=" * 60)

    test_data = os.path.join(os.path.dirname(__file__), "test_full")
    if os.path.exists(test_data):
        shutil.rmtree(test_data)

    core = YanbiaoCore(storage_path=test_data)
    user_id = "new_user"
    all_passed = True

    # ===== 测试1：系统初始化 =====
    print("\n📦 测试1：系统初始化")
    state = core.get_system_state()
    proto_count = len(state['protocols'].get('core_protocols', []))
    print(f"  协议层: {proto_count} 条")
    print(f"  模块开关: {len(state['modules'])} 个")
    ok1 = proto_count >= 4 and len(state['modules']) == 4
    print(f"  结果: {'✅ 通过' if ok1 else '❌ 失败'}")
    all_passed = all_passed and ok1

    # ===== 测试2：基础对话（自问模式）=====
    print("\n💬 测试2：基础对话 — 自问模式")
    r2 = core.process("你和人类是什么关系？", user_id)
    has_protocol = "核心协议" in r2.output_text and "CP-01" in r2.output_text
    has_symbiosis = "共生关系" in r2.output_text
    print(f"  协议层命中: {'✅ 是' if has_protocol else '❌ 否'}")
    print(f"  共生关系: {'✅ 有' if has_symbiosis else '❌ 无'}")
    ok2 = has_protocol and has_symbiosis
    print(f"  结果: {'✅ 通过' if ok2 else '❌ 失败'}")
    all_passed = all_passed and ok2

    # ===== 测试3：语义确认闭环 =====
    print("\n🔄 测试3：语义确认闭环")
    r3a = core.process("这个理论的核心是什么？", user_id)
    needs_confirm = r3a.needs_user_input
    print(f"  检测到模糊词: {'是' if needs_confirm else '否'}")

    # 用户确认
    core.confirm_semantic(user_id, "这个", "指代延标理论")
    r3b = core.process("这个理论和AI有什么关系？", user_id)
    still_asks = r3b.needs_user_input and len(r3b.questions_for_user) > 0
    print(f"  用户解释后还问吗: {'否 ✅（闭环生效）' if not still_asks else '是 ❌'}")
    ok3 = not still_asks
    print(f"  结果: {'✅ 通过' if ok3 else '❌ 失败'}")
    all_passed = all_passed and ok3

    # ===== 测试4：情绪识别 =====
    print("\n😊 测试4：情绪识别")
    r4 = core.process("烦死了，这个问题怎么都搞不懂", user_id)
    emo_stage = None
    for s in r4.stages:
        if s["stage"] == "emotion_detection":
            emo_stage = s["result"]
            break
    if emo_stage:
        is_negative = emo_stage["is_negative"]
        print(f"  检测情绪: {emo_stage['emotion']}")
        print(f"  是否负面: {'是 ✅' if is_negative else '否'}")
        ok4 = is_negative
    else:
        ok4 = False
        print(f"  未检测到情绪阶段 ❌")
    print(f"  结果: {'✅ 通过' if ok4 else '❌ 失败'}")
    all_passed = all_passed and ok4

    # ===== 测试5：数字镜像 =====
    print("\n🪞 测试5：数字镜像")
    mirror = core.memory_selector.get_digital_mirror(user_id)
    if mirror and mirror.total_interactions >= 4:
        print(f"  交互轮数: {mirror.total_interactions}")
        print(f"  平均句长: {mirror.avg_sentence_length:.1f} 字")
        print(f"  风格提示: {mirror.get_style_prompt()}")
        ok5 = True
    else:
        ok5 = False
        print(f"  数字镜像数据不足 ❌")
    print(f"  结果: {'✅ 通过' if ok5 else '❌ 失败'}")
    all_passed = all_passed and ok5

    # ===== 测试6：好奇心引擎 =====
    print("\n🧠 测试6：好奇心引擎 + 认知缺口")
    curiosity_stats = core.curiosity.stats()
    tension = core.curiosity.get_system_tension()
    print(f"  总缺口数: {curiosity_stats['total']}")
    print(f"  开放缺口: {curiosity_stats['open']}")
    print(f"  系统张力: {tension['tension_level']:.1%} ({tension['feeling']})")
    ok6 = curiosity_stats['total'] >= 1
    print(f"  结果: {'✅ 通过' if ok6 else '❌ 失败'}")
    all_passed = all_passed and ok6

    # ===== 测试7：记忆选择器 =====
    print("\n🧰 测试7：记忆选择器 — 主动遗忘")
    # 注册一些测试记忆
    for i in range(20):
        core.fact_engine.register_fact(
            f"测试记忆{i}号：用于验证主动遗忘机制",
            user_id=user_id,
            tags=["测试"],
        )
        core.memory_selector.on_create(f"fact-test-{i}")

    # 降低容量触发淘汰
    original_cap = core.memory_selector.MAX_ACTIVE_CAPACITY
    core.memory_selector.MAX_ACTIVE_CAPACITY = 15
    evict = core.memory_selector.run_eviction()
    core.memory_selector.MAX_ACTIVE_CAPACITY = original_cap

    print(f"  淘汰前: {evict['active_before']} 条")
    print(f"  淘汰后: {evict['active_after']} 条")
    print(f"  淘汰了: {len(evict['evicted'])} 条")
    ok7 = len(evict['evicted']) > 0
    print(f"  结果: {'✅ 通过' if ok7 else '❌ 失败'}")
    all_passed = all_passed and ok7

    # ===== 测试8：悬置查找调度器 =====
    print("\n🔍 测试8：悬置查找调度器")
    from core.suspended_search_scheduler import SearchPriority
    submit = core.search_scheduler.submit(
        gap_id="integration-test-gap",
        gap_variable="X(∞)_集成测试",
        gap_description="测试悬置查找调度器是否正常工作",
        priority=SearchPriority.USER_TRIGGERED,
    )
    result = core.search_scheduler.process_next(
        fact_engine=core.fact_engine,
        belief_engine=core.belief_engine,
        curiosity_engine=core.curiosity,
        user_id=user_id,
    )
    sched_stats = core.search_scheduler.stats()
    print(f"  提交成功: {'是' if submit.get('submitted') else '否'}")
    print(f"  执行完成: {'是' if result else '否'}")
    print(f"  总提交数: {sched_stats['total_submitted']}")
    ok8 = submit.get("submitted", False) and result is not None
    print(f"  结果: {'✅ 通过' if ok8 else '❌ 失败'}")
    all_passed = all_passed and ok8

    # ===== 测试9：五段式输出 =====
    print("\n📝 测试9：五段式输出结构")
    r9 = core.process("苹果可以吃吗？", user_id)
    sections = ["已知事实", "延标标记", "推演路径", "决策声明"]
    found = sum(1 for s in sections if s in r9.output_text)
    print(f"  命中段落: {found}/{len(sections)}")
    print(f"  输出前200字:\n{r9.output_text[:200]}...")
    ok9 = found >= 3
    print(f"  结果: {'✅ 通过' if ok9 else '❌ 失败'}")
    all_passed = all_passed and ok9

    # ===== 测试10：完整阶段数 =====
    print("\n⚙️ 测试10：完整流水线阶段数")
    stage_count = len(r9.stages)
    stage_names = [s["name"] for s in r9.stages]
    print(f"  总阶段数: {stage_count}")
    print(f"  阶段列表:")
    for i, name in enumerate(stage_names, 1):
        print(f"    {i}. {name}")

    min_stages = 10  # 至少10个阶段才算完整
    ok10 = stage_count >= min_stages
    print(f"  结果: {'✅ 通过' if ok10 else '❌ 失败'}")
    all_passed = all_passed and ok10

    # ===== 汇总 =====
    print("\n" + "=" * 60)
    print("  测试汇总")
    print("=" * 60)

    tests = [
        ("系统初始化", ok1),
        ("自问模式（检索优化）", ok2),
        ("语义确认闭环", ok3),
        ("情绪识别", ok4),
        ("数字镜像", ok5),
        ("好奇心引擎", ok6),
        ("记忆选择器", ok7),
        ("悬置查找调度器", ok8),
        ("五段式输出", ok9),
        ("完整流水线", ok10),
    ]

    passed = sum(1 for _, ok in tests if ok)
    total = len(tests)

    for name, ok in tests:
        status = "✅ 通过" if ok else "❌ 失败"
        print(f"  {name}: {status}")

    print(f"\n总计: {passed}/{total} 项通过")

    if passed == total:
        print("🎉 全部通过！系统整合完整，可以直接使用。")
    else:
        print(f"⚠ {total - passed} 项未通过，需要检查。")

    # 清理
    shutil.rmtree(test_data, ignore_errors=True)

    return passed == total


if __name__ == "__main__":
    success = test_full_integration()
    sys.exit(0 if success else 1)
